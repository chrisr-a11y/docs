// Example 09: List Users
//
// Demonstrates listing users in the firm.
package main

import (
	"fmt"
	"os"

	"github.com/polymarket/client-sample-code/go/config"
	"github.com/polymarket/client-sample-code/go/rest"
)

func main() {
	fmt.Println("============================================================")
	fmt.Println("Example 09: List Users")
	fmt.Println("============================================================")
	fmt.Println()

	// Load configuration
	cfg := config.MustLoad()

	// Create REST client
	client := rest.NewClient(cfg)

	// List users
	fmt.Println("Listing users in firm...")
	result, err := client.ListUsers()
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: %v\n", err)
		os.Exit(1)
	}

	if len(result.Users) == 0 {
		fmt.Println("  No users found")
	} else {
		fmt.Printf("  Found %d user(s):\n", len(result.Users))
		for i, user := range result.Users {
			fmt.Printf("    %d. %s\n", i+1, user)
		}
	}
	fmt.Println()
	fmt.Println("Success!")
}
