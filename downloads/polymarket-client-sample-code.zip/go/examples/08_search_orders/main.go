// Example 08: Search Orders
//
// Demonstrates searching historical orders for an account.
package main

import (
	"fmt"
	"os"

	"github.com/polymarket/client-sample-code/go/config"
	"github.com/polymarket/client-sample-code/go/rest"
)

func main() {
	fmt.Println("============================================================")
	fmt.Println("Example 08: Search Orders")
	fmt.Println("============================================================")
	fmt.Println()

	// Load configuration
	cfg := config.MustLoad()

	// Create REST client
	client := rest.NewClient(cfg)

	// Search orders
	fmt.Printf("Searching orders for account: %s\n", cfg.Account)
	result, err := client.SearchOrders(cfg.Account, 100)
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: %v\n", err)
		os.Exit(1)
	}

	if len(result.Orders) == 0 {
		fmt.Println("  No orders found")
	} else {
		fmt.Printf("  Found %d order(s):\n", len(result.Orders))
		// Show first 5
		limit := 5
		if len(result.Orders) < limit {
			limit = len(result.Orders)
		}
		for i := 0; i < limit; i++ {
			order := result.Orders[i]
			fmt.Printf("    %d. %s %s %s @ %d (status: %s)\n",
				i+1, order.Side, order.Symbol, order.Type, order.Price, order.Status)
		}
		if len(result.Orders) > 5 {
			fmt.Printf("    ... and %d more\n", len(result.Orders)-5)
		}
		if result.NextPageToken != "" {
			fmt.Printf("  Next page token: %s\n", result.NextPageToken)
		}
	}
	fmt.Println()
	fmt.Println("Success!")
}
