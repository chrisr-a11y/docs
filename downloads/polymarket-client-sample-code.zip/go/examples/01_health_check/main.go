// Example 01: Health Check
//
// Demonstrates checking the API health status.
// This endpoint does not require authentication.
package main

import (
	"fmt"
	"os"

	"github.com/polymarket/client-sample-code/go/config"
	"github.com/polymarket/client-sample-code/go/rest"
)

func main() {
	fmt.Println("============================================================")
	fmt.Println("Example 01: Health Check")
	fmt.Println("============================================================")
	fmt.Println()

	// Load configuration (validates environment)
	cfg := config.MustLoad()

	// Create REST client
	client := rest.NewClient(cfg)

	// Check health
	fmt.Println("Checking API health...")
	result, err := client.Health()
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: %v\n", err)
		os.Exit(1)
	}

	fmt.Printf("  Status: %s\n", result.Status)
	fmt.Println()
	fmt.Println("Health check passed!")
}
