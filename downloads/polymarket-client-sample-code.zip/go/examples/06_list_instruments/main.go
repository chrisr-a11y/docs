// Example 06: List Instruments
//
// Demonstrates listing tradeable instruments.
package main

import (
	"fmt"
	"os"

	"github.com/polymarket/client-sample-code/go/config"
	"github.com/polymarket/client-sample-code/go/rest"
)

func main() {
	fmt.Println("============================================================")
	fmt.Println("Example 06: List Instruments")
	fmt.Println("============================================================")
	fmt.Println()

	// Load configuration
	cfg := config.MustLoad()

	// Create REST client
	client := rest.NewClient(cfg)

	// List instruments (empty filter = all instruments)
	fmt.Println("Listing tradeable instruments...")
	result, err := client.ListInstruments(nil)
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: %v\n", err)
		os.Exit(1)
	}

	if len(result.Instruments) == 0 {
		fmt.Println("  No instruments found")
	} else {
		fmt.Printf("  Found %d instrument(s):\n", len(result.Instruments))
		// Show first 10
		limit := 10
		if len(result.Instruments) < limit {
			limit = len(result.Instruments)
		}
		for i := 0; i < limit; i++ {
			inst := result.Instruments[i]
			fmt.Printf("    %d. %s - %s (state: %s)\n",
				i+1, inst.Symbol, inst.Description, inst.State)
		}
		if len(result.Instruments) > 10 {
			fmt.Printf("    ... and %d more\n", len(result.Instruments)-10)
		}
	}
	fmt.Println()
	fmt.Println("Success!")
}
