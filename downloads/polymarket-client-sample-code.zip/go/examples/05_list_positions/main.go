// Example 05: List Positions
//
// Demonstrates listing positions for a trading account.
package main

import (
	"fmt"
	"os"

	"github.com/polymarket/client-sample-code/go/config"
	"github.com/polymarket/client-sample-code/go/rest"
)

func main() {
	fmt.Println("============================================================")
	fmt.Println("Example 05: List Positions")
	fmt.Println("============================================================")
	fmt.Println()

	// Load configuration
	cfg := config.MustLoad()

	// Create REST client
	client := rest.NewClient(cfg)

	// List positions
	fmt.Printf("Listing positions for account: %s\n", cfg.Account)
	result, err := client.ListPositions(cfg.Account)
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: %v\n", err)
		os.Exit(1)
	}

	if len(result.Positions) == 0 {
		fmt.Println("  No positions found")
	} else {
		fmt.Printf("  Found %d position(s):\n", len(result.Positions))
		for i, pos := range result.Positions {
			fmt.Printf("    %d. %s: net=%d, bought=%d, sold=%d\n",
				i+1, pos.Symbol, pos.NetPosition, pos.QtyBought, pos.QtySold)
		}
	}
	fmt.Println()
	fmt.Println("Success!")
}
