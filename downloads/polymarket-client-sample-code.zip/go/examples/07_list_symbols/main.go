// Example 07: List Symbols
//
// Demonstrates listing all available trading symbols.
package main

import (
	"fmt"
	"os"

	"github.com/polymarket/client-sample-code/go/config"
	"github.com/polymarket/client-sample-code/go/rest"
)

func main() {
	fmt.Println("============================================================")
	fmt.Println("Example 07: List Symbols")
	fmt.Println("============================================================")
	fmt.Println()

	// Load configuration
	cfg := config.MustLoad()

	// Create REST client
	client := rest.NewClient(cfg)

	// List symbols
	fmt.Println("Listing available symbols...")
	result, err := client.ListSymbols()
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: %v\n", err)
		os.Exit(1)
	}

	if len(result.Symbols) == 0 {
		fmt.Println("  No symbols found")
	} else {
		fmt.Printf("  Found %d symbol(s):\n", len(result.Symbols))
		// Show first 10
		limit := 10
		if len(result.Symbols) < limit {
			limit = len(result.Symbols)
		}
		for i := 0; i < limit; i++ {
			fmt.Printf("    %d. %s\n", i+1, result.Symbols[i])
		}
		if len(result.Symbols) > 10 {
			fmt.Printf("    ... and %d more\n", len(result.Symbols)-10)
		}
	}
	fmt.Println()
	fmt.Println("Success!")
}
