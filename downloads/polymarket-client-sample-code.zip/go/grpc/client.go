// Package grpc provides a gRPC client for the Polymarket Exchange API streaming endpoints.
package grpc

import (
	"context"
	"crypto/tls"
	"fmt"
	"strings"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials"
	"google.golang.org/grpc/metadata"

	"github.com/polymarket/client-sample-code/go/auth"
	"github.com/polymarket/client-sample-code/go/config"
	polymarketv1 "github.com/polymarket/client-sample-code/go/gen/polymarket/v1"
)

// Client is a gRPC client for the Polymarket Exchange API.
type Client struct {
	config *config.Config
	conn   *grpc.ClientConn

	// Service clients
	MarketData polymarketv1.MarketDataSubscriptionAPIClient
	DropCopy   polymarketv1.DropCopyAPIClient
	Positions  polymarketv1.PositionAPIClient
	Orders     polymarketv1.OrderEntryAPIClient
	Funding    polymarketv1.FundingAPIClient
}

// NewClient creates a new gRPC client and establishes a connection.
func NewClient(cfg *config.Config) (*Client, error) {
	// Parse server name from gRPC address for TLS
	serverName := cfg.GRPCAddr
	if idx := strings.Index(serverName, ":"); idx != -1 {
		serverName = serverName[:idx]
	}

	// TLS configuration
	tlsConfig := &tls.Config{
		MinVersion: tls.VersionTLS12,
		ServerName: serverName,
	}

	// Create connection with TLS credentials
	conn, err := grpc.NewClient(
		cfg.GRPCAddr,
		grpc.WithTransportCredentials(credentials.NewTLS(tlsConfig)),
		grpc.WithDefaultCallOptions(grpc.MaxCallRecvMsgSize(10*1024*1024)), // 10MB
	)
	if err != nil {
		return nil, fmt.Errorf("failed to connect to gRPC server: %w", err)
	}

	return &Client{
		config:     cfg,
		conn:       conn,
		MarketData: polymarketv1.NewMarketDataSubscriptionAPIClient(conn),
		DropCopy:   polymarketv1.NewDropCopyAPIClient(conn),
		Positions:  polymarketv1.NewPositionAPIClient(conn),
		Orders:     polymarketv1.NewOrderEntryAPIClient(conn),
		Funding:    polymarketv1.NewFundingAPIClient(conn),
	}, nil
}

// Close closes the gRPC connection.
func (c *Client) Close() error {
	if c.conn != nil {
		return c.conn.Close()
	}
	return nil
}

// AuthContext creates a context with authentication metadata.
func (c *Client) AuthContext(ctx context.Context) (context.Context, error) {
	token, _, err := auth.GetAccessToken(c.config)
	if err != nil {
		return nil, fmt.Errorf("failed to get auth token: %w", err)
	}

	md := metadata.New(map[string]string{
		"authorization":    "Bearer " + token,
		"x-participant-id": c.config.ParticipantID,
	})

	return metadata.NewOutgoingContext(ctx, md), nil
}

// Config returns the client configuration.
func (c *Client) Config() *config.Config {
	return c.config
}
