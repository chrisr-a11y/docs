// Package auth provides authentication for the Polymarket Exchange API.
package auth

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"

	"github.com/golang-jwt/jwt/v4"
	"github.com/google/uuid"
	"github.com/polymarket/client-sample-code/go/config"
)

// TokenResponse represents the authentication server token response.
type TokenResponse struct {
	AccessToken string `json:"access_token"`
	TokenType   string `json:"token_type"`
	ExpiresIn   int    `json:"expires_in"`
}

// tokenCache stores the cached token and expiration.
var tokenCache struct {
	sync.Mutex
	token     string
	expiresAt time.Time
}

// GetAccessToken retrieves an access token from the authentication server, using cache when possible.
// Returns the token and the number of seconds until expiration.
func GetAccessToken(cfg *config.Config) (string, int, error) {
	return GetAccessTokenWithRefresh(cfg, false)
}

// GetAccessTokenWithRefresh retrieves an access token, optionally forcing a refresh.
func GetAccessTokenWithRefresh(cfg *config.Config, forceRefresh bool) (string, int, error) {
	tokenCache.Lock()
	defer tokenCache.Unlock()

	// Check cache (with 60-second buffer)
	if !forceRefresh && tokenCache.token != "" && time.Now().Add(60*time.Second).Before(tokenCache.expiresAt) {
		remaining := int(time.Until(tokenCache.expiresAt).Seconds())
		return tokenCache.token, remaining, nil
	}

	// Create client assertion JWT
	assertion, err := CreateClientAssertion(cfg)
	if err != nil {
		return "", 0, fmt.Errorf("failed to create client assertion: %w", err)
	}

	// Exchange for access token
	tokenURL := fmt.Sprintf("https://%s/oauth/token", cfg.AuthDomain)
	data := url.Values{
		"client_id":             {cfg.ClientID},
		"client_assertion_type": {"urn:ietf:params:oauth:client-assertion-type:jwt-bearer"},
		"client_assertion":      {assertion},
		"audience":              {cfg.AuthAudience},
		"grant_type":            {"client_credentials"},
	}

	if cfg.Verbose {
		fmt.Printf("\n>>> AUTH TOKEN REQUEST\n")
		fmt.Printf("  POST %s\n", tokenURL)
		fmt.Printf("  client_id: %s\n", cfg.ClientID)
		fmt.Printf("  audience: %s\n", cfg.AuthAudience)
	}

	client := &http.Client{Timeout: 10 * time.Second}
	resp, err := client.PostForm(tokenURL, data)
	if err != nil {
		return "", 0, fmt.Errorf("authentication request failed: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		var errBody map[string]interface{}
		json.NewDecoder(resp.Body).Decode(&errBody)
		return "", 0, fmt.Errorf("authentication server returned %d: %v", resp.StatusCode, errBody)
	}

	var tokenResp TokenResponse
	if err := json.NewDecoder(resp.Body).Decode(&tokenResp); err != nil {
		return "", 0, fmt.Errorf("failed to parse token response: %w", err)
	}

	if tokenResp.AccessToken == "" {
		return "", 0, fmt.Errorf("no access_token in response")
	}

	// Update cache
	tokenCache.token = tokenResp.AccessToken
	tokenCache.expiresAt = time.Now().Add(time.Duration(tokenResp.ExpiresIn) * time.Second)

	if cfg.Verbose {
		fmt.Printf("\n<<< AUTH TOKEN RESPONSE\n")
		fmt.Printf("  Status: %d\n", resp.StatusCode)
		fmt.Printf("  Token length: %d\n", len(tokenResp.AccessToken))
		fmt.Printf("  Expires in: %ds\n", tokenResp.ExpiresIn)
	}

	return tokenResp.AccessToken, tokenResp.ExpiresIn, nil
}

// CreateClientAssertion creates a signed JWT for private_key_jwt authentication.
func CreateClientAssertion(cfg *config.Config) (string, error) {
	now := time.Now()
	claims := jwt.MapClaims{
		"iss": cfg.ClientID,
		"sub": cfg.ClientID,
		"aud": fmt.Sprintf("https://%s/oauth/token", cfg.AuthDomain),
		"iat": now.Unix(),
		"exp": now.Add(5 * time.Minute).Unix(),
		"jti": uuid.New().String(),
	}

	token := jwt.NewWithClaims(jwt.SigningMethodRS256, claims)
	signed, err := token.SignedString(cfg.PrivateKey)
	if err != nil {
		return "", fmt.Errorf("failed to sign JWT: %w", err)
	}

	return signed, nil
}

// ClearTokenCache clears the cached token, forcing the next request to get a fresh token.
func ClearTokenCache() {
	tokenCache.Lock()
	defer tokenCache.Unlock()
	tokenCache.token = ""
	tokenCache.expiresAt = time.Time{}
}

// BearerToken returns the authorization header value for API requests.
func BearerToken(cfg *config.Config) (string, error) {
	token, _, err := GetAccessToken(cfg)
	if err != nil {
		return "", err
	}
	return "Bearer " + token, nil
}

// DecodeToken decodes a JWT token without verification (for debugging).
func DecodeToken(tokenString string) (map[string]interface{}, error) {
	parts := strings.Split(tokenString, ".")
	if len(parts) != 3 {
		return nil, fmt.Errorf("invalid token format")
	}

	// Decode claims (second part)
	payload, err := jwt.DecodeSegment(parts[1])
	if err != nil {
		return nil, fmt.Errorf("failed to decode token payload: %w", err)
	}

	var claims map[string]interface{}
	if err := json.Unmarshal(payload, &claims); err != nil {
		return nil, fmt.Errorf("failed to parse claims: %w", err)
	}

	return claims, nil
}
