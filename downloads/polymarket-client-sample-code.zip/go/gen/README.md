# Generated Protocol Buffer Files

This directory contains pre-generated Go code from the Polymarket Exchange API protocol buffer definitions.

## Contents

- `polymarket/v1/*.pb.go` - Protocol buffer message types
- `polymarket/v1/*_grpc.pb.go` - gRPC service stubs
- `polymarket/v1/polymarketv1connect/*.connect.go` - Connect protocol stubs

## Usage

These files are already generated and ready to use. Import them in your Go code:

```go
import polymarketv1 "github.com/polymarket/client-sample-code/go/gen/polymarket/v1"
import "github.com/polymarket/client-sample-code/go/gen/polymarket/v1/polymarketv1connect"
```

## Regenerating (Advanced)

If you need to regenerate these files (e.g., if the proto definitions change), you'll need:

1. The proto source files from the Polymarket Exchange Gateway
2. Protocol buffer compiler (`protoc`)
3. Go protoc plugins:
   - `protoc-gen-go`
   - `protoc-gen-go-grpc`
   - `protoc-gen-connect-go`

Regeneration is typically not necessary for using this sample code.

## Source

These files were generated from the `polymarket/v1/*.proto` definitions in the Polymarket Exchange Gateway repository.
