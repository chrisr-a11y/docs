#!/bin/bash
#
# Sample Environment Configuration for Polymarket Exchange API - Go Client
#
# Copy this file and fill in your actual values:
#   cp sample_env.sh my_env.sh
#   # Edit my_env.sh with your credentials
#   source my_env.sh
#
# Then run the examples:
#   cd cmd/run_all && go run .
#

# =============================================================================
# Required Configuration
# =============================================================================

# Your Client ID (provided by Polymarket)
export POLYMARKET_CLIENT_ID="your-client-id-here"

# Path to your RSA private key (PEM format)
# This key must match the public key registered with Polymarket
export POLYMARKET_PRIVATE_KEY_PATH="/path/to/your/private_key.pem"

# API Base URL
# Preprod: https://api.preprod.polymarketexchange.com
# Production: https://api.polymarketexchange.com
export POLYMARKET_API_URL="https://api.preprod.polymarketexchange.com"

# Authentication Domain (provided by Polymarket)
# Preprod: auth.preprod.polymarketexchange.com
# Production: auth.polymarketexchange.com
export POLYMARKET_AUTH_DOMAIN="auth.preprod.polymarketexchange.com"

# Authentication Audience (matches API URL)
export POLYMARKET_AUTH_AUDIENCE="https://api.preprod.polymarketexchange.com"

# Your participant ID (format: firms/Your-Firm/users/your-user)
export POLYMARKET_PARTICIPANT_ID="firms/Your-Firm/users/your-user"

# Your trading account (format: firms/Your-Firm/accounts/your-trading-account)
export POLYMARKET_ACCOUNT="firms/Your-Firm/accounts/your-trading-account"

# =============================================================================
# Optional Configuration
# =============================================================================

# Symbol to use for order placement demo
# Default: SBLIX-KC-YES (Kansas City wins Super Bowl)
# Override with a valid symbol for your environment
export POLYMARKET_TEST_SYMBOL="SBLIX-KC-YES"

# gRPC endpoint address (if different from derived address)
# Default: derived from API URL (api.X -> grpc.X:443)
# export POLYMARKET_GRPC_ADDR="grpc.dev01.polymarketexchange.com:443"

# Enable verbose logging (true/false)
export POLYMARKET_VERBOSE="false"

# Request timeout in seconds
export POLYMARKET_TIMEOUT="30"
