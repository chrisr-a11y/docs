#!/bin/bash
# SplashIB Environment Configuration

export POLYMARKET_CLIENT_ID="oequU8cnWJYVnh0TIsfP5BFiN2vO4vHn"
export POLYMARKET_PRIVATE_KEY_PATH="/home/chris.rodier/isv-keys/dev01/isv-splashib-private.pem"
export POLYMARKET_API_URL="https://api.dev01.polymarketexchange.com"
export POLYMARKET_AUTH_DOMAIN="pmx-dev01.us.auth0.com"
export POLYMARKET_AUTH_AUDIENCE="https://api.dev01.polymarketexchange.com"

# Firm names for KYC user creation
export POLYMARKET_FIRM="ISV-Participant-Splashib"
export POLYMARKET_CLEARING_MEMBER="ISV-Splashib"

# User credentials - will be set by KYC onboarding
# Leave empty to trigger KYC, or set to use existing user
export POLYMARKET_PARTICIPANT_ID=""
export POLYMARKET_ACCOUNT=""

export POLYMARKET_TEST_SYMBOL="GWTEST-20251219"
export POLYMARKET_VERBOSE="true"
