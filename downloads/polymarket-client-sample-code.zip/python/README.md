# Polymarket Exchange API - Python Client Examples

This directory contains Python sample code demonstrating how to authenticate with and use the Polymarket Exchange API.

## Prerequisites

- Python 3.6 or higher
- Auth0 credentials (Client ID and private key) provided by Polymarket
- A registered trading account

## Installation

1. Install dependencies:

```bash
pip3 install -r requirements.txt
```

2. Configure your environment:

```bash
# Copy the sample environment file
cp sample_env.sh my_env.sh

# Edit with your actual credentials
nano my_env.sh  # or use your preferred editor

# Source the environment
source my_env.sh
```

## Configuration

The following environment variables are required:

| Variable | Description |
|----------|-------------|
| `POLYMARKET_CLIENT_ID` | Your Auth0 Client ID |
| `POLYMARKET_PRIVATE_KEY_PATH` | Path to your RSA private key (PEM format) |
| `POLYMARKET_API_URL` | API base URL (e.g., `https://api.dev01.polymarketexchange.com`) |
| `POLYMARKET_AUTH0_DOMAIN` | Auth0 domain (e.g., `pmx-dev01.us.auth0.com`) |
| `POLYMARKET_AUTH0_AUDIENCE` | Auth0 audience (matches API URL) |
| `POLYMARKET_PARTICIPANT_ID` | Your participant ID (e.g., `firms/Your-Firm/users/your-user`) |
| `POLYMARKET_ACCOUNT` | Your trading account (e.g., `firms/Your-Firm/accounts/your-account`) |

Optional variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `POLYMARKET_TEST_SYMBOL` | `SBLIX-KC-YES` | Symbol for order demo (Kansas City wins Super Bowl) |
| `POLYMARKET_VERBOSE` | `false` | Enable verbose logging |
| `POLYMARKET_TIMEOUT` | `30` | Request timeout (seconds) |

## Running Examples

### Run All Examples

```bash
cd examples
python3 run_all.py
```

### Run Individual Examples

```bash
# Health check (no authentication required)
python3 examples/01_health_check.py

# Get current user info
python3 examples/02_whoami.py

# List trading accounts
python3 examples/03_list_accounts.py

# Get account balance
python3 examples/04_get_balance.py

# List positions
python3 examples/05_list_positions.py

# List tradeable instruments
python3 examples/06_list_instruments.py

# List all symbols
python3 examples/07_list_symbols.py

# Search order history
python3 examples/08_search_orders.py

# List users in firm
python3 examples/09_list_users.py

# Place and cancel order (safe demo)
python3 examples/10_place_and_cancel_order.py
```

## File Structure

```
python/
├── README.md           # This file
├── requirements.txt    # Python dependencies
├── sample_env.sh       # Sample environment configuration
├── config.py           # Configuration loading and validation
├── auth.py             # Auth0 authentication (private_key_jwt)
├── api_client.py       # REST API client
└── examples/
    ├── 01_health_check.py      # Health check (no auth)
    ├── 02_whoami.py            # Get current user
    ├── 03_list_accounts.py     # List accounts
    ├── 04_get_balance.py       # Get balance
    ├── 05_list_positions.py    # List positions
    ├── 06_list_instruments.py  # List instruments
    ├── 07_list_symbols.py      # List symbols
    ├── 08_search_orders.py     # Search orders
    ├── 09_list_users.py        # List users
    ├── 10_place_and_cancel_order.py  # Place and cancel order
    └── run_all.py              # Run all examples
```

## Using the API Client in Your Code

```python
from config import load_config
from api_client import PolymarketClient

# Load configuration from environment
config = load_config()

# Create client
client = PolymarketClient(config)

# Make API calls
status, result = client.health()
print(f"Health: {result}")

status, result = client.whoami()
print(f"User: {result.get('user')}")

status, result = client.get_balance(config.account, "USD")
print(f"Balance: ${float(result.get('balance', 0)):,.2f}")
```

## Authentication Flow

This client uses **private_key_jwt** authentication with Auth0:

1. Create a signed JWT using your RSA private key
2. Exchange the JWT for an access token at Auth0
3. Use the access token for API requests

The client handles token caching and automatic refresh.

## Troubleshooting

### "Private key file not found"

Ensure `POLYMARKET_PRIVATE_KEY_PATH` points to a valid PEM file:

```bash
# Check the file exists
ls -la $POLYMARKET_PRIVATE_KEY_PATH

# Verify it's a valid RSA private key
openssl rsa -in $POLYMARKET_PRIVATE_KEY_PATH -check -noout
```

### "Missing required environment variables"

Source your environment file before running:

```bash
source my_env.sh
python3 examples/run_all.py
```

### "Auth0 returned 401"

- Verify your Client ID is correct
- Ensure your private key matches the public key registered with Auth0
- Check that your credentials haven't expired

### Connection timeout

- Verify the API URL is correct
- Check network connectivity
- Try increasing `POLYMARKET_TIMEOUT`

## Support

For API documentation, see: https://docs.polymarketexchange.com/

For issues with this sample code, contact your Polymarket representative.
