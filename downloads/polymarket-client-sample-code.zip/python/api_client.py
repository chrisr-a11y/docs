#!/usr/bin/env python3
"""
REST API client for Polymarket Exchange API.

Provides a clean interface to all API endpoints with automatic token management.
"""

import json
import time
import urllib.request
import urllib.error
from typing import Any, Dict, Optional, Tuple

from config import Config
from auth import get_access_token


class PolymarketClient:
    """Client for Polymarket Exchange API."""

    def __init__(self, config: Config):
        """
        Initialize the API client.

        Args:
            config: Configuration object with API settings
        """
        self.config = config
        self._token: Optional[str] = None
        self._token_expires: float = 0

    def _ensure_token(self) -> str:
        """Get or refresh access token."""
        if time.time() >= self._token_expires - 60:  # 60 second buffer
            self._token, expires_in = get_access_token(self.config)
            self._token_expires = time.time() + expires_in
        return self._token

    def _request(
        self,
        method: str,
        path: str,
        body: Optional[Dict] = None,
        auth: bool = True
    ) -> Tuple[int, Dict]:
        """
        Make an HTTP request to the API.

        Args:
            method: HTTP method (GET, POST, etc.)
            path: API path (e.g., /v1/health)
            body: Request body for POST/PATCH requests
            auth: Whether to include authentication

        Returns:
            Tuple of (status_code, response_dict)
        """
        url = f"{self.config.api_url}{path}"

        headers = {"Content-Type": "application/json"}
        if auth:
            token = self._ensure_token()
            headers["Authorization"] = f"Bearer {token}"
            headers["x-participant-id"] = self.config.participant_id

        data = None
        if body is not None:
            data = json.dumps(body).encode("utf-8")

        if self.config.verbose:
            print(f"\n>>> {method} {url}")
            if body:
                print(f"  Body: {json.dumps(body, indent=2)}")

        req = urllib.request.Request(url, data=data, headers=headers, method=method)

        try:
            with urllib.request.urlopen(req, timeout=self.config.timeout) as resp:
                response_body = resp.read()
                result = json.loads(response_body) if response_body else {}

                if self.config.verbose:
                    print(f"\n<<< {resp.status}")
                    print(f"  Response: {json.dumps(result, indent=2)[:500]}")

                return resp.status, result

        except urllib.error.HTTPError as e:
            error_body = e.read().decode()
            try:
                result = json.loads(error_body)
            except json.JSONDecodeError:
                result = {"error": error_body}

            if self.config.verbose:
                print(f"\n<<< {e.code}")
                print(f"  Error: {error_body[:500]}")

            return e.code, result

        except urllib.error.URLError as e:
            return 0, {"error": str(e.reason)}

    def _get(self, path: str, auth: bool = True) -> Tuple[int, Dict]:
        """Make a GET request."""
        return self._request("GET", path, auth=auth)

    def _post(self, path: str, body: Dict, auth: bool = True) -> Tuple[int, Dict]:
        """Make a POST request."""
        return self._request("POST", path, body=body, auth=auth)

    # =========================================================================
    # Health API (No Auth Required)
    # =========================================================================

    def health(self) -> Tuple[int, Dict]:
        """
        Check API health status.

        No authentication required.

        Returns:
            Tuple of (status_code, {"status": "ok"})
        """
        return self._get("/v1/health", auth=False)

    # =========================================================================
    # Accounts API
    # =========================================================================

    def whoami(self) -> Tuple[int, Dict]:
        """
        Get current user information.

        Returns:
            Tuple of (status_code, {"user": "...", "firm": "..."})
        """
        return self._get("/v1/whoami")

    def list_accounts(self) -> Tuple[int, Dict]:
        """
        List trading accounts for the current user.

        Returns:
            Tuple of (status_code, {"accounts": [...]})
        """
        return self._get("/v1/accounts")

    def list_users(self) -> Tuple[int, Dict]:
        """
        List users in the firm.

        Returns:
            Tuple of (status_code, {"users": [...]})
        """
        return self._get("/v1/users")

    # =========================================================================
    # Positions API
    # =========================================================================

    def get_balance(self, account: str, currency: str = "USD") -> Tuple[int, Dict]:
        """
        Get account balance for a specific currency.

        Args:
            account: Account name (e.g., firms/Your-Firm/accounts/your-account)
            currency: Currency code (default: USD)

        Returns:
            Tuple of (status_code, {"balance": "..."})
        """
        return self._post("/v1/positions/balance", {
            "name": account,
            "currency": currency
        })

    def list_balances(self, account: str) -> Tuple[int, Dict]:
        """
        List all currency balances for an account.

        Args:
            account: Account name

        Returns:
            Tuple of (status_code, {"balances": [...]})
        """
        return self._post("/v1/positions/balances", {"name": account})

    def list_positions(self, account: str) -> Tuple[int, Dict]:
        """
        List all positions for an account.

        Args:
            account: Account name

        Returns:
            Tuple of (status_code, {"positions": [...]})
        """
        return self._get(f"/v1/positions?name={account}")

    # =========================================================================
    # Reference Data API
    # =========================================================================

    def list_instruments(self, symbols: Optional[list] = None) -> Tuple[int, Dict]:
        """
        List tradeable instruments.

        Args:
            symbols: Optional list of symbols to filter by

        Returns:
            Tuple of (status_code, {"instruments": [...]})
        """
        return self._post("/v1/refdata/instruments", {"symbols": symbols or []})

    def list_symbols(self) -> Tuple[int, Dict]:
        """
        List all available symbols on the exchange.

        Returns:
            Tuple of (status_code, {"symbols": [...]})
        """
        return self._post("/v1/refdata/symbols", {})

    # =========================================================================
    # Report API (Order History)
    # =========================================================================

    def search_orders(
        self,
        account: str,
        page_size: int = 100,
        page_token: str = ""
    ) -> Tuple[int, Dict]:
        """
        Search historical orders.

        Args:
            account: Account name
            page_size: Number of orders per page (default: 100)
            page_token: Token for pagination

        Returns:
            Tuple of (status_code, {"orders": [...], "next_page_token": "..."})
        """
        body = {
            "account": account,
            "page_size": page_size,
        }
        if page_token:
            body["page_token"] = page_token
        return self._post("/v1/report/orders/search", body)

    # =========================================================================
    # Trading API
    # =========================================================================

    def place_order(
        self,
        symbol: str,
        side: str,
        order_type: str,
        quantity: int,
        price: int,
        account: str,
        clord_id: str,
        time_in_force: str = "TIME_IN_FORCE_DAY"
    ) -> Tuple[int, Dict]:
        """
        Place a trading order.

        Args:
            symbol: Instrument symbol (e.g., SBLIX-KC-YES)
            side: SIDE_BUY or SIDE_SELL
            order_type: ORDER_TYPE_LIMIT or ORDER_TYPE_MARKET
            quantity: Order quantity
            price: Order price in cents (e.g., 1 = $0.01)
            account: Account name
            clord_id: Unique client order ID
            time_in_force: Order duration (default: TIME_IN_FORCE_DAY)

        Returns:
            Tuple of (status_code, {"order_id": "...", ...})
        """
        return self._post("/v1/trading/orders", {
            "type": order_type,
            "side": side,
            "order_qty": quantity,
            "symbol": symbol,
            "price": price,
            "time_in_force": time_in_force,
            "clord_id": clord_id,
            "account": account,
        })

    def cancel_order(
        self,
        order_id: str,
        account: str,
        symbol: str
    ) -> Tuple[int, Dict]:
        """
        Cancel a working order.

        Args:
            order_id: The order ID to cancel
            account: Account name
            symbol: Instrument symbol

        Returns:
            Tuple of (status_code, response_dict)
        """
        return self._post("/v1/trading/orders/cancel", {
            "order_id": order_id,
            "account": account,
            "symbol": symbol,
        })


if __name__ == "__main__":
    # Test the client
    from config import load_config

    config = load_config()
    client = PolymarketClient(config)

    print("Testing API client...")

    # Test health endpoint
    status, result = client.health()
    print(f"\nHealth check: {status}")
    print(f"  Result: {result}")

    # Test whoami endpoint
    status, result = client.whoami()
    print(f"\nWhoAmI: {status}")
    print(f"  Result: {result}")
