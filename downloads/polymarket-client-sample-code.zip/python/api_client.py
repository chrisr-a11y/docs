#!/usr/bin/env python3
"""
REST API client for Polymarket Exchange API.

Provides a clean interface to all API endpoints with automatic token management.
"""

import json
import socket
import time
import urllib.request
import urllib.error
from typing import Any, Dict, Optional, Tuple
from urllib.parse import urlparse

from config import Config
from auth import get_access_token

# External DNS resolution for environments with split-horizon DNS
try:
    import dns.resolver
    DNS_AVAILABLE = True
except ImportError:
    DNS_AVAILABLE = False

EXTERNAL_DNS_SERVERS = ['8.8.8.8', '1.1.1.1']
_dns_cache: Dict[str, str] = {}

def resolve_with_external_dns(hostname: str) -> Optional[str]:
    """Resolve hostname using external DNS (Google/Cloudflare)."""
    if not DNS_AVAILABLE:
        return None
    if hostname in _dns_cache:
        return _dns_cache[hostname]
    try:
        resolver = dns.resolver.Resolver()
        resolver.nameservers = EXTERNAL_DNS_SERVERS
        resolver.timeout = 5
        resolver.lifetime = 10
        answers = resolver.resolve(hostname, 'A')
        for rdata in answers:
            ip = str(rdata)
            _dns_cache[hostname] = ip
            return ip
    except Exception:
        return None
    return None

def install_external_dns():
    """Install custom DNS resolver for urllib."""
    if not DNS_AVAILABLE:
        print("Warning: dnspython not installed. Run: pip install dnspython")
        return False

    original_getaddrinfo = socket.getaddrinfo

    def patched_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
        ip = resolve_with_external_dns(host)
        if ip:
            return [(socket.AF_INET, socket.SOCK_STREAM, 6, '', (ip, port))]
        return original_getaddrinfo(host, port, family, type, proto, flags)

    socket.getaddrinfo = patched_getaddrinfo
    print("External DNS resolver installed (using 8.8.8.8, 1.1.1.1)")
    return True

# Install DNS resolver on module load
install_external_dns()


class PolymarketClient:
    """Client for Polymarket Exchange API."""

    def __init__(self, config: Config):
        """
        Initialize the API client.

        Args:
            config: Configuration object with API settings
        """
        self.config = config
        self._token: Optional[str] = None
        self._token_expires: float = 0

    def _ensure_token(self) -> str:
        """Get or refresh access token."""
        if time.time() >= self._token_expires - 60:  # 60 second buffer
            self._token, expires_in = get_access_token(self.config)
            self._token_expires = time.time() + expires_in
        return self._token

    def _request(
        self,
        method: str,
        path: str,
        body: Optional[Dict] = None,
        auth: bool = True
    ) -> Tuple[int, Dict]:
        """
        Make an HTTP request to the API.

        Args:
            method: HTTP method (GET, POST, etc.)
            path: API path (e.g., /v1/health)
            body: Request body for POST/PATCH requests
            auth: Whether to include authentication

        Returns:
            Tuple of (status_code, response_dict)
        """
        url = f"{self.config.api_url}{path}"

        headers = {"Content-Type": "application/json"}
        if auth:
            token = self._ensure_token()
            headers["Authorization"] = f"Bearer {token}"
            # Only send participant ID if set (not required for RefData endpoints)
            if self.config.participant_id:
                headers["x-participant-id"] = self.config.participant_id

        data = None
        if body is not None:
            data = json.dumps(body).encode("utf-8")

        if self.config.verbose:
            print(f"\n>>> {method} {url}")
            if body:
                print(f"  Body: {json.dumps(body, indent=2)}")

        req = urllib.request.Request(url, data=data, headers=headers, method=method)

        try:
            with urllib.request.urlopen(req, timeout=self.config.timeout) as resp:
                response_body = resp.read()
                result = json.loads(response_body) if response_body else {}

                if self.config.verbose:
                    print(f"\n<<< {resp.status}")
                    print(f"  Response: {json.dumps(result, indent=2)[:500]}")

                return resp.status, result

        except urllib.error.HTTPError as e:
            error_body = e.read().decode()
            try:
                result = json.loads(error_body)
            except json.JSONDecodeError:
                result = {"error": error_body}

            if self.config.verbose:
                print(f"\n<<< {e.code}")
                print(f"  Error: {error_body[:500]}")

            return e.code, result

        except urllib.error.URLError as e:
            return 0, {"error": str(e.reason)}

    def _get(self, path: str, auth: bool = True) -> Tuple[int, Dict]:
        """Make a GET request."""
        return self._request("GET", path, auth=auth)

    def _post(self, path: str, body: Dict, auth: bool = True) -> Tuple[int, Dict]:
        """Make a POST request."""
        return self._request("POST", path, body=body, auth=auth)

    # =========================================================================
    # Health API (No Auth Required)
    # =========================================================================

    def health(self) -> Tuple[int, Dict]:
        """
        Check API health status.

        No authentication required.

        Returns:
            Tuple of (status_code, {"status": "ok"})
        """
        return self._get("/v1/health", auth=False)

    # =========================================================================
    # Accounts API
    # =========================================================================

    def whoami(self) -> Tuple[int, Dict]:
        """
        Get current user information.

        Returns:
            Tuple of (status_code, {"user": "...", "firm": "..."})
        """
        return self._get("/v1/whoami")

    def list_accounts(self) -> Tuple[int, Dict]:
        """
        List trading accounts for the current user.

        Returns:
            Tuple of (status_code, {"accounts": [...]})
        """
        return self._get("/v1/accounts")

    def list_users(self) -> Tuple[int, Dict]:
        """
        List users in the firm.

        Returns:
            Tuple of (status_code, {"users": [...]})
        """
        return self._get("/v1/users")

    # =========================================================================
    # Positions API
    # =========================================================================

    def get_balance(self, account: str, currency: str = "USD") -> Tuple[int, Dict]:
        """
        Get account balance for a specific currency.

        Args:
            account: Account name (e.g., firms/Your-Firm/accounts/your-account)
            currency: Currency code (default: USD)

        Returns:
            Tuple of (status_code, {"balance": "..."})
        """
        return self._post("/v1/positions/balance", {
            "name": account,
            "currency": currency
        })

    def list_balances(self, account: str) -> Tuple[int, Dict]:
        """
        List all currency balances for an account.

        Args:
            account: Account name

        Returns:
            Tuple of (status_code, {"balances": [...]})
        """
        return self._post("/v1/positions/balances", {"name": account})

    def list_positions(self, account: str) -> Tuple[int, Dict]:
        """
        List all positions for an account.

        Args:
            account: Account name

        Returns:
            Tuple of (status_code, {"positions": [...]})
        """
        return self._get(f"/v1/positions?name={account}")

    # =========================================================================
    # Reference Data API (No participant_id required)
    # =========================================================================

    def list_instruments(self, symbols: Optional[list] = None) -> Tuple[int, Dict]:
        """
        List tradeable instruments.

        Note: This endpoint requires authentication but does NOT require a
        participant_id. You can call this before KYC onboarding is complete.

        Args:
            symbols: Optional list of symbols to filter by

        Returns:
            Tuple of (status_code, {"instruments": [...]})
        """
        return self._post("/v1/refdata/instruments", {"symbols": symbols or []})

    def list_symbols(self) -> Tuple[int, Dict]:
        """
        List all available symbols on the exchange.

        Note: This endpoint requires authentication but does NOT require a
        participant_id. You can call this before KYC onboarding is complete.

        Returns:
            Tuple of (status_code, {"symbols": [...]})
        """
        return self._post("/v1/refdata/symbols", {})

    # =========================================================================
    # Report API (Order History)
    # =========================================================================

    def search_orders(
        self,
        account: str,
        page_size: int = 100,
        page_token: str = ""
    ) -> Tuple[int, Dict]:
        """
        Search historical orders.

        Args:
            account: Account name
            page_size: Number of orders per page (default: 100)
            page_token: Token for pagination

        Returns:
            Tuple of (status_code, {"orders": [...], "next_page_token": "..."})
        """
        body = {
            "account": account,
            "page_size": page_size,
        }
        if page_token:
            body["page_token"] = page_token
        return self._post("/v1/report/orders/search", body)

    # =========================================================================
    # Trading API
    # =========================================================================

    def place_order(
        self,
        symbol: str,
        side: str,
        order_type: str,
        quantity: int,
        price: int,
        account: str,
        clord_id: str,
        time_in_force: str = "TIME_IN_FORCE_DAY"
    ) -> Tuple[int, Dict]:
        """
        Place a trading order.

        Args:
            symbol: Instrument symbol (e.g., SBLIX-KC-YES)
            side: SIDE_BUY or SIDE_SELL
            order_type: ORDER_TYPE_LIMIT or ORDER_TYPE_MARKET
            quantity: Order quantity
            price: Order price in cents (e.g., 1 = $0.01)
            account: Account name
            clord_id: Unique client order ID
            time_in_force: Order duration (default: TIME_IN_FORCE_DAY)

        Returns:
            Tuple of (status_code, {"order_id": "...", ...})
        """
        return self._post("/v1/trading/orders", {
            "type": order_type,
            "side": side,
            "order_qty": quantity,
            "symbol": symbol,
            "price": price,
            "time_in_force": time_in_force,
            "clord_id": clord_id,
            "account": account,
        })

    def cancel_order(
        self,
        order_id: str,
        account: str,
        symbol: str
    ) -> Tuple[int, Dict]:
        """
        Cancel a working order.

        Args:
            order_id: The order ID to cancel
            account: Account name
            symbol: Instrument symbol

        Returns:
            Tuple of (status_code, response_dict)
        """
        return self._post("/v1/trading/orders/cancel", {
            "order_id": order_id,
            "account": account,
            "symbol": symbol,
        })

    # =========================================================================
    # KYC API (User Onboarding)
    # =========================================================================

    def kyc_status(self, external_id: str) -> Tuple[int, Dict]:
        """
        Get KYC status for a user.

        Args:
            external_id: External user ID

        Returns:
            Tuple of (status_code, {"status": {...}})
        """
        return self._get(f"/v1/kyc/status?external_id={external_id}")

    def kyc_start(
        self,
        user_id: str,
        first_name: str,
        last_name: str,
        date_of_birth: str,
        email: str,
        phone_number: str,
        ssn: str,
        address: Dict
    ) -> Tuple[int, Dict]:
        """
        Start KYC verification for a new user.

        For Socure sandbox testing, use these DOBs:

        Consumer Onboarding (instant decision):
        - 1985-10-02: Auto-approve (ACCEPT)
        - 1985-09-04: Reject
        - 1985-09-29: Review

        DocV (Document Verification) - triggers DocV flow, outcome after completion:
        - 1985-09-02: DocV Accept
        - 1985-09-05: DocV Reject
        - 1985-09-26: DocV Review
        - 1985-09-01: DocV Resubmit

        Reference: Socure ID+ Test Cases PDF

        Args:
            user_id: Unique user identifier
            first_name: User's first name
            last_name: User's last name
            date_of_birth: DOB in YYYY-MM-DD format
            email: User's email
            phone_number: Phone in +1XXXXXXXXXX format
            ssn: Social security number
            address: Dict with address_line_1, city, state, postal_code, country

        Returns:
            Tuple of (status_code, response with participant_id and account)
        """
        return self._post("/v1/kyc/start", {
            "user_id": user_id,
            "first_name": first_name,
            "last_name": last_name,
            "date_of_birth": date_of_birth,
            "email": email,
            "phone_number": phone_number,
            "ssn": ssn,
            "address": address,
        })


if __name__ == "__main__":
    # Test the client
    from config import load_config

    config = load_config()
    client = PolymarketClient(config)

    print("Testing API client...")

    # Test health endpoint
    status, result = client.health()
    print(f"\nHealth check: {status}")
    print(f"  Result: {result}")

    # Test whoami endpoint
    status, result = client.whoami()
    print(f"\nWhoAmI: {status}")
    print(f"  Result: {result}")
