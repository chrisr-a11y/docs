#!/usr/bin/env python3
"""
Run All Examples

Runs all example scripts in sequence to validate API connectivity
and demonstrate all available endpoints.
"""

import sys
import os
import subprocess
import time

# Example scripts to run (in order)
EXAMPLES = [
    ("01_health_check.py", "Health Check (no auth)"),
    ("02_whoami.py", "Who Am I"),
    ("03_list_accounts.py", "List Accounts"),
    ("04_get_balance.py", "Get Balance"),
    ("05_list_positions.py", "List Positions"),
    ("06_list_instruments.py", "List Instruments"),
    ("07_list_symbols.py", "List Symbols"),
    ("08_search_orders.py", "Search Orders"),
    ("09_list_users.py", "List Users"),
    ("10_place_and_cancel_order.py", "Place and Cancel Order"),
]


def run_example(script: str, description: str) -> bool:
    """Run a single example script."""
    script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), script)

    result = subprocess.run(
        [sys.executable, script_path],
        capture_output=False,
    )

    return result.returncode == 0


def main():
    print("=" * 70)
    print("  Polymarket Exchange API - Running All Examples")
    print("=" * 70)
    print()

    # Track results
    passed = 0
    failed = 0
    failed_examples = []

    for script, description in EXAMPLES:
        print(f"\n{'─' * 70}")
        print(f"Running: {description}")
        print(f"{'─' * 70}\n")

        success = run_example(script, description)

        if success:
            passed += 1
            print(f"\n✓ {description} - PASSED")
        else:
            failed += 1
            failed_examples.append(description)
            print(f"\n✗ {description} - FAILED")

        time.sleep(0.5)  # Small delay between examples

    # Summary
    print()
    print("=" * 70)
    print("  SUMMARY")
    print("=" * 70)
    print()
    print(f"  Total:  {len(EXAMPLES)}")
    print(f"  Passed: {passed}")
    print(f"  Failed: {failed}")

    if failed_examples:
        print()
        print("  Failed examples:")
        for ex in failed_examples:
            print(f"    - {ex}")

    print()

    if failed == 0:
        print("All examples completed successfully!")
        return 0
    else:
        print(f"{failed} example(s) failed. Please check the output above.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
