#!/usr/bin/env python3
"""
Run All Examples

Runs all example scripts in sequence to validate API connectivity
and demonstrate all available endpoints.

Usage:
    python3 run_all.py           # Run REST examples only
    python3 run_all.py --streaming  # Start gRPC streams, then run REST examples
"""

import sys
import os
import subprocess
import time
import argparse
import threading

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# REST Example scripts to run (in order)
REST_EXAMPLES = [
    ("01_health_check.py", "Health Check (no auth)"),
    ("02_whoami.py", "Who Am I"),
    ("03_list_accounts.py", "List Accounts"),
    ("04_get_balance.py", "Get Balance"),
    ("05_list_positions.py", "List Positions"),
    ("06_list_instruments.py", "List Instruments"),
    ("07_list_symbols.py", "List Symbols"),
    ("08_search_orders.py", "Search Orders"),
    ("09_list_users.py", "List Users"),
    ("10_place_and_cancel_order.py", "Place and Cancel Order"),
]


class StreamingStats:
    """Track streaming subscription statistics."""
    def __init__(self):
        self.market_data_count = 0
        self.order_count = 0
        self.position_count = 0
        self.errors = []


def run_market_data_stream(client, symbol, stats, stop_event):
    """Background thread for market data streaming."""
    try:
        for response in client.subscribe_market_data([symbol], depth=5):
            if stop_event.is_set():
                break
            stats.market_data_count += 1
    except Exception as e:
        stats.errors.append(f"Market data: {e}")


def run_order_stream(client, account, stats, stop_event):
    """Background thread for order streaming."""
    try:
        for response in client.subscribe_orders([account]):
            if stop_event.is_set():
                break
            stats.order_count += 1
    except Exception as e:
        stats.errors.append(f"Orders: {e}")


def run_position_stream(client, account, stats, stop_event):
    """Background thread for position streaming."""
    try:
        for response in client.subscribe_positions([account]):
            if stop_event.is_set():
                break
            stats.position_count += 1
    except Exception as e:
        stats.errors.append(f"Positions: {e}")


def run_example(script: str, description: str) -> bool:
    """Run a single example script."""
    script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), script)

    result = subprocess.run(
        [sys.executable, script_path],
        capture_output=False,
    )

    return result.returncode == 0


def main():
    parser = argparse.ArgumentParser(description='Run Polymarket API examples')
    parser.add_argument(
        '--streaming',
        action='store_true',
        help='Start background gRPC streaming subscriptions while running REST examples'
    )
    args = parser.parse_args()

    print("=" * 70)
    print("  Polymarket Exchange API - Running All Examples")
    if args.streaming:
        print("  (with background gRPC streaming)")
    print("=" * 70)
    print()

    # Initialize streaming if requested
    grpc_client = None
    stats = None
    stop_event = None
    threads = []

    if args.streaming:
        try:
            from config import load_config
            from grpc_client import PolymarketGrpcClient

            config = load_config()
            grpc_client = PolymarketGrpcClient(config)
            stats = StreamingStats()
            stop_event = threading.Event()

            print("Starting background gRPC subscriptions...")
            print(f"  gRPC Address: {config.grpc_addr}")
            print(f"  Symbol: {config.test_symbol}")
            print(f"  Account: {config.account}")
            print()

            # Start market data thread
            md_thread = threading.Thread(
                target=run_market_data_stream,
                args=(grpc_client, config.test_symbol, stats, stop_event),
                daemon=True
            )
            md_thread.start()
            threads.append(md_thread)
            print("  Market data subscription started")

            # Start order thread
            order_thread = threading.Thread(
                target=run_order_stream,
                args=(grpc_client, config.account, stats, stop_event),
                daemon=True
            )
            order_thread.start()
            threads.append(order_thread)
            print("  Order subscription started")

            # Start position thread
            pos_thread = threading.Thread(
                target=run_position_stream,
                args=(grpc_client, config.account, stats, stop_event),
                daemon=True
            )
            pos_thread.start()
            threads.append(pos_thread)
            print("  Position subscription started")

            print()
            # Give streams time to establish
            time.sleep(2)

        except Exception as e:
            print(f"WARNING: Could not start gRPC streaming: {e}")
            print("Continuing with REST examples only...")
            print()
            args.streaming = False

    # Track REST results
    passed = 0
    failed = 0
    failed_examples = []

    for script, description in REST_EXAMPLES:
        print(f"\n{'─' * 70}")
        print(f"Running: {description}")
        print(f"{'─' * 70}\n")

        success = run_example(script, description)

        if success:
            passed += 1
            print(f"\n  {description} - PASSED")
        else:
            failed += 1
            failed_examples.append(description)
            print(f"\n  {description} - FAILED")

        time.sleep(0.5)  # Small delay between examples

    # Stop streaming threads
    if args.streaming and stop_event:
        print()
        print("Stopping background streams...")
        stop_event.set()
        time.sleep(1)  # Give threads time to exit

        if grpc_client:
            grpc_client.close()

    # Summary
    print()
    print("=" * 70)
    print("  SUMMARY")
    print("=" * 70)
    print()
    print(f"  REST Examples: {passed}/{len(REST_EXAMPLES)} passed")

    if args.streaming and stats:
        print()
        print("  Streaming Statistics:")
        print(f"    Market data updates: {stats.market_data_count}")
        print(f"    Order updates: {stats.order_count}")
        print(f"    Position updates: {stats.position_count}")
        if stats.errors:
            print(f"    Errors: {len(stats.errors)}")
            for err in stats.errors:
                print(f"      - {err}")

    if failed_examples:
        print()
        print("  Failed examples:")
        for ex in failed_examples:
            print(f"    - {ex}")

    print()

    if failed == 0:
        print("All examples completed successfully!")
        return 0
    else:
        print(f"{failed} example(s) failed. Please check the output above.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
