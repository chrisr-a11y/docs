#!/usr/bin/env python3
"""
Example 06: List Instruments

Demonstrates listing tradeable instruments on the exchange.

Note: This endpoint requires authentication but does NOT require a participant_id.
You can call this before completing KYC onboarding.
"""

import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api_client import PolymarketClient
from config import load_config


def main():
    print("=" * 60)
    print("Example 06: List Instruments")
    print("=" * 60)
    print()

    # Load configuration
    config = load_config()

    # Create client
    client = PolymarketClient(config)

    # List instruments
    print("Listing tradeable instruments...")
    status, result = client.list_instruments()

    if status == 200:
        print(f"  Status: {status} OK")
        instruments = result.get("instruments", [])
        print(f"  Found {len(instruments)} instrument(s):")
        for inst in instruments[:10]:  # Show first 10
            symbol = inst.get("symbol", "N/A")
            state = inst.get("state", "N/A")
            print(f"    - {symbol} ({state})")
        if len(instruments) > 10:
            print(f"    ... and {len(instruments) - 10} more")
        return 0
    else:
        print(f"  Status: {status}")
        print(f"  Error: {result}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
