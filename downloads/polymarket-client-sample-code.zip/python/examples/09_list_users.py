#!/usr/bin/env python3
"""
Example 09: List Users

Demonstrates listing all users in the firm.
"""

import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api_client import PolymarketClient
from config import load_config


def main():
    print("=" * 60)
    print("Example 09: List Users")
    print("=" * 60)
    print()

    # Load configuration
    config = load_config()

    # Create client
    client = PolymarketClient(config)

    # List users
    print("Listing users in firm...")
    status, result = client.list_users()

    if status == 200:
        print(f"  Status: {status} OK")
        users = result.get("users", [])
        if users:
            print(f"  Found {len(users)} user(s):")
            for user in users:
                # User can be a string or an object with 'name' field
                if isinstance(user, str):
                    print(f"    - {user}")
                else:
                    name = user.get("name", "N/A")
                    print(f"    - {name}")
        else:
            print("  No users found.")
        return 0
    else:
        print(f"  Status: {status}")
        print(f"  Error: {result}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
