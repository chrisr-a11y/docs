#!/usr/bin/env python3
"""
Example 04: Get Balance

Demonstrates getting the USD balance for a trading account.
"""

import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api_client import PolymarketClient
from config import load_config


def main():
    print("=" * 60)
    print("Example 04: Get Balance")
    print("=" * 60)
    print()

    # Load configuration
    config = load_config()

    # Create client
    client = PolymarketClient(config)

    # Get balance
    print(f"Getting USD balance for account: {config.account}")
    status, result = client.get_balance(config.account, "USD")

    if status == 200:
        print(f"  Status: {status} OK")
        balance = result.get("balance", "0")
        print(f"  USD Balance: ${float(balance):,.2f}")
        return 0
    else:
        print(f"  Status: {status}")
        print(f"  Error: {result}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
