#!/usr/bin/env python3
"""
Example 03: List Accounts

Demonstrates listing all trading accounts available to the current user.
"""

import sys
import os
import json

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api_client import PolymarketClient
from config import load_config


def main():
    print("=" * 60)
    print("Example 03: List Accounts")
    print("=" * 60)
    print()

    # Load configuration
    config = load_config()

    # Create client
    client = PolymarketClient(config)

    # List accounts
    print("Listing trading accounts...")
    status, result = client.list_accounts()

    if status == 200:
        print(f"  Status: {status} OK")
        accounts = result.get("accounts", [])
        print(f"  Found {len(accounts)} account(s):")
        for account in accounts:
            # Account can be a string or an object with 'name' field
            if isinstance(account, str):
                print(f"    - {account}")
            else:
                name = account.get("name", "N/A")
                print(f"    - {name}")
        return 0
    else:
        print(f"  Status: {status}")
        print(f"  Error: {result}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
