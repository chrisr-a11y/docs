#!/usr/bin/env python3
"""
Example 13: gRPC Position Subscription

Demonstrates subscribing to real-time position updates via gRPC streaming.
Receives notifications when positions change due to trades.
"""

import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import grpc
from config import load_config
from grpc_client import PolymarketGrpcClient, format_position_update


def main():
    print("=" * 60)
    print("  Example 13: gRPC Position Subscription")
    print("=" * 60)
    print()

    # Load configuration
    config = load_config()

    print(f"Connecting to gRPC endpoint: {config.grpc_addr}")
    print(f"Subscribing to positions for account: {config.account}")
    print()

    try:
        with PolymarketGrpcClient(config) as client:
            print("Waiting for position updates (will show first 10 or timeout after 30s)...")
            print("-" * 60)

            count = 0
            for response in client.subscribe_positions([config.account]):
                formatted = format_position_update(response)
                print(f"  [{count + 1}] {formatted}")

                count += 1
                if count >= 10:
                    print()
                    print(f"Received {count} updates. Closing stream...")
                    break

    except grpc.RpcError as e:
        print(f"\nERROR: gRPC call failed")
        print(f"  Code: {e.code()}")
        print(f"  Details: {e.details()}")
        return 1
    except KeyboardInterrupt:
        print("\n\nInterrupted by user")
        return 0

    print()
    print("Position subscription example completed successfully!")
    return 0


if __name__ == "__main__":
    sys.exit(main())
