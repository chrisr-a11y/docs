#!/usr/bin/env python3
"""
Example 05: List Positions

Demonstrates listing all positions held by a trading account.
"""

import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api_client import PolymarketClient
from config import load_config


def main():
    print("=" * 60)
    print("Example 05: List Positions")
    print("=" * 60)
    print()

    # Load configuration
    config = load_config()

    # Create client
    client = PolymarketClient(config)

    # List positions
    print(f"Listing positions for account: {config.account}")
    status, result = client.list_positions(config.account)

    if status == 200:
        print(f"  Status: {status} OK")
        positions = result.get("positions", [])
        if positions:
            print(f"  Found {len(positions)} position(s):")
            for pos in positions:
                symbol = pos.get("symbol", "N/A")
                qty = pos.get("quantity", "0")
                print(f"    - {symbol}: {qty}")
        else:
            print("  No positions found.")
        return 0
    else:
        print(f"  Status: {status}")
        print(f"  Error: {result}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
