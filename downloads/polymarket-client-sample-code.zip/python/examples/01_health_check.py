#!/usr/bin/env python3
"""
Example 01: Health Check

Demonstrates the health check endpoint, which requires no authentication.
This is a good first test to verify connectivity to the API.
"""

import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api_client import PolymarketClient
from config import load_config


def main():
    print("=" * 60)
    print("Example 01: Health Check")
    print("=" * 60)
    print()

    # Load configuration (validates private key exists)
    config = load_config()

    # Create client
    client = PolymarketClient(config)

    # Call health endpoint (no auth required)
    print("Checking API health...")
    status, result = client.health()

    if status == 200:
        print(f"  Status: {status} OK")
        print(f"  Response: {result}")
        print("\nAPI is healthy!")
        return 0
    else:
        print(f"  Status: {status}")
        print(f"  Error: {result}")
        print("\nAPI health check failed!")
        return 1


if __name__ == "__main__":
    sys.exit(main())
