#!/usr/bin/env python3
"""
Configuration module for Polymarket Exchange API client.

Loads configuration from environment variables and validates the private key.
"""

import os
import sys
from dataclasses import dataclass
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa


@dataclass
class Config:
    """Configuration for Polymarket Exchange API client."""
    client_id: str
    private_key_path: str
    api_url: str
    auth0_domain: str
    auth0_audience: str
    participant_id: str
    account: str
    test_symbol: str
    verbose: bool = False
    timeout: int = 30


def validate_private_key(path: str) -> bool:
    """
    Verify private key file exists and is valid RSA.

    Args:
        path: Path to the private key PEM file

    Returns:
        True if valid, exits with error if not
    """
    if not os.path.exists(path):
        print(f"ERROR: Private key file not found: {path}", file=sys.stderr)
        print("Please set POLYMARKET_PRIVATE_KEY_PATH to the path of your private key.", file=sys.stderr)
        sys.exit(1)

    try:
        with open(path, 'rb') as f:
            key = serialization.load_pem_private_key(f.read(), password=None)
        if not isinstance(key, rsa.RSAPrivateKey):
            print("ERROR: Key must be an RSA private key", file=sys.stderr)
            sys.exit(1)
        return True
    except Exception as e:
        print(f"ERROR: Invalid private key: {e}", file=sys.stderr)
        sys.exit(1)


def load_config() -> Config:
    """
    Load configuration from environment variables.

    Required environment variables:
        POLYMARKET_CLIENT_ID: Auth0 client ID
        POLYMARKET_PRIVATE_KEY_PATH: Path to RSA private key PEM file
        POLYMARKET_API_URL: Base URL for the API
        POLYMARKET_AUTH0_DOMAIN: Auth0 domain
        POLYMARKET_AUTH0_AUDIENCE: Auth0 audience
        POLYMARKET_PARTICIPANT_ID: Your participant ID (e.g., firms/Your-Firm/users/your-user)
        POLYMARKET_ACCOUNT: Your trading account (e.g., firms/Your-Firm/accounts/your-account)

    Optional environment variables:
        POLYMARKET_TEST_SYMBOL: Symbol for order demo (default: SBLIX-KC-YES)
        POLYMARKET_VERBOSE: Enable verbose logging (default: false)
        POLYMARKET_TIMEOUT: Request timeout in seconds (default: 30)

    Returns:
        Config object with all settings
    """
    # Required variables
    required_vars = [
        "POLYMARKET_CLIENT_ID",
        "POLYMARKET_PRIVATE_KEY_PATH",
        "POLYMARKET_API_URL",
        "POLYMARKET_AUTH0_DOMAIN",
        "POLYMARKET_AUTH0_AUDIENCE",
        "POLYMARKET_PARTICIPANT_ID",
        "POLYMARKET_ACCOUNT",
    ]

    missing = [var for var in required_vars if not os.environ.get(var)]
    if missing:
        print("ERROR: Missing required environment variables:", file=sys.stderr)
        for var in missing:
            print(f"  - {var}", file=sys.stderr)
        print("\nPlease source your environment file (e.g., source sample_env.sh)", file=sys.stderr)
        sys.exit(1)

    private_key_path = os.environ["POLYMARKET_PRIVATE_KEY_PATH"]

    # Validate private key
    validate_private_key(private_key_path)

    return Config(
        client_id=os.environ["POLYMARKET_CLIENT_ID"],
        private_key_path=private_key_path,
        api_url=os.environ["POLYMARKET_API_URL"].rstrip("/"),
        auth0_domain=os.environ["POLYMARKET_AUTH0_DOMAIN"],
        auth0_audience=os.environ["POLYMARKET_AUTH0_AUDIENCE"],
        participant_id=os.environ["POLYMARKET_PARTICIPANT_ID"],
        account=os.environ["POLYMARKET_ACCOUNT"],
        test_symbol=os.environ.get("POLYMARKET_TEST_SYMBOL", "SBLIX-KC-YES"),
        verbose=os.environ.get("POLYMARKET_VERBOSE", "false").lower() == "true",
        timeout=int(os.environ.get("POLYMARKET_TIMEOUT", "30")),
    )


if __name__ == "__main__":
    # Test configuration loading
    config = load_config()
    print("Configuration loaded successfully:")
    print(f"  Client ID: {config.client_id[:8]}...")
    print(f"  Private Key: {config.private_key_path}")
    print(f"  API URL: {config.api_url}")
    print(f"  Auth0 Domain: {config.auth0_domain}")
    print(f"  Participant ID: {config.participant_id}")
    print(f"  Account: {config.account}")
    print(f"  Test Symbol: {config.test_symbol}")
