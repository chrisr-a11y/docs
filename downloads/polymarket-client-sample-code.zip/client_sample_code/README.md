# Polymarket Exchange API - Client Sample Code

This repository contains sample code demonstrating how to integrate with the Polymarket Exchange API.

## Overview

The Polymarket Exchange API provides programmatic access to:

- **Account Management**: View user info, list accounts
- **Positions & Balances**: Query balances and positions
- **Market Data**: List instruments, symbols, and market information
- **Trading**: Place and cancel orders
- **Reporting**: Search order and trade history

## Prerequisites

Before using these examples, you need:

1. **Auth0 Credentials** - Client ID provided by Polymarket
2. **RSA Key Pair** - Private key for signing JWTs (public key registered with Polymarket)
3. **Trading Account** - Participant ID and account name

## Available Languages

### Python

Full-featured Python client with examples for all API endpoints.

```bash
cd python
pip3 install -r requirements.txt
source sample_env.sh  # Configure your environment
python3 examples/run_all.py
```

See [python/README.md](python/README.md) for detailed instructions.

## Authentication

All examples use **private_key_jwt** authentication:

1. Sign a JWT with your RSA private key
2. Exchange the JWT for an Auth0 access token
3. Use the access token in API requests

This provides secure, credential-free authentication without exposing secrets.

## Quick Start

1. **Install dependencies**:
   ```bash
   cd python
   pip3 install -r requirements.txt
   ```

2. **Configure environment**:
   ```bash
   cp sample_env.sh my_env.sh
   # Edit my_env.sh with your credentials
   source my_env.sh
   ```

3. **Run examples**:
   ```bash
   python3 examples/run_all.py
   ```

## API Endpoints Demonstrated

| Example | Endpoint | Description |
|---------|----------|-------------|
| 01 | `GET /v1/health` | Health check (no auth) |
| 02 | `GET /v1/whoami` | Get current user info |
| 03 | `GET /v1/accounts` | List trading accounts |
| 04 | `POST /v1/positions/balance` | Get account balance |
| 05 | `GET /v1/positions` | List positions |
| 06 | `POST /v1/refdata/instruments` | List tradeable instruments |
| 07 | `POST /v1/refdata/symbols` | List all symbols |
| 08 | `POST /v1/report/orders/search` | Search order history |
| 09 | `GET /v1/users` | List users in firm |
| 10 | `POST /v1/trading/orders` | Place and cancel order |

## Documentation

- **API Reference**: https://docs.polymarketexchange.com/
- **Python Examples**: [python/README.md](python/README.md)

## Support

For questions about this sample code or the API, contact your Polymarket representative.
