#!/usr/bin/env python3
"""
Authentication module for Polymarket Exchange API.

Implements private_key_jwt authentication flow with Auth0.
"""

import json
import time
import uuid
import urllib.request
import urllib.error
from typing import Tuple, Optional

import jwt
from cryptography.hazmat.primitives import serialization

from config import Config


# Token cache
_token_cache: dict = {
    "token": None,
    "expires_at": 0
}


def create_client_assertion(client_id: str, domain: str, private_key_path: str) -> str:
    """
    Create a signed JWT for client authentication.

    Args:
        client_id: Auth0 client ID
        domain: Auth0 domain
        private_key_path: Path to RSA private key PEM file

    Returns:
        Signed JWT string
    """
    # Load private key
    with open(private_key_path, 'rb') as f:
        private_key = serialization.load_pem_private_key(f.read(), password=None)

    # Create claims
    now = int(time.time())
    claims = {
        "iss": client_id,
        "sub": client_id,
        "aud": f"https://{domain}/oauth/token",
        "iat": now,
        "exp": now + 300,  # 5 minutes
        "jti": str(uuid.uuid4()),
    }

    # Sign and return
    return jwt.encode(claims, private_key, algorithm="RS256")


def get_access_token(config: Config, force_refresh: bool = False) -> Tuple[str, int]:
    """
    Get an access token from Auth0, using cache when possible.

    Args:
        config: Configuration object
        force_refresh: If True, bypass cache and get fresh token

    Returns:
        Tuple of (access_token, expires_in_seconds)

    Raises:
        Exception: If token acquisition fails
    """
    global _token_cache

    # Check cache (with 60 second buffer)
    if not force_refresh and _token_cache["token"] and time.time() < _token_cache["expires_at"] - 60:
        remaining = int(_token_cache["expires_at"] - time.time())
        return _token_cache["token"], remaining

    # Create client assertion
    try:
        assertion = create_client_assertion(
            config.client_id,
            config.auth0_domain,
            config.private_key_path
        )
    except Exception as e:
        raise Exception(f"Failed to create client assertion: {e}")

    url = f"https://{config.auth0_domain}/oauth/token"
    payload = {
        "client_id": config.client_id,
        "client_assertion_type": "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
        "client_assertion": assertion,
        "audience": config.auth0_audience,
        "grant_type": "client_credentials",
    }

    if config.verbose:
        print(f"\n>>> AUTH0 TOKEN REQUEST")
        print(f"  POST {url}")
        print(f"  client_id: {config.client_id}")
        print(f"  audience: {config.auth0_audience}")

    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST"
    )

    try:
        with urllib.request.urlopen(req, timeout=config.timeout) as resp:
            body = resp.read()
            result = json.loads(body)
            token = result.get("access_token", "")
            expires_in = result.get("expires_in", 3600)

            if not token:
                raise Exception("No access_token in response")

            # Update cache
            _token_cache["token"] = token
            _token_cache["expires_at"] = time.time() + expires_in

            if config.verbose:
                print(f"\n<<< AUTH0 TOKEN RESPONSE")
                print(f"  Status: {resp.status}")
                print(f"  Token length: {len(token)}")
                print(f"  Expires in: {expires_in}s")

            return token, expires_in

    except urllib.error.HTTPError as e:
        error_body = e.read().decode()
        raise Exception(f"Auth0 returned {e.code}: {error_body}")
    except urllib.error.URLError as e:
        raise Exception(f"Auth0 request failed: {e.reason}")


def clear_token_cache():
    """Clear the token cache, forcing next request to get a fresh token."""
    global _token_cache
    _token_cache = {"token": None, "expires_at": 0}


if __name__ == "__main__":
    # Test authentication
    from config import load_config

    config = load_config()
    print("Testing authentication...")

    try:
        token, expires_in = get_access_token(config)
        print(f"SUCCESS: Got access token")
        print(f"  Token length: {len(token)}")
        print(f"  Expires in: {expires_in}s")
        print(f"  Token prefix: {token[:50]}...")
    except Exception as e:
        print(f"FAILED: {e}")
