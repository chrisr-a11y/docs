#!/bin/bash
# ISV205 Environment Configuration

export POLYMARKET_CLIENT_ID="hV6WOA8tA7iKL83sF9Hb1JRHiMN0KMKb"
export POLYMARKET_PRIVATE_KEY_PATH="/home/chris.rodier/isv-keys/dev01/isv-isv205-private.pem"
export POLYMARKET_API_URL="https://api.dev01.polymarketexchange.com"
export POLYMARKET_AUTH_DOMAIN="pmx-dev01.us.auth0.com"
export POLYMARKET_AUTH_AUDIENCE="https://api.dev01.polymarketexchange.com"

# Firm names for KYC user creation
export POLYMARKET_FIRM="ISV-Participant-Isv205"
export POLYMARKET_CLEARING_MEMBER="ISV-Isv205"

# User credentials - will be set by KYC onboarding
# Leave empty to trigger KYC, or set to use existing user
export POLYMARKET_PARTICIPANT_ID=""
export POLYMARKET_ACCOUNT=""

export POLYMARKET_TEST_SYMBOL="GWTEST-20251219"
export POLYMARKET_VERBOSE="true"
