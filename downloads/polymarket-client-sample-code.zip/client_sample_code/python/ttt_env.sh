#!/bin/bash
# TTT ISV Environment Configuration for Polymarket Exchange API

# Auth0/Authentication
export POLYMARKET_CLIENT_ID="qLWrhFNRWHtgB56DeUVcDHqPrlMxMDZQ"
export POLYMARKET_PRIVATE_KEY_PATH="/home/chris.rodier/isv-keys/dev01/isv-ttt-private.pem"
export POLYMARKET_API_URL="https://api.dev01.polymarketexchange.com"
export POLYMARKET_AUTH_DOMAIN="pmx-dev01.us.auth0.com"
export POLYMARKET_AUTH_AUDIENCE="https://api.dev01.polymarketexchange.com"

# Placeholder participant/account - TTT has no users yet
# These are required by config validation but won't work for user-specific calls
export POLYMARKET_PARTICIPANT_ID="firms/ISV-Participant-Ttt/users/ttt-testuser-001"
export POLYMARKET_ACCOUNT="firms/ISV-Ttt/accounts/ttt-testuser-001-trading"

# Optional
export POLYMARKET_TEST_SYMBOL="GWTEST-20251219"
export POLYMARKET_GRPC_ADDR="grpc-api.dev01.polymarketexchange.com:443"
export POLYMARKET_VERBOSE="false"
export POLYMARKET_TIMEOUT="30"

echo "TTT ISV environment loaded"
echo "  Client ID: $POLYMARKET_CLIENT_ID"
echo "  API URL: $POLYMARKET_API_URL"
