#!/bin/bash
#
# Run Python Client Sample Code Against PREPROD
#
# Prerequisites:
#   1. Alice ISV must exist in preprod Auth0 (run ensure-alice-isv-preprod.sh first)
#   2. The alice_isv_public.pem must be registered with the preprod Auth0 app
#   3. Set POLYMARKET_CLIENT_ID below to the preprod Alice ISV client ID
#   4. Python dependencies installed: pip3 install -r requirements.txt
#
# Usage:
#   ./run_preprod.sh              # Run all examples
#   ./run_preprod.sh --streaming  # Run with background gRPC subscriptions
#   ./run_preprod.sh --skip-kyc   # Skip KYC (use existing user)
#

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# =============================================================================
# PREPROD Configuration
# =============================================================================

# Alice ISV Client ID for PREPROD
# NOTE: This is a PUBLIC test client ID for preprod testing only - not a secret.
# It requires a matching private key (alice_isv_private.pem) to authenticate.
# nosec: test-credential-preprod-only
export POLYMARKET_CLIENT_ID="${POLYMARKET_CLIENT_ID:-tONZuDgXAPDWb4xG8NxnHijMFjpU1Rpc}"

# Path to RSA private key (same key used across environments)
export POLYMARKET_PRIVATE_KEY_PATH="${POLYMARKET_PRIVATE_KEY_PATH:-$SCRIPT_DIR/keys/alice_isv_private.pem}"

# PREPROD API endpoints
export POLYMARKET_API_URL="https://api.preprod.polymarketexchange.com"
export POLYMARKET_AUTH_DOMAIN="pmx-preprod.us.auth0.com"
export POLYMARKET_AUTH_AUDIENCE="https://api.preprod.polymarketexchange.com"
export POLYMARKET_GRPC_ADDR="grpc-api.preprod.polymarketexchange.com:443"

# Test user (will be set by KYC or use existing)
# If skipping KYC, set these to your existing preprod user
export POLYMARKET_PARTICIPANT_ID="${POLYMARKET_PARTICIPANT_ID:-}"
export POLYMARKET_ACCOUNT="${POLYMARKET_ACCOUNT:-}"

# Test symbol - use a valid preprod instrument
# NFL Super Bowl 2026 (Feb 8, 2026) - Kansas City Chiefs - PREOPEN state
export POLYMARKET_TEST_SYMBOL="${POLYMARKET_TEST_SYMBOL:-tec-nfl-sbw-2026-02-08-kc}"

# Optional settings
export POLYMARKET_VERBOSE="${POLYMARKET_VERBOSE:-false}"
export POLYMARKET_TIMEOUT="${POLYMARKET_TIMEOUT:-30}"

# =============================================================================
# Validation
# =============================================================================

echo "========================================="
echo "Python Client Sample - PREPROD"
echo "========================================="
echo ""
echo "Configuration:"
echo "  Client ID:    $POLYMARKET_CLIENT_ID"
echo "  API URL:      $POLYMARKET_API_URL"
echo "  Auth Domain:  $POLYMARKET_AUTH_DOMAIN"
echo "  gRPC Addr:    $POLYMARKET_GRPC_ADDR"
echo "  Private Key:  $POLYMARKET_PRIVATE_KEY_PATH"
echo ""

# Verify private key exists
if [ ! -f "$POLYMARKET_PRIVATE_KEY_PATH" ]; then
    echo "ERROR: Private key not found: $POLYMARKET_PRIVATE_KEY_PATH"
    echo ""
    echo "Make sure the alice_isv_private.pem key exists and is registered"
    echo "with your preprod Auth0 application."
    exit 1
fi

echo "Private key found: OK"
echo ""

# Check Python dependencies
if ! python3 -c "import grpc" 2>/dev/null; then
    echo "WARNING: Python gRPC not installed."
    echo "Install dependencies with: pip3 install -r requirements.txt"
    echo ""
fi

# =============================================================================
# Run
# =============================================================================

echo "Running Python examples against PREPROD..."
echo "========================================="
echo ""

exec python3 examples/run_all.py "$@"
