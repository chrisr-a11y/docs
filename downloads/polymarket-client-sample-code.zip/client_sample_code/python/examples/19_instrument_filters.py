#!/usr/bin/env python3
"""
Example 19: Instrument Filters

Demonstrates filtering instruments by state and metadata fields.
These filters allow efficient querying of specific instrument subsets.

Available Filters:
- states: Filter by instrument states (INSTRUMENT_STATE_OPEN, INSTRUMENT_STATE_CLOSED, INSTRUMENT_STATE_TERMINATED)
- metadata: Filter by metadata fields like sports_game_league, market_category
- symbols: Filter by specific symbols (see Example 06)
- tradable_only: Filter tradable vs non-tradable instruments
"""

import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api_client import PolymarketClient
from config import load_config


def truncate(s: str, max_len: int) -> str:
    """Truncate string to max_len characters."""
    if len(s) <= max_len:
        return s
    return s[:max_len - 3] + "..."


def main():
    print("=" * 60)
    print("Example 19: Instrument Filters")
    print("=" * 60)
    print()

    # Load configuration
    config = load_config()

    # Create client
    client = PolymarketClient(config)

    # Filter 1: Get OPEN instruments only
    print("Filter 1: Instruments in OPEN state")
    print("-" * 35)
    status, result = client.list_instruments(
        page_size=10,
        states=["INSTRUMENT_STATE_OPEN"]
    )
    if status == 200:
        instruments = result.get("instruments", [])
        print(f"  Found {len(instruments)} OPEN instruments (showing first 10):")
        for i, inst in enumerate(instruments[:5]):
            symbol = inst.get("symbol", "N/A")
            description = truncate(inst.get("description", ""), 50)
            print(f"    - {symbol}: {description}")
        if len(instruments) > 5:
            print(f"    ... and {len(instruments) - 5} more")
    else:
        print(f"  Error: {status}")
    print()

    # Filter 2: Get TERMINATED instruments
    print("Filter 2: Instruments in TERMINATED state")
    print("-" * 42)
    status, result = client.list_instruments(
        page_size=10,
        states=["INSTRUMENT_STATE_TERMINATED"]
    )
    if status == 200:
        instruments = result.get("instruments", [])
        print(f"  Found {len(instruments)} TERMINATED instruments (showing first 10):")
        for i, inst in enumerate(instruments[:5]):
            symbol = inst.get("symbol", "N/A")
            description = truncate(inst.get("description", ""), 50)
            print(f"    - {symbol}: {description}")
        if len(instruments) > 5:
            print(f"    ... and {len(instruments) - 5} more")
    else:
        print(f"  Error: {status}")
    print()

    # Filter 3: Filter by sports_game_league
    print("Filter 3: NFL sports instruments (league filter)")
    print("-" * 51)
    status, result = client.list_instruments(
        page_size=20,
        sports_game_league="nfl"  # Use dedicated parameter for sports league filter
    )
    if status == 200:
        instruments = result.get("instruments", [])
        print(f"  Found {len(instruments)} NFL instruments:")
        for i, inst in enumerate(instruments[:5]):
            symbol = inst.get("symbol", "N/A")
            description = truncate(inst.get("description", ""), 50)
            print(f"    - {symbol}: {description}")
        if len(instruments) > 5:
            print(f"    ... and {len(instruments) - 5} more")
    else:
        print(f"  Error: {status}")
    print()

    # Filter 4: Filter by market category
    print("Filter 4: Sports category instruments")
    print("-" * 38)
    status, result = client.list_instruments(
        page_size=20,
        metadata={"market_category": "sports"}
    )
    if status == 200:
        instruments = result.get("instruments", [])
        print(f"  Found {len(instruments)} sports category instruments:")
        for i, inst in enumerate(instruments[:5]):
            symbol = inst.get("symbol", "N/A")
            description = truncate(inst.get("description", ""), 50)
            print(f"    - {symbol}: {description}")
        if len(instruments) > 5:
            print(f"    ... and {len(instruments) - 5} more")
    else:
        print(f"  Error: {status}")
    print()

    # Filter 5: Combined filters - OPEN + tradable only
    print("Filter 5: OPEN and tradable instruments")
    print("-" * 40)
    status, result = client.list_instruments(
        page_size=10,
        states=["INSTRUMENT_STATE_OPEN"],
        tradable_only=True
    )
    if status == 200:
        instruments = result.get("instruments", [])
        print(f"  Found {len(instruments)} OPEN and tradable instruments:")
        for i, inst in enumerate(instruments[:5]):
            symbol = inst.get("symbol", "N/A")
            description = truncate(inst.get("description", ""), 40)
            non_tradable = inst.get("nonTradable", False)
            tradable = "non-tradable" if non_tradable else "tradable"
            print(f"    - {symbol} ({tradable}): {description}")
        if len(instruments) > 5:
            print(f"    ... and {len(instruments) - 5} more")
    else:
        print(f"  Error: {status}")
    print()

    # Filter 6: Multiple states
    print("Filter 6: OPEN or CLOSED instruments")
    print("-" * 37)
    status, result = client.list_instruments(
        page_size=10,
        states=["INSTRUMENT_STATE_OPEN", "INSTRUMENT_STATE_CLOSED"]
    )
    if status == 200:
        instruments = result.get("instruments", [])
        print(f"  Found {len(instruments)} OPEN or CLOSED instruments:")
        for i, inst in enumerate(instruments[:5]):
            symbol = inst.get("symbol", "N/A")
            state = inst.get("state", "N/A")
            print(f"    - {symbol} (state: {state})")
        if len(instruments) > 5:
            print(f"    ... and {len(instruments) - 5} more")
    else:
        print(f"  Error: {status}")
    print()

    print("Success!")
    return 0


if __name__ == "__main__":
    sys.exit(main())
