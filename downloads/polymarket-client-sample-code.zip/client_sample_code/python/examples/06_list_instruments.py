#!/usr/bin/env python3
"""
Example 06: List Instruments (with Pagination)

Demonstrates listing tradeable instruments on the exchange with pagination support.

Note: This endpoint requires authentication but does NOT require a participant_id.
You can call this before completing KYC onboarding.
"""

import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api_client import PolymarketClient
from config import load_config


def main():
    print("=" * 60)
    print("Example 06: List Instruments (with Pagination)")
    print("=" * 60)
    print()

    # Load configuration
    config = load_config()

    # Create client
    client = PolymarketClient(config)

    # Method 1: Fetch all instruments (auto-pagination)
    print("Method 1: Fetch all instruments (auto-pagination)")
    status, all_instruments = client.list_all_instruments(page_size=100)
    if status == 200:
        print(f"  Total instruments: {len(all_instruments)}")
    else:
        print(f"  Error: {status}")
        return 1
    print()

    # Method 2: Manual pagination for more control
    print("Method 2: Manual pagination (pageSize=5)")
    page_token = ""
    page_num = 0

    while page_num < 3:  # Show first 3 pages
        page_num += 1
        status, result = client.list_instruments(page_size=5, page_token=page_token)

        if status != 200:
            print(f"  Error on page {page_num}: {status}")
            break

        instruments = result.get("instruments", [])
        eof = result.get("eof", False)
        next_token = result.get("nextPageToken", "")

        suffix = " (end of results)" if eof else ""
        print(f"  Page {page_num}: {len(instruments)} instruments{suffix}")

        # Display instruments
        for i, inst in enumerate(instruments):
            symbol = inst.get("symbol", "N/A")
            description = inst.get("description", "")
            state = inst.get("state", "N/A")
            print(f"    {page_num}.{i+1}. {symbol} - {description} (state: {state})")

        if eof:
            break
        page_token = next_token
    print()

    # Method 3: Filter by specific symbols
    print("Method 3: Filter by specific symbols")
    if len(all_instruments) > 0:
        # Get first two symbols for filtering demo
        filter_symbols = [inst.get("symbol") for inst in all_instruments[:2]]

        status, result = client.list_instruments(symbols=filter_symbols)
        if status == 200:
            instruments = result.get("instruments", [])
            print(f"  Filtered to {len(instruments)} instruments:")
            for inst in instruments:
                symbol = inst.get("symbol", "N/A")
                description = inst.get("description", "")
                print(f"    - {symbol}: {description}")
        else:
            print(f"  Error: {status}")
    print()

    print("Success!")
    return 0


if __name__ == "__main__":
    sys.exit(main())
