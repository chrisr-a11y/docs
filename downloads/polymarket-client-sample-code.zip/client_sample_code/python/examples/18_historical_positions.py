#!/usr/bin/env python3
"""
Example 18: Historical Positions

Demonstrates querying positions at a specific point in time using:
- as_of_time: RFC3339 timestamp for exact point-in-time queries
- as_of_date: Year/month/day for end-of-trading-day queries

Use cases:
- End-of-day reports and P&L calculations
- Regulatory snapshots at specific timestamps
- Position reconciliation with external records
- Audit trail and compliance reviews

Note: as_of_time and as_of_date are mutually exclusive.
      Use one or the other, not both.
"""

import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api_client import PolymarketClient
from config import load_config


def main():
    print("=" * 60)
    print("Example 18: Historical Positions")
    print("=" * 60)
    print()

    # Load configuration
    config = load_config()

    # Create client
    client = PolymarketClient(config)

    # -------------------------------------------------------------------------
    # Example 1: Query by timestamp (as_of_time)
    # -------------------------------------------------------------------------
    print("1. Query positions by timestamp (as_of_time)")
    print("-" * 50)

    # Query positions as of a specific timestamp
    # Format: RFC3339 (e.g., "2026-01-02T17:00:00Z")
    timestamp = "2025-12-21T23:00:00Z"
    print(f"   Account: {config.account}")
    print(f"   As of time: {timestamp}")

    status, result = client.list_historical_positions(
        account=config.account,
        as_of_time=timestamp,
    )

    if status == 200:
        print(f"   Status: {status} OK")
        positions = result.get("positions", [])
        if positions:
            print(f"   Found {len(positions)} position(s):")
            for pos in positions:
                symbol = pos.get("symbol", "N/A")
                net_pos = pos.get("netPosition", "0")
                print(f"     - {symbol}: netPosition={net_pos}")
        else:
            print("   No positions found at that time.")
    else:
        print(f"   Status: {status}")
        print(f"   Response: {result}")

    print()

    # -------------------------------------------------------------------------
    # Example 2: Query by trade date (as_of_date)
    # -------------------------------------------------------------------------
    print("2. Query positions by trade date (as_of_date)")
    print("-" * 50)

    # Query positions at end of a specific trading day
    date = {"year": 2025, "month": 12, "day": 22}
    print(f"   Account: {config.account}")
    print(f"   As of date: {date['year']}-{date['month']:02d}-{date['day']:02d}")

    status, result = client.list_historical_positions(
        account=config.account,
        as_of_date=date,
    )

    if status == 200:
        print(f"   Status: {status} OK")
        positions = result.get("positions", [])
        if positions:
            print(f"   Found {len(positions)} position(s):")
            for pos in positions:
                symbol = pos.get("symbol", "N/A")
                net_pos = pos.get("netPosition", "0")
                print(f"     - {symbol}: netPosition={net_pos}")
        else:
            print("   No positions found at that date.")
    else:
        print(f"   Status: {status}")
        print(f"   Response: {result}")

    print()
    print("=" * 60)
    print("Done!")
    return 0


if __name__ == "__main__":
    sys.exit(main())
