#!/usr/bin/env python3
"""
Example 08: Search Orders

Demonstrates searching historical orders for an account.
"""

import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api_client import PolymarketClient
from config import load_config


def main():
    print("=" * 60)
    print("Example 08: Search Orders")
    print("=" * 60)
    print()

    # Load configuration
    config = load_config()

    # Create client
    client = PolymarketClient(config)

    # Search orders
    print(f"Searching orders for account: {config.account}")
    status, result = client.search_orders(config.account, page_size=10)

    if status == 200:
        print(f"  Status: {status} OK")
        orders = result.get("orders", [])
        if orders:
            print(f"  Found {len(orders)} order(s):")
            for order in orders[:5]:  # Show first 5
                order_id = order.get("order_id", "N/A")
                symbol = order.get("symbol", "N/A")
                side = order.get("side", "N/A")
                status_val = order.get("status", "N/A")
                print(f"    - {order_id[:12]}... {symbol} {side} ({status_val})")
            if len(orders) > 5:
                print(f"    ... and {len(orders) - 5} more")
        else:
            print("  No orders found.")

        next_page = result.get("next_page_token", "")
        if next_page:
            print(f"\n  More results available (next_page_token: {next_page[:20]}...)")

        return 0
    else:
        print(f"  Status: {status}")
        print(f"  Error: {result}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
