#!/usr/bin/env python3
"""
Example 17: Pagination

Demonstrates how to paginate through large result sets using page tokens.
Shows both manual pagination and the convenience search_all_orders() method.
"""

import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api_client import PolymarketClient
from config import load_config


def manual_pagination(client, account):
    """
    Demonstrate manual pagination through orders.

    Use this approach when you need:
    - Control over when to stop fetching
    - To process results as they come in (streaming-like)
    - Memory efficiency for very large result sets
    """
    print("Method 1: Manual Pagination")
    print("-" * 40)

    all_orders = []
    page_token = ""
    page_count = 0
    page_size = 10  # Small page size to demonstrate pagination

    while True:
        page_count += 1
        print(f"  Fetching page {page_count}...", end=" ")

        status, result = client.search_orders(account, page_size=page_size, page_token=page_token)

        if status != 200:
            print(f"Error: {status}")
            return None

        orders = result.get("orders", [])
        all_orders.extend(orders)
        print(f"got {len(orders)} orders")

        # Get next page token
        page_token = result.get("next_page_token", "")

        # Stop if no more pages
        if not page_token:
            print("  No more pages.")
            break

        # Optional: limit pages for demo purposes
        if page_count >= 5:
            print("  (stopping after 5 pages for demo)")
            break

    print(f"\n  Total orders retrieved: {len(all_orders)}")
    return all_orders


def automatic_pagination(client, account):
    """
    Demonstrate automatic pagination using search_all_orders().

    Use this approach when you need:
    - All results in one call
    - Simplicity over control
    - Small to medium result sets
    """
    print("\nMethod 2: Automatic Pagination (search_all_orders)")
    print("-" * 40)

    print("  Fetching all orders...")
    status, all_orders = client.search_all_orders(account, page_size=50)

    if status != 200:
        print(f"  Error: {status}")
        return None

    print(f"  Total orders retrieved: {len(all_orders)}")

    # Show summary by status
    if all_orders:
        status_counts = {}
        for order in all_orders:
            order_status = order.get("state", "UNKNOWN")
            status_counts[order_status] = status_counts.get(order_status, 0) + 1

        print("\n  Orders by status:")
        for status_name, count in sorted(status_counts.items()):
            print(f"    {status_name}: {count}")

    return all_orders


def main():
    print("=" * 60)
    print("Example 17: Pagination")
    print("=" * 60)
    print()

    # Load configuration
    config = load_config()

    # Create client
    client = PolymarketClient(config)

    print(f"Account: {config.account}")
    print()

    # Method 1: Manual pagination
    manual_pagination(client, config.account)

    # Method 2: Automatic pagination
    automatic_pagination(client, config.account)

    print()
    print("=" * 60)
    print("Pagination Patterns:")
    print("=" * 60)
    print("""
1. Manual Pagination:
   - Use search_orders() with page_token parameter
   - Good for streaming/processing as you go
   - Memory efficient for large datasets

2. Automatic Pagination:
   - Use search_all_orders() for convenience
   - Returns all results in one call
   - Simpler code, but loads all into memory

3. Best Practices:
   - Use reasonable page_size (50-100)
   - Handle errors at each page
   - Consider memory for large result sets
   - Add delays if hitting rate limits
""")

    return 0


if __name__ == "__main__":
    sys.exit(main())
