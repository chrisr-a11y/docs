#!/usr/bin/env python3
"""
Example 00: KYC Onboard User

Creates a new user via KYC using Socure sandbox data.
This must run BEFORE other examples that require a user/account.

The created participant_id and account are saved to a file for other examples.
"""

import os
import sys
import json
import time
from datetime import datetime

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import load_config
from api_client import PolymarketClient

# File to store created user credentials
CREDENTIALS_FILE = os.path.join(os.path.dirname(__file__), ".created_user.json")


def main():
    print("=" * 60)
    print("Example 00: KYC Onboard User")
    print("=" * 60)
    print()

    config = load_config()
    client = PolymarketClient(config)

    # Generate unique user ID based on timestamp
    user_id = f"test-{datetime.now().strftime('%Y%m%d-%H%M%S')}"

    print(f"Creating new user via KYC...")
    print(f"  User ID: {user_id}")
    print(f"  DOB: 1985-10-02 (Socure sandbox auto-approve)")
    print()

    # Step 1: Start KYC with Socure sandbox data (auto-approve DOB)
    status, result = client.kyc_start(
        user_id=user_id,
        first_name="Test",
        last_name="User",
        date_of_birth="1985-10-02",  # Socure sandbox: auto-approve
        email=f"{user_id}@example.com",
        phone_number="+14155551212",
        ssn="123456789",
        address={
            "address_line_1": "123 Test Street",
            "city": "New York",
            "state": "NY",
            "postal_code": "10001",
            "country": "US"
        }
    )

    if status != 200:
        print(f"KYC start failed with status {status}")
        print(f"  Error: {result}")
        return 1

    print(f"KYC started successfully!")
    print(f"  Response: {json.dumps(result, indent=4)}")

    # Extract from immediate response (Socure sandbox returns immediately)
    decision = result.get('decision', '') or result.get('status', {}).get('decision', '')
    # New API returns participant_id and account directly in response
    participant_id = result.get('participantId') or result.get('participant_id')
    account = result.get('account')

    if decision == 'ACCEPT':
        print()
        print("KYC APPROVED!")

        # Verify the gateway returned the EP3 IDs
        if not participant_id or not account:
            print(f"  WARNING: KYC response missing participant_id or account")
            print(f"  Response: {json.dumps(result, indent=4)}")
            print(f"  Gateway may need to be updated to return these fields")
            return 1

        # Save credentials for other examples
        credentials = {
            "user_id": user_id,
            "participant_id": participant_id,
            "account": account,
            "created_at": datetime.now().isoformat(),
        }

        with open(CREDENTIALS_FILE, 'w') as f:
            json.dump(credentials, f, indent=2)

        print()
        print(f"User created successfully!")
        print(f"  Participant ID: {participant_id}")
        print(f"  Account: {account}")
        print()
        print(f"Credentials saved to: {CREDENTIALS_FILE}")
        print()
        print("You can now run the other examples.")
        return 0

    elif decision == 'REVIEW':
        print("KYC pending review (DocV required)")
        return 1

    elif decision == 'REJECT':
        print("KYC REJECTED!")
        return 1

    # Poll for completion if not immediate
    print()
    print("Checking KYC status...")
    max_attempts = 10
    for attempt in range(max_attempts):
        status, result = client.kyc_status(user_id)

        if status == 200:
            kyc_status = result.get('status', {})
            decision = kyc_status.get('decision', '')

            print(f"  Attempt {attempt + 1}: decision = {decision}")

            if decision == 'ACCEPT':
                print("KYC APPROVED!")

                # New API returns participant_id and account directly in GetKYCStatus response
                participant_id = result.get('participantId') or result.get('participant_id')
                account = result.get('account')

                if not participant_id or not account:
                    print(f"  WARNING: KYC status response missing participant_id or account")
                    print(f"  Response: {json.dumps(result, indent=4)}")
                    return 1

                credentials = {
                    "user_id": user_id,
                    "participant_id": participant_id,
                    "account": account,
                    "created_at": datetime.now().isoformat(),
                }

                with open(CREDENTIALS_FILE, 'w') as f:
                    json.dump(credentials, f, indent=2)

                print(f"  Participant ID: {participant_id}")
                print(f"  Account: {account}")
                print(f"Credentials saved to: {CREDENTIALS_FILE}")
                return 0

            elif decision == 'REJECT':
                print("KYC REJECTED!")
                return 1

        time.sleep(1)

    print("KYC did not complete in time")
    return 1


if __name__ == "__main__":
    sys.exit(main())
