#!/usr/bin/env python3
"""
Example 10: Place and Cancel Order

Demonstrates placing a limit order and then immediately canceling it.

This example uses a very unattractive price ($0.01) to ensure the order
won't fill before we cancel it. This is a safe way to test the trading
API without any actual execution risk.

Default symbol: SBLIX-KC-YES (Kansas City wins Super Bowl)
"""

import sys
import os
import uuid

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api_client import PolymarketClient
from config import load_config


def main():
    print("=" * 60)
    print("Example 10: Place and Cancel Order")
    print("=" * 60)
    print()

    # Load configuration
    config = load_config()

    # Create client
    client = PolymarketClient(config)

    # Generate unique client order ID
    clord_id = f"sample-{uuid.uuid4()}"

    # Order parameters
    symbol = config.test_symbol  # Default: SBLIX-KC-YES (Kansas City wins Super Bowl)
    side = "SIDE_BUY"
    order_type = "ORDER_TYPE_LIMIT"
    quantity = 1
    price = 1  # $0.01 - extremely unattractive, won't fill

    print("Step 1: Placing limit order...")
    print(f"  Symbol: {symbol}")
    print(f"  Side: {side}")
    print(f"  Type: {order_type}")
    print(f"  Quantity: {quantity}")
    print(f"  Price: ${price/100:.2f} (very unattractive)")
    print(f"  Account: {config.account}")
    print(f"  Client Order ID: {clord_id}")
    print()

    # Place order
    status, result = client.place_order(
        symbol=symbol,
        side=side,
        order_type=order_type,
        quantity=quantity,
        price=price,
        account=config.account,
        clord_id=clord_id,
    )

    if status != 200:
        print(f"  ERROR: Failed to place order")
        print(f"  Status: {status}")
        print(f"  Error: {result}")
        return 1

    # API returns orderId (camelCase)
    order_id = result.get("orderId", "") or result.get("order_id", "")
    print(f"  Order placed successfully!")
    print(f"  Order ID: {order_id}")
    print()

    if not order_id:
        print("  ERROR: No order ID returned")
        return 1

    # Cancel order
    print("Step 2: Canceling order...")
    cancel_status, cancel_result = client.cancel_order(order_id, config.account, symbol)

    if cancel_status == 200:
        print(f"  Order canceled successfully!")
        print(f"  Status: {cancel_status}")
        print()
        print("Trade API test completed successfully!")
        print("(Order was placed and immediately canceled - no execution)")
        return 0
    else:
        print(f"  WARNING: Cancel may have failed")
        print(f"  Status: {cancel_status}")
        print(f"  Response: {cancel_result}")
        print()
        print("Please check the order status manually.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
