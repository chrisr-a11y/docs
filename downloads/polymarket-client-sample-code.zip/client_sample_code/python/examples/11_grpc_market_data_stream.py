#!/usr/bin/env python3
"""
Example 11: gRPC Market Data Stream

Demonstrates subscribing to real-time market data updates via gRPC streaming.
Receives order book updates (bids/offers) for specified symbols.
"""

import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import grpc
from config import load_config
from grpc_client import PolymarketGrpcClient, format_market_data_update


def main():
    print("=" * 60)
    print("  Example 11: gRPC Market Data Stream")
    print("=" * 60)
    print()

    # Load configuration
    config = load_config()
    symbol = config.test_symbol

    print(f"Connecting to gRPC endpoint: {config.grpc_addr}")
    print(f"Subscribing to market data for: {symbol}")
    print()

    try:
        with PolymarketGrpcClient(config) as client:
            print("Waiting for market data updates (will show first 10 or timeout after 30s)...")
            print("-" * 60)

            count = 0
            for response in client.subscribe_market_data([symbol], depth=5):
                formatted = format_market_data_update(response)
                print(f"  [{count + 1}] {formatted}")

                count += 1
                if count >= 10:
                    print()
                    print(f"Received {count} updates. Closing stream...")
                    break

    except grpc.RpcError as e:
        print(f"\nERROR: gRPC call failed")
        print(f"  Code: {e.code()}")
        print(f"  Details: {e.details()}")
        return 1
    except KeyboardInterrupt:
        print("\n\nInterrupted by user")
        return 0

    print()
    print("Market data stream example completed successfully!")
    return 0


if __name__ == "__main__":
    sys.exit(main())
