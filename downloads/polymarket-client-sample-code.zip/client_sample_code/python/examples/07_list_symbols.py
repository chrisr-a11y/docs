#!/usr/bin/env python3
"""
Example 07: List Symbols

Demonstrates listing all available symbols on the exchange.

Note: This endpoint requires authentication but does NOT require a participant_id.
You can call this before completing KYC onboarding.
"""

import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api_client import PolymarketClient
from config import load_config


def main():
    print("=" * 60)
    print("Example 07: List Symbols")
    print("=" * 60)
    print()

    # Load configuration
    config = load_config()

    # Create client
    client = PolymarketClient(config)

    # List symbols
    print("Listing all symbols...")
    status, result = client.list_symbols()

    if status == 200:
        print(f"  Status: {status} OK")
        symbols = result.get("symbols", [])
        print(f"  Found {len(symbols)} symbol(s):")
        for sym in symbols[:15]:  # Show first 15
            print(f"    - {sym}")
        if len(symbols) > 15:
            print(f"    ... and {len(symbols) - 15} more")
        return 0
    else:
        print(f"  Status: {status}")
        print(f"  Error: {result}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
