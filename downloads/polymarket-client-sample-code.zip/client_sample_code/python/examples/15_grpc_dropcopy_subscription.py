#!/usr/bin/env python3
"""
Example 15: gRPC Drop Copy Subscription

Demonstrates subscribing to the drop copy (execution) feed via gRPC streaming.
Receives trade confirmations and execution reports in real-time.
"""

import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import grpc
from config import load_config
from grpc_client import PolymarketGrpcClient


def format_dropcopy_update(response) -> str:
    """Format a drop copy update for display."""
    if response.executions:
        executions = response.executions
        return f"[DropCopy] {len(executions)} execution(s)"
    return "[DropCopy] No executions"


def main():
    print("=" * 60)
    print("  Example 15: gRPC Drop Copy Subscription")
    print("=" * 60)
    print()

    # Load configuration
    config = load_config()

    print(f"Connecting to gRPC endpoint: {config.grpc_addr}")
    print("Subscribing to drop copy (execution) feed...")
    print()

    try:
        with PolymarketGrpcClient(config) as client:
            print("Waiting for drop copy updates (will show first 10 or timeout after 30s)...")
            print("-" * 60)

            count = 0
            for response in client.subscribe_drop_copy():
                formatted = format_dropcopy_update(response)
                print(f"  [{count + 1}] {formatted}")

                count += 1
                if count >= 10:
                    print()
                    print(f"Received {count} updates. Closing stream...")
                    break

    except grpc.RpcError as e:
        print(f"\nERROR: gRPC call failed")
        print(f"  Code: {e.code()}")
        print(f"  Details: {e.details()}")
        return 1
    except KeyboardInterrupt:
        print("\n\nInterrupted by user")
        return 0

    print()
    print("Drop copy subscription example completed successfully!")
    return 0


if __name__ == "__main__":
    sys.exit(main())
