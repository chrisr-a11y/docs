#!/usr/bin/env python3
"""
Example: KYC DocV (Document Verification) Test

Tests the Socure DocV flow using sandbox DOB triggers. These DOBs trigger
document verification and return SDK credentials for mobile integration.

Socure Sandbox DocV Test DOBs (from Socure ID+ Test Cases PDF):
- 1985-09-02: DocV Accept (after document submission)
- 1985-09-05: DocV Reject (after document submission)
- 1985-09-26: DocV Review (after document submission)
- 1985-09-01: DocV Resubmit (after document submission)

All DOBs above will trigger DocV (REVIEW/ON_HOLD status) and return:
- docvTransactionToken: Token to pass to SDK's launch() method
- sdkKey: Public key for initializing Socure DocV SDK
- url: Web URL for document verification
- qrCode: QR code image (base64 PNG) for mobile scanning
- eventId: Socure event identifier

The DOB determines the OUTCOME after DocV completion, not whether DocV triggers.
"""

import os
import sys
import json
import time
from datetime import datetime

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import load_config
from api_client import PolymarketClient

# DocV test DOBs and their expected outcomes after document submission
DOCV_TEST_DOBS = [
    ("1985-09-02", "Accept", "User will be approved after DocV completion"),
    ("1985-09-05", "Reject", "User will be rejected after DocV completion"),
    ("1985-09-26", "Review", "User will need manual review after DocV"),
    ("1985-09-01", "Resubmit", "User will need to resubmit documents"),
]


def test_docv_trigger(client: PolymarketClient, dob: str, expected_outcome: str, description: str) -> dict:
    """
    Test a single DocV DOB trigger and verify SDK credentials are returned.

    Returns dict with test results.
    """
    user_id = f"docv-test-{expected_outcome.lower()}-{int(time.time())}"

    print(f"\n--- Testing DOB {dob} ({expected_outcome}) ---")
    print(f"  Expected: {description}")

    status, result = client.kyc_start(
        user_id=user_id,
        first_name="DocV",
        last_name=f"Test{expected_outcome}",
        date_of_birth=dob,
        email=f"{user_id}@example.com",
        phone_number="+14155551212",
        ssn="000000000",  # Sandbox SSN
        address={
            "address_line_1": "123 Test Street",
            "city": "New York",
            "state": "NY",
            "postal_code": "10001",
            "country": "US"
        }
    )

    test_result = {
        "dob": dob,
        "expected_outcome": expected_outcome,
        "http_status": status,
        "docv_triggered": False,
        "sdk_key_present": False,
        "transaction_token_present": False,
        "url_present": False,
        "passed": False,
    }

    if status != 200:
        print(f"  ERROR: HTTP {status}")
        print(f"  Response: {result}")
        return test_result

    # Check decision and status
    kyc_status = result.get('status', {})
    decision = kyc_status.get('decision', '')
    status_val = kyc_status.get('status', '')
    sub_status = kyc_status.get('subStatus', '')

    print(f"  Decision: {decision}, Status: {status_val}")
    print(f"  SubStatus: {sub_status}")

    # Check for DocV data
    docv = result.get('docv')
    if docv:
        test_result["docv_triggered"] = True
        test_result["sdk_key_present"] = bool(docv.get('sdkKey'))
        test_result["transaction_token_present"] = bool(docv.get('docvTransactionToken'))
        test_result["url_present"] = bool(docv.get('url'))

        print(f"  DocV Data Present: YES")
        print(f"    SDK Key: {docv.get('sdkKey', '<missing>')}")
        print(f"    Transaction Token: {docv.get('docvTransactionToken', '<missing>')[:50]}...")
        print(f"    URL: {docv.get('url', '<missing>')}")
        print(f"    Event ID: {docv.get('eventId', '<missing>')}")
        print(f"    QR Code: {'<present>' if docv.get('qrCode') else '<missing>'}")

        # Test passes if DocV triggered with all required fields
        test_result["passed"] = (
            test_result["sdk_key_present"] and
            test_result["transaction_token_present"] and
            test_result["url_present"]
        )
    else:
        print(f"  DocV Data Present: NO")

    return test_result


def main():
    print("=" * 70)
    print("KYC DocV (Document Verification) Test")
    print("=" * 70)
    print()
    print("This test verifies that Socure DocV DOBs trigger document verification")
    print("and return the SDK credentials needed for mobile integration.")
    print()
    print("Reference: Socure ID+ Test Cases PDF, Section 3 (DocV)")
    print()

    config = load_config()
    client = PolymarketClient(config)

    results = []

    for dob, outcome, description in DOCV_TEST_DOBS:
        result = test_docv_trigger(client, dob, outcome, description)
        results.append(result)
        time.sleep(1)  # Small delay between requests

    # Summary
    print()
    print("=" * 70)
    print("Test Summary")
    print("=" * 70)

    passed = sum(1 for r in results if r["passed"])
    total = len(results)

    print(f"\nResults: {passed}/{total} tests passed\n")

    print(f"{'DOB':<12} {'Outcome':<10} {'DocV':<6} {'SDK Key':<8} {'Token':<8} {'URL':<6} {'Pass':<6}")
    print("-" * 70)

    for r in results:
        print(f"{r['dob']:<12} {r['expected_outcome']:<10} "
              f"{'YES' if r['docv_triggered'] else 'NO':<6} "
              f"{'YES' if r['sdk_key_present'] else 'NO':<8} "
              f"{'YES' if r['transaction_token_present'] else 'NO':<8} "
              f"{'YES' if r['url_present'] else 'NO':<6} "
              f"{'PASS' if r['passed'] else 'FAIL':<6}")

    print()

    if passed == total:
        print("All DocV tests passed! SDK credentials are being returned correctly.")
        print()
        print("To integrate DocV in your mobile app:")
        print("  1. Initialize Socure SDK with the 'sdkKey'")
        print("  2. Call SDK.launch() with the 'docvTransactionToken'")
        print("  3. Handle success/failure callbacks from the SDK")
        print()
        return 0
    else:
        print("Some tests failed. Check the DocV configuration.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
