#!/usr/bin/env python3
"""
Example 02: Who Am I

Demonstrates the whoami endpoint, which returns information about the
currently authenticated user and their firm.
"""

import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api_client import PolymarketClient
from config import load_config


def main():
    print("=" * 60)
    print("Example 02: Who Am I")
    print("=" * 60)
    print()

    # Load configuration
    config = load_config()

    # Create client
    client = PolymarketClient(config)

    # Call whoami endpoint
    print("Getting current user info...")
    status, result = client.whoami()

    if status == 200:
        print(f"  Status: {status} OK")
        print(f"  User: {result.get('user', 'N/A')}")
        print(f"  Firm: {result.get('firm', 'N/A')}")
        print("\nAuthentication successful!")
        return 0
    else:
        print(f"  Status: {status}")
        print(f"  Error: {result}")
        print("\nFailed to get user info!")
        return 1


if __name__ == "__main__":
    sys.exit(main())
