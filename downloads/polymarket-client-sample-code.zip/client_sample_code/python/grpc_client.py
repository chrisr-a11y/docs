#!/usr/bin/env python3
"""
gRPC Streaming Client for Polymarket Exchange API.

Provides streaming subscriptions for real-time market data, orders,
positions, funding, and drop copy feeds.
"""

import grpc
import time
from typing import Iterator, Optional, Callable

from config import Config
from auth import get_access_token

# Generated proto imports
from gen.polymarket.v1 import marketdatasubscription_pb2
from gen.polymarket.v1 import marketdatasubscription_pb2_grpc
from gen.polymarket.v1 import positions_pb2
from gen.polymarket.v1 import positions_pb2_grpc
from gen.polymarket.v1 import trading_pb2
from gen.polymarket.v1 import trading_pb2_grpc
from gen.polymarket.v1 import funding_pb2
from gen.polymarket.v1 import funding_pb2_grpc
from gen.polymarket.v1 import dropcopy_pb2
from gen.polymarket.v1 import dropcopy_pb2_grpc


class AuthMetadataPlugin(grpc.AuthMetadataPlugin):
    """Plugin that adds authentication metadata to gRPC calls."""

    def __init__(self, config: Config):
        self.config = config
        self._token: Optional[str] = None
        self._token_expires: float = 0

    def __call__(self, context, callback):
        """Add authentication metadata to the call."""
        # Refresh token if needed
        if time.time() >= self._token_expires - 60:
            self._token, expires_in = get_access_token(self.config)
            self._token_expires = time.time() + expires_in

        metadata = [
            ('authorization', f'Bearer {self._token}'),
            ('x-participant-id', self.config.participant_id),
        ]
        callback(metadata, None)


class PolymarketGrpcClient:
    """gRPC client for Polymarket Exchange streaming APIs."""

    def __init__(self, config: Config):
        """
        Initialize the gRPC client.

        Args:
            config: Configuration object with API settings
        """
        self.config = config

        # Create auth metadata plugin
        auth_plugin = AuthMetadataPlugin(config)

        # Create channel credentials with TLS and auth
        ssl_creds = grpc.ssl_channel_credentials()
        call_creds = grpc.metadata_call_credentials(auth_plugin)
        composite_creds = grpc.composite_channel_credentials(ssl_creds, call_creds)

        # Create secure channel
        self.channel = grpc.secure_channel(
            config.grpc_addr,
            composite_creds,
            options=[
                ('grpc.max_receive_message_length', 10 * 1024 * 1024),  # 10MB
            ]
        )

        # Create service stubs
        self.market_data_stub = marketdatasubscription_pb2_grpc.MarketDataSubscriptionAPIStub(self.channel)
        self.positions_stub = positions_pb2_grpc.PositionAPIStub(self.channel)
        self.orders_stub = trading_pb2_grpc.OrderEntryAPIStub(self.channel)
        self.funding_stub = funding_pb2_grpc.FundingAPIStub(self.channel)
        self.dropcopy_stub = dropcopy_pb2_grpc.DropCopyAPIStub(self.channel)

    def close(self):
        """Close the gRPC channel."""
        if self.channel:
            self.channel.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    # =========================================================================
    # Market Data Streaming
    # =========================================================================

    def subscribe_market_data(
        self,
        symbols: list,
        depth: int = 5,
        snapshot_only: bool = False
    ) -> Iterator:
        """
        Subscribe to market data updates for specified symbols.

        Args:
            symbols: List of symbols to subscribe to
            depth: Order book depth (default: 5)
            snapshot_only: If True, receive only initial snapshot

        Yields:
            CreateMarketDataSubscriptionResponse objects
        """
        request = marketdatasubscription_pb2.CreateMarketDataSubscriptionRequest(
            symbols=symbols,
            depth=depth,
            snapshot_only=snapshot_only,
        )

        return self.market_data_stub.CreateMarketDataSubscription(request)

    # =========================================================================
    # Position Streaming
    # =========================================================================

    def subscribe_positions(self, accounts: list) -> Iterator:
        """
        Subscribe to position updates for specified accounts.

        Args:
            accounts: List of account names to subscribe to

        Yields:
            CreatePositionSubscriptionResponse objects
        """
        request = positions_pb2.CreatePositionSubscriptionRequest(
            accounts=accounts,
        )

        return self.positions_stub.CreatePositionSubscription(request)

    # =========================================================================
    # Order Streaming
    # =========================================================================

    def subscribe_orders(
        self,
        accounts: list,
        symbols: Optional[list] = None,
        snapshot_only: bool = False
    ) -> Iterator:
        """
        Subscribe to order updates for specified accounts.

        Args:
            accounts: List of account names to subscribe to
            symbols: Optional list of symbols to filter
            snapshot_only: If True, receive only initial snapshot

        Yields:
            CreateOrderSubscriptionResponse objects
        """
        request = trading_pb2.CreateOrderSubscriptionRequest(
            accounts=accounts,
            symbols=symbols or [],
            snapshot_only=snapshot_only,
        )

        return self.orders_stub.CreateOrderSubscription(request)

    # =========================================================================
    # Funding Streaming
    # =========================================================================

    def subscribe_funding(self) -> Iterator:
        """
        Subscribe to funding transaction updates.

        Yields:
            CreateFundingTransactionSubscriptionResponse objects
        """
        request = funding_pb2.CreateFundingTransactionSubscriptionRequest()

        return self.funding_stub.CreateFundingTransactionSubscription(request)

    # =========================================================================
    # Drop Copy Streaming
    # =========================================================================

    def subscribe_drop_copy(self, symbols: Optional[list] = None) -> Iterator:
        """
        Subscribe to drop copy (execution) feed.

        Args:
            symbols: Optional list of symbols to filter

        Yields:
            CreateDropCopySubscriptionResponse objects
        """
        request = dropcopy_pb2.CreateDropCopySubscriptionRequest(
            symbols=symbols or [],
        )

        return self.dropcopy_stub.CreateDropCopySubscription(request)


def format_market_data_update(response) -> str:
    """Format a market data update for display."""
    if response.HasField('heartbeat'):
        return "[Heartbeat]"
    elif response.HasField('update'):
        update = response.update
        bids = len(update.bids) if update.bids else 0
        offers = len(update.offers) if update.offers else 0
        return f"Symbol: {update.symbol}, Bids: {bids}, Offers: {offers}"
    return str(response)


def format_position_update(response) -> str:
    """Format a position update for display."""
    if response.HasField('heartbeat'):
        return "[Heartbeat]"
    elif response.HasField('snapshot'):
        positions = response.snapshot.positions
        return f"[Snapshot] {len(positions)} position(s)"
    elif response.HasField('update'):
        positions = response.update.positions
        return f"[Update] {len(positions)} position(s)"
    return str(response)


def format_order_update(response) -> str:
    """Format an order update for display."""
    if response.HasField('heartbeat'):
        return "[Heartbeat]"
    elif response.HasField('snapshot'):
        orders = response.snapshot.orders
        return f"[Snapshot] {len(orders)} order(s)"
    elif response.HasField('update'):
        orders = response.update.orders
        if orders:
            order = orders[0]
            return f"[Update] Order {order.order_id}: {order.status}"
        return "[Update] No orders"
    return str(response)


if __name__ == "__main__":
    # Test the gRPC client
    from config import load_config

    config = load_config()
    print(f"Testing gRPC client to {config.grpc_addr}...")

    with PolymarketGrpcClient(config) as client:
        print("\nSubscribing to market data...")
        try:
            count = 0
            for response in client.subscribe_market_data([config.test_symbol], depth=5):
                print(f"  {format_market_data_update(response)}")
                count += 1
                if count >= 5:
                    break
        except grpc.RpcError as e:
            print(f"  Error: {e.code()} - {e.details()}")
