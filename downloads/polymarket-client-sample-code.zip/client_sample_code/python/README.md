# Polymarket Exchange API - Python Client Examples

This directory contains Python sample code demonstrating how to authenticate with and use the Polymarket Exchange API, including both REST endpoints and gRPC streaming.

## Prerequisites

- Python 3.6 or higher
- Credentials (Client ID and private key) provided by Polymarket
- A registered trading account

## Installation

1. Install dependencies:

```bash
pip3 install -r requirements.txt
```

2. Configure your environment:

```bash
# Copy the sample environment file
cp sample_env.sh my_env.sh

# Edit with your actual credentials
nano my_env.sh  # or use your preferred editor

# Source the environment
source my_env.sh
```

## Configuration

The following environment variables are required:

| Variable | Description |
|----------|-------------|
| `POLYMARKET_CLIENT_ID` | Your Client ID (provided by Polymarket) |
| `POLYMARKET_PRIVATE_KEY_PATH` | Path to your RSA private key (PEM format) |
| `POLYMARKET_API_URL` | API base URL (e.g., `https://api.preprod.polymarketexchange.com`) |
| `POLYMARKET_AUTH_DOMAIN` | Authentication domain (e.g., `auth.preprod.polymarketexchange.com`) |
| `POLYMARKET_AUTH_AUDIENCE` | Authentication audience (matches API URL) |
| `POLYMARKET_PARTICIPANT_ID` | Your participant ID (e.g., `firms/Your-Firm/users/your-user`) |
| `POLYMARKET_ACCOUNT` | Your trading account (e.g., `firms/Your-Firm/accounts/your-account`) |

Optional variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `POLYMARKET_TEST_SYMBOL` | `SBLIX-KC-YES` | Symbol for order demo |
| `POLYMARKET_GRPC_ADDR` | (derived from API URL) | gRPC endpoint address |
| `POLYMARKET_VERBOSE` | `false` | Enable verbose logging |
| `POLYMARKET_TIMEOUT` | `30` | Request timeout (seconds) |

## Running Examples

### Run All REST Examples

```bash
cd examples
python3 run_all.py
```

### Run with Background gRPC Streaming

Start background streaming subscriptions while running REST examples:

```bash
python3 examples/run_all.py --streaming
```

This will:
1. Connect to market data, order, and position streams
2. Run all 10 REST examples
3. Display streaming statistics at the end

### Run Individual REST Examples

```bash
# Health check (no authentication required)
python3 examples/01_health_check.py

# Get current user info
python3 examples/02_whoami.py

# List trading accounts
python3 examples/03_list_accounts.py

# Get account balance
python3 examples/04_get_balance.py

# List positions
python3 examples/05_list_positions.py

# List tradeable instruments
python3 examples/06_list_instruments.py

# List all symbols
python3 examples/07_list_symbols.py

# Search order history
python3 examples/08_search_orders.py

# List users in firm
python3 examples/09_list_users.py

# Place and cancel order (safe demo)
python3 examples/10_place_and_cancel_order.py
```

### Run gRPC Streaming Examples

```bash
# Real-time market data
python3 examples/11_grpc_market_data_stream.py

# Order status updates
python3 examples/12_grpc_order_subscription.py

# Position changes
python3 examples/13_grpc_position_subscription.py

# Funding transactions
python3 examples/14_grpc_funding_subscription.py

# Drop copy (execution feed)
python3 examples/15_grpc_dropcopy_subscription.py
```

## File Structure

```
python/
├── README.md           # This file
├── requirements.txt    # Python dependencies
├── sample_env.sh       # Sample environment configuration
├── config.py           # Configuration loading and validation
├── auth.py             # Authentication (private_key_jwt)
├── api_client.py       # REST API client
├── grpc_client.py      # gRPC streaming client
├── gen/                # Pre-generated protocol buffer files
│   └── polymarket/v1/  # gRPC service definitions
└── examples/
    ├── 01_health_check.py      # Health check (no auth)
    ├── 02_whoami.py            # Get current user
    ├── 03_list_accounts.py     # List accounts
    ├── 04_get_balance.py       # Get balance
    ├── 05_list_positions.py    # List positions
    ├── 06_list_instruments.py  # List instruments
    ├── 07_list_symbols.py      # List symbols
    ├── 08_search_orders.py     # Search orders
    ├── 09_list_users.py        # List users
    ├── 10_place_and_cancel_order.py  # Place and cancel order
    ├── 11_grpc_market_data_stream.py # Market data streaming
    ├── 12_grpc_order_subscription.py # Order updates
    ├── 13_grpc_position_subscription.py # Position updates
    ├── 14_grpc_funding_subscription.py  # Funding updates
    ├── 15_grpc_dropcopy_subscription.py # Drop copy feed
    └── run_all.py              # Run all examples
```

## Using the REST API Client in Your Code

```python
from config import load_config
from api_client import PolymarketClient

# Load configuration from environment
config = load_config()

# Create client
client = PolymarketClient(config)

# Make API calls
status, result = client.health()
print(f"Health: {result}")

status, result = client.whoami()
print(f"User: {result.get('user')}")

status, result = client.get_balance(config.account, "USD")
print(f"Balance: ${float(result.get('balance', 0)):,.2f}")
```

## Using the gRPC Streaming Client

```python
from config import load_config
from grpc_client import PolymarketGrpcClient

# Load configuration
config = load_config()

# Create gRPC client
with PolymarketGrpcClient(config) as client:
    # Subscribe to market data
    for response in client.subscribe_market_data([config.test_symbol], depth=5):
        if response.HasField('update'):
            update = response.update
            print(f"Symbol: {update.symbol}, Bids: {len(update.bids)}")

        # Break after some updates
        break
```

## Authentication Flow

This client uses **private_key_jwt** authentication:

1. Create a signed JWT using your RSA private key
2. Exchange the JWT for an access token
3. Use the access token for API requests

The client handles token caching and automatic refresh.

## Troubleshooting

### "Private key file not found"

Ensure `POLYMARKET_PRIVATE_KEY_PATH` points to a valid PEM file:

```bash
# Check the file exists
ls -la $POLYMARKET_PRIVATE_KEY_PATH

# Verify it's a valid RSA private key
openssl rsa -in $POLYMARKET_PRIVATE_KEY_PATH -check -noout
```

### "Missing required environment variables"

Source your environment file before running:

```bash
source my_env.sh
python3 examples/run_all.py
```

### "Authentication server returned 401"

- Verify your Client ID is correct
- Ensure your private key matches the public key registered with Polymarket
- Check that your credentials haven't expired

### gRPC Connection Issues

- Verify the gRPC address is correct (default derived from API URL)
- Check that port 443 is not blocked by a firewall
- Try setting `POLYMARKET_GRPC_ADDR` explicitly

### Connection timeout

- Verify the API URL is correct
- Check network connectivity
- Try increasing `POLYMARKET_TIMEOUT`

## Support

For API documentation, see: https://docs.polymarketexchange.com/

For issues with this sample code, contact **fix@qcex.com**.
