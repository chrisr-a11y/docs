// Package config provides configuration loading and validation for the Polymarket Exchange API client.
package config

import (
	"crypto/rsa"
	"crypto/x509"
	"encoding/pem"
	"errors"
	"fmt"
	"os"
	"strconv"
	"strings"
)

// Config holds all configuration for the Polymarket Exchange API client.
type Config struct {
	// Authentication settings
	ClientID     string
	PrivateKey   *rsa.PrivateKey
	AuthDomain   string
	AuthAudience string

	// API endpoints
	APIURL   string
	GRPCAddr string

	// User context
	ParticipantID string
	Account       string

	// Test settings
	TestSymbol string

	// Options
	Verbose bool
	Timeout int
}

// Load reads configuration from environment variables and validates it.
// It exits with a clear error message if required configuration is missing or invalid.
func Load() (*Config, error) {
	// Required environment variables (for API connection)
	required := map[string]string{
		"POLYMARKET_CLIENT_ID":        "",
		"POLYMARKET_PRIVATE_KEY_PATH": "",
		"POLYMARKET_API_URL":          "",
		"POLYMARKET_AUTH_DOMAIN":      "",
		"POLYMARKET_AUTH_AUDIENCE":    "",
	}

	// Check for missing required variables
	var missing []string
	for key := range required {
		val := os.Getenv(key)
		if val == "" {
			missing = append(missing, key)
		}
		required[key] = val
	}

	if len(missing) > 0 {
		return nil, fmt.Errorf("missing required environment variables:\n  - %s\n\nPlease source your environment file (e.g., source sample_env.sh)",
			strings.Join(missing, "\n  - "))
	}

	// Optional user context (set after KYC onboarding)
	// Note: Not required for RefData endpoints (ListInstruments, ListSymbols)
	participantID := os.Getenv("POLYMARKET_PARTICIPANT_ID")
	account := os.Getenv("POLYMARKET_ACCOUNT")

	// Load and validate private key
	privateKey, err := LoadPrivateKey(required["POLYMARKET_PRIVATE_KEY_PATH"])
	if err != nil {
		return nil, err
	}

	// Parse optional settings
	verbose := strings.ToLower(os.Getenv("POLYMARKET_VERBOSE")) == "true"
	timeout := 30
	if t := os.Getenv("POLYMARKET_TIMEOUT"); t != "" {
		if parsed, err := strconv.Atoi(t); err == nil {
			timeout = parsed
		}
	}

	// Derive gRPC address from API URL if not provided
	grpcAddr := os.Getenv("POLYMARKET_GRPC_ADDR")
	if grpcAddr == "" {
		grpcAddr = deriveGRPCAddr(required["POLYMARKET_API_URL"])
	}

	// Default test symbol
	testSymbol := os.Getenv("POLYMARKET_TEST_SYMBOL")
	if testSymbol == "" {
		testSymbol = "SBLIX-KC-YES" // Kansas City wins Super Bowl
	}

	return &Config{
		ClientID:      required["POLYMARKET_CLIENT_ID"],
		PrivateKey:    privateKey,
		AuthDomain:    required["POLYMARKET_AUTH_DOMAIN"],
		AuthAudience:  required["POLYMARKET_AUTH_AUDIENCE"],
		APIURL:        strings.TrimSuffix(required["POLYMARKET_API_URL"], "/"),
		GRPCAddr:      grpcAddr,
		ParticipantID: participantID,
		Account:       account,
		TestSymbol:    testSymbol,
		Verbose:       verbose,
		Timeout:       timeout,
	}, nil
}

// LoadPrivateKey reads and validates an RSA private key from a PEM file.
func LoadPrivateKey(path string) (*rsa.PrivateKey, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, fmt.Errorf("private key file not found: %s\nPlease set POLYMARKET_PRIVATE_KEY_PATH to the path of your private key", path)
		}
		return nil, fmt.Errorf("failed to read private key file: %w", err)
	}

	block, _ := pem.Decode(data)
	if block == nil {
		return nil, errors.New("failed to parse PEM block containing private key")
	}

	// Try PKCS8 format first (newer), then PKCS1 (older)
	var key interface{}
	key, err = x509.ParsePKCS8PrivateKey(block.Bytes)
	if err != nil {
		key, err = x509.ParsePKCS1PrivateKey(block.Bytes)
		if err != nil {
			return nil, fmt.Errorf("invalid private key format (tried PKCS8 and PKCS1): %w", err)
		}
	}

	rsaKey, ok := key.(*rsa.PrivateKey)
	if !ok {
		return nil, errors.New("key must be an RSA private key")
	}

	return rsaKey, nil
}

// deriveGRPCAddr attempts to derive a gRPC address from the API URL.
// For example: https://api.dev01.polymarketexchange.com -> grpc-api.dev01.polymarketexchange.com:443
func deriveGRPCAddr(apiURL string) string {
	// Remove protocol
	host := strings.TrimPrefix(apiURL, "https://")
	host = strings.TrimPrefix(host, "http://")

	// Remove path
	if idx := strings.Index(host, "/"); idx != -1 {
		host = host[:idx]
	}

	// Try to derive gRPC host
	// api.dev01.polymarketexchange.com -> grpc-api.dev01.polymarketexchange.com
	if strings.HasPrefix(host, "api.") {
		return "grpc-api." + strings.TrimPrefix(host, "api.") + ":443"
	}

	// Fallback: just append gRPC port
	return host + ":443"
}

// MustLoad calls Load and panics if there's an error.
// Use this in example programs for cleaner error handling.
func MustLoad() *Config {
	cfg, err := Load()
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: %v\n", err)
		os.Exit(1)
	}
	return cfg
}
