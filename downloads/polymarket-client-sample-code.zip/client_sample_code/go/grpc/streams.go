package grpc

import (
	"context"
	"fmt"
	"io"
	"log"
	"sync"

	polymarketv1 "github.com/polymarket/client-sample-code/go/gen/polymarket/v1"
)

// MarketDataSubscription manages a market data streaming subscription.
type MarketDataSubscription struct {
	stream  polymarketv1.MarketDataSubscriptionAPI_CreateMarketDataSubscriptionClient
	cancel  context.CancelFunc
	updates chan *polymarketv1.CreateMarketDataSubscriptionResponse
	done    chan struct{}
	err     error
	mu      sync.Mutex
}

// SubscribeMarketData creates a market data subscription.
func (c *Client) SubscribeMarketData(ctx context.Context, symbols []string, depth int32) (*MarketDataSubscription, error) {
	authCtx, err := c.AuthContext(ctx)
	if err != nil {
		return nil, err
	}

	streamCtx, cancel := context.WithCancel(authCtx)

	req := &polymarketv1.CreateMarketDataSubscriptionRequest{
		Symbols: symbols,
		Depth:   depth,
	}

	stream, err := c.MarketData.CreateMarketDataSubscription(streamCtx, req)
	if err != nil {
		cancel()
		return nil, fmt.Errorf("failed to create market data subscription: %w", err)
	}

	sub := &MarketDataSubscription{
		stream:  stream,
		cancel:  cancel,
		updates: make(chan *polymarketv1.CreateMarketDataSubscriptionResponse, 100),
		done:    make(chan struct{}),
	}

	// Start receiving in background
	go sub.receive()

	return sub, nil
}

func (s *MarketDataSubscription) receive() {
	defer close(s.done)
	defer close(s.updates)

	for {
		resp, err := s.stream.Recv()
		if err == io.EOF {
			return
		}
		if err != nil {
			s.mu.Lock()
			s.err = err
			s.mu.Unlock()
			return
		}

		select {
		case s.updates <- resp:
		default:
			// Channel full, drop oldest
			select {
			case <-s.updates:
				s.updates <- resp
			default:
			}
		}
	}
}

// Updates returns a channel of market data updates.
func (s *MarketDataSubscription) Updates() <-chan *polymarketv1.CreateMarketDataSubscriptionResponse {
	return s.updates
}

// Done returns a channel that is closed when the subscription ends.
func (s *MarketDataSubscription) Done() <-chan struct{} {
	return s.done
}

// Err returns any error that caused the subscription to end.
func (s *MarketDataSubscription) Err() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.err
}

// Close stops the subscription.
func (s *MarketDataSubscription) Close() {
	s.cancel()
}

// PositionSubscription manages a position streaming subscription.
type PositionSubscription struct {
	stream  polymarketv1.PositionAPI_CreatePositionSubscriptionClient
	cancel  context.CancelFunc
	updates chan *polymarketv1.CreatePositionSubscriptionResponse
	done    chan struct{}
	err     error
	mu      sync.Mutex
}

// SubscribePositions creates a position subscription.
func (c *Client) SubscribePositions(ctx context.Context, accounts []string) (*PositionSubscription, error) {
	authCtx, err := c.AuthContext(ctx)
	if err != nil {
		return nil, err
	}

	streamCtx, cancel := context.WithCancel(authCtx)

	req := &polymarketv1.CreatePositionSubscriptionRequest{
		Accounts: accounts,
	}

	stream, err := c.Positions.CreatePositionSubscription(streamCtx, req)
	if err != nil {
		cancel()
		return nil, fmt.Errorf("failed to create position subscription: %w", err)
	}

	sub := &PositionSubscription{
		stream:  stream,
		cancel:  cancel,
		updates: make(chan *polymarketv1.CreatePositionSubscriptionResponse, 100),
		done:    make(chan struct{}),
	}

	go sub.receive()

	return sub, nil
}

func (s *PositionSubscription) receive() {
	defer close(s.done)
	defer close(s.updates)

	for {
		resp, err := s.stream.Recv()
		if err == io.EOF {
			return
		}
		if err != nil {
			s.mu.Lock()
			s.err = err
			s.mu.Unlock()
			return
		}

		select {
		case s.updates <- resp:
		default:
		}
	}
}

// Updates returns a channel of position updates.
func (s *PositionSubscription) Updates() <-chan *polymarketv1.CreatePositionSubscriptionResponse {
	return s.updates
}

// Done returns a channel that is closed when the subscription ends.
func (s *PositionSubscription) Done() <-chan struct{} {
	return s.done
}

// Err returns any error that caused the subscription to end.
func (s *PositionSubscription) Err() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.err
}

// Close stops the subscription.
func (s *PositionSubscription) Close() {
	s.cancel()
}

// DropCopySubscription manages a drop copy streaming subscription.
type DropCopySubscription struct {
	stream  polymarketv1.DropCopyAPI_CreateDropCopySubscriptionClient
	cancel  context.CancelFunc
	updates chan *polymarketv1.CreateDropCopySubscriptionResponse
	done    chan struct{}
	err     error
	mu      sync.Mutex
}

// SubscribeDropCopy creates a drop copy subscription.
func (c *Client) SubscribeDropCopy(ctx context.Context, symbols []string) (*DropCopySubscription, error) {
	authCtx, err := c.AuthContext(ctx)
	if err != nil {
		return nil, err
	}

	streamCtx, cancel := context.WithCancel(authCtx)

	req := &polymarketv1.CreateDropCopySubscriptionRequest{
		Symbols: symbols,
	}

	stream, err := c.DropCopy.CreateDropCopySubscription(streamCtx, req)
	if err != nil {
		cancel()
		return nil, fmt.Errorf("failed to create drop copy subscription: %w", err)
	}

	sub := &DropCopySubscription{
		stream:  stream,
		cancel:  cancel,
		updates: make(chan *polymarketv1.CreateDropCopySubscriptionResponse, 100),
		done:    make(chan struct{}),
	}

	go sub.receive()

	return sub, nil
}

func (s *DropCopySubscription) receive() {
	defer close(s.done)
	defer close(s.updates)

	for {
		resp, err := s.stream.Recv()
		if err == io.EOF {
			return
		}
		if err != nil {
			s.mu.Lock()
			s.err = err
			s.mu.Unlock()
			return
		}

		select {
		case s.updates <- resp:
		default:
		}
	}
}

// Updates returns a channel of drop copy updates.
func (s *DropCopySubscription) Updates() <-chan *polymarketv1.CreateDropCopySubscriptionResponse {
	return s.updates
}

// Done returns a channel that is closed when the subscription ends.
func (s *DropCopySubscription) Done() <-chan struct{} {
	return s.done
}

// Err returns any error that caused the subscription to end.
func (s *DropCopySubscription) Err() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.err
}

// Close stops the subscription.
func (s *DropCopySubscription) Close() {
	s.cancel()
}

// FundingSubscription manages a funding streaming subscription.
type FundingSubscription struct {
	stream  polymarketv1.FundingAPI_CreateFundingTransactionSubscriptionClient
	cancel  context.CancelFunc
	updates chan *polymarketv1.CreateFundingTransactionSubscriptionResponse
	done    chan struct{}
	err     error
	mu      sync.Mutex
}

// SubscribeFunding creates a funding transaction subscription.
func (c *Client) SubscribeFunding(ctx context.Context) (*FundingSubscription, error) {
	authCtx, err := c.AuthContext(ctx)
	if err != nil {
		return nil, err
	}

	streamCtx, cancel := context.WithCancel(authCtx)

	req := &polymarketv1.CreateFundingTransactionSubscriptionRequest{}

	stream, err := c.Funding.CreateFundingTransactionSubscription(streamCtx, req)
	if err != nil {
		cancel()
		return nil, fmt.Errorf("failed to create funding subscription: %w", err)
	}

	sub := &FundingSubscription{
		stream:  stream,
		cancel:  cancel,
		updates: make(chan *polymarketv1.CreateFundingTransactionSubscriptionResponse, 100),
		done:    make(chan struct{}),
	}

	go sub.receive()

	return sub, nil
}

func (s *FundingSubscription) receive() {
	defer close(s.done)
	defer close(s.updates)

	for {
		resp, err := s.stream.Recv()
		if err == io.EOF {
			return
		}
		if err != nil {
			s.mu.Lock()
			s.err = err
			s.mu.Unlock()
			return
		}

		select {
		case s.updates <- resp:
		default:
		}
	}
}

// Updates returns a channel of funding updates.
func (s *FundingSubscription) Updates() <-chan *polymarketv1.CreateFundingTransactionSubscriptionResponse {
	return s.updates
}

// Done returns a channel that is closed when the subscription ends.
func (s *FundingSubscription) Done() <-chan struct{} {
	return s.done
}

// Err returns any error that caused the subscription to end.
func (s *FundingSubscription) Err() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.err
}

// Close stops the subscription.
func (s *FundingSubscription) Close() {
	s.cancel()
}

// OrderSubscription manages an order streaming subscription.
type OrderSubscription struct {
	stream  polymarketv1.OrderEntryAPI_CreateOrderSubscriptionClient
	cancel  context.CancelFunc
	updates chan *polymarketv1.CreateOrderSubscriptionResponse
	done    chan struct{}
	err     error
	mu      sync.Mutex
}

// SubscribeOrders creates an order subscription.
func (c *Client) SubscribeOrders(ctx context.Context, accounts []string) (*OrderSubscription, error) {
	authCtx, err := c.AuthContext(ctx)
	if err != nil {
		return nil, err
	}

	streamCtx, cancel := context.WithCancel(authCtx)

	req := &polymarketv1.CreateOrderSubscriptionRequest{
		Accounts: accounts,
	}

	stream, err := c.Orders.CreateOrderSubscription(streamCtx, req)
	if err != nil {
		cancel()
		return nil, fmt.Errorf("failed to create order subscription: %w", err)
	}

	sub := &OrderSubscription{
		stream:  stream,
		cancel:  cancel,
		updates: make(chan *polymarketv1.CreateOrderSubscriptionResponse, 100),
		done:    make(chan struct{}),
	}

	go sub.receive()

	return sub, nil
}

func (s *OrderSubscription) receive() {
	defer close(s.done)
	defer close(s.updates)

	for {
		resp, err := s.stream.Recv()
		if err == io.EOF {
			return
		}
		if err != nil {
			s.mu.Lock()
			s.err = err
			s.mu.Unlock()
			return
		}

		select {
		case s.updates <- resp:
		default:
		}
	}
}

// Updates returns a channel of order updates.
func (s *OrderSubscription) Updates() <-chan *polymarketv1.CreateOrderSubscriptionResponse {
	return s.updates
}

// Done returns a channel that is closed when the subscription ends.
func (s *OrderSubscription) Done() <-chan struct{} {
	return s.done
}

// Err returns any error that caused the subscription to end.
func (s *OrderSubscription) Err() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.err
}

// Close stops the subscription.
func (s *OrderSubscription) Close() {
	s.cancel()
}

// LogStreamUpdates is a helper that logs streaming updates for debugging.
func LogStreamUpdates[T any](name string, updates <-chan T, done <-chan struct{}) {
	go func() {
		count := 0
		for {
			select {
			case update, ok := <-updates:
				if !ok {
					log.Printf("[%s] Stream closed after %d updates", name, count)
					return
				}
				count++
				if count <= 5 {
					log.Printf("[%s] Update #%d: %+v", name, count, update)
				} else if count == 6 {
					log.Printf("[%s] (suppressing further log output...)", name)
				}
			case <-done:
				log.Printf("[%s] Stream done after %d updates", name, count)
				return
			}
		}
	}()
}
