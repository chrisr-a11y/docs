# Polymarket Exchange API - Go Client Examples

This directory contains Go sample code demonstrating how to authenticate with and use the Polymarket Exchange API, including both REST and gRPC streaming endpoints.

## Prerequisites

- Go 1.21 or higher
- Auth0 credentials (Client ID and private key) provided by Polymarket
- A registered trading account

## Installation

1. Install dependencies:

```bash
go mod download
```

2. Configure your environment:

```bash
# Copy the sample environment file
cp sample_env.sh my_env.sh

# Edit with your actual credentials
nano my_env.sh  # or use your preferred editor

# Source the environment
source my_env.sh
```

## Configuration

The following environment variables are required:

| Variable | Description |
|----------|-------------|
| `POLYMARKET_CLIENT_ID` | Your Auth0 Client ID |
| `POLYMARKET_PRIVATE_KEY_PATH` | Path to your RSA private key (PEM format) |
| `POLYMARKET_API_URL` | API base URL (e.g., `https://api.dev01.polymarketexchange.com`) |
| `POLYMARKET_AUTH0_DOMAIN` | Auth0 domain (e.g., `pmx-dev01.us.auth0.com`) |
| `POLYMARKET_AUTH0_AUDIENCE` | Auth0 audience (matches API URL) |
| `POLYMARKET_PARTICIPANT_ID` | Your participant ID (e.g., `firms/Your-Firm/users/your-user`) |
| `POLYMARKET_ACCOUNT` | Your trading account (e.g., `firms/Your-Firm/accounts/your-account`) |

Optional variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `POLYMARKET_TEST_SYMBOL` | `SBLIX-KC-YES` | Symbol for order demo (Kansas City wins Super Bowl) |
| `POLYMARKET_GRPC_ADDR` | (derived from API URL) | gRPC endpoint address |
| `POLYMARKET_VERBOSE` | `false` | Enable verbose logging |
| `POLYMARKET_TIMEOUT` | `30` | Request timeout (seconds) |

## Running Examples

### Run All REST Examples

```bash
cd cmd/run_all
go run .
```

### Run All Examples with Background Streaming

```bash
cd cmd/run_all
go run . -streaming
```

### Run Individual Examples

```bash
# REST API Examples
go run ./examples/01_health_check     # Health check (no auth)
go run ./examples/02_whoami           # Get current user
go run ./examples/03_list_accounts    # List accounts
go run ./examples/04_get_balance      # Get balance
go run ./examples/05_list_positions   # List positions
go run ./examples/06_list_instruments # List instruments
go run ./examples/07_list_symbols     # List symbols
go run ./examples/08_search_orders    # Search orders
go run ./examples/09_list_users       # List users
go run ./examples/10_place_and_cancel_order  # Place and cancel order

# gRPC Streaming Examples
go run ./examples/11_grpc_market_data_stream   # Market data stream
go run ./examples/12_grpc_order_subscription   # Order updates
go run ./examples/13_grpc_position_subscription # Position updates
go run ./examples/14_grpc_funding_subscription  # Funding notifications
go run ./examples/15_grpc_dropcopy_subscription # Drop copy feed
go run ./examples/16_connect_streaming         # Connect protocol
```

## File Structure

```
go/
├── README.md                # This file
├── go.mod                   # Go module definition
├── go.sum                   # Dependencies checksum
├── sample_env.sh            # Sample environment configuration
├── config/
│   └── config.go            # Configuration loading and validation
├── auth/
│   └── auth.go              # Auth0 authentication
├── rest/
│   └── client.go            # REST API client
├── grpc/
│   ├── client.go            # gRPC client setup
│   └── streams.go           # Streaming subscription helpers
├── gen/
│   └── polymarket/v1/       # Pre-generated proto files
├── examples/
│   ├── 01_health_check/     # Health check (no auth)
│   ├── 02_whoami/           # Get current user
│   ├── 03_list_accounts/    # List accounts
│   ├── 04_get_balance/      # Get balance
│   ├── 05_list_positions/   # List positions
│   ├── 06_list_instruments/ # List instruments
│   ├── 07_list_symbols/     # List symbols
│   ├── 08_search_orders/    # Search orders
│   ├── 09_list_users/       # List users
│   ├── 10_place_and_cancel_order/  # Place and cancel order
│   ├── 11_grpc_market_data_stream/ # Market data stream
│   ├── 12_grpc_order_subscription/ # Order subscription
│   ├── 13_grpc_position_subscription/ # Position subscription
│   ├── 14_grpc_funding_subscription/  # Funding subscription
│   ├── 15_grpc_dropcopy_subscription/ # Drop copy subscription
│   └── 16_connect_streaming/          # Connect protocol
└── cmd/
    └── run_all/             # Run all examples
```

## Using the API Client in Your Code

### REST API

```go
package main

import (
    "fmt"
    "github.com/polymarket/client-sample-code/go/config"
    "github.com/polymarket/client-sample-code/go/rest"
)

func main() {
    // Load configuration from environment
    cfg := config.MustLoad()

    // Create REST client
    client := rest.NewClient(cfg)

    // Make API calls
    health, _ := client.Health()
    fmt.Printf("Health: %s\n", health.Status)

    whoami, _ := client.WhoAmI()
    fmt.Printf("User: %s\n", whoami.User)

    balance, _ := client.GetBalance(cfg.Account, "USD")
    fmt.Printf("Balance: %s\n", balance.Balance)
}
```

### gRPC Streaming

```go
package main

import (
    "context"
    "fmt"
    "github.com/polymarket/client-sample-code/go/config"
    grpcclient "github.com/polymarket/client-sample-code/go/grpc"
)

func main() {
    cfg := config.MustLoad()

    // Create gRPC client
    client, _ := grpcclient.NewClient(cfg)
    defer client.Close()

    // Subscribe to market data
    sub, _ := client.SubscribeMarketData(context.Background(), []string{"SBLIX-KC-YES"}, 5)
    defer sub.Close()

    // Receive updates
    for update := range sub.Updates() {
        if md := update.GetUpdate(); md != nil {
            fmt.Printf("%s: %d bids, %d offers\n", md.Symbol, len(md.Bids), len(md.Offers))
        }
    }
}
```

## Authentication Flow

This client uses **private_key_jwt** authentication with Auth0:

1. Create a signed JWT using your RSA private key
2. Exchange the JWT for an access token at Auth0
3. Use the access token for API requests

The client handles token caching and automatic refresh.

## Troubleshooting

### "Private key file not found"

Ensure `POLYMARKET_PRIVATE_KEY_PATH` points to a valid PEM file:

```bash
# Check the file exists
ls -la $POLYMARKET_PRIVATE_KEY_PATH

# Verify it's a valid RSA private key
openssl rsa -in $POLYMARKET_PRIVATE_KEY_PATH -check -noout
```

### "Missing required environment variables"

Source your environment file before running:

```bash
source my_env.sh
cd cmd/run_all && go run .
```

### "Auth0 returned 401"

- Verify your Client ID is correct
- Ensure your private key matches the public key registered with Auth0
- Check that your credentials haven't expired

### gRPC Connection Issues

- Verify the gRPC address is correct
- Check that port 443 is not blocked by a firewall
- Try setting `POLYMARKET_GRPC_ADDR` explicitly

## Support

For API documentation, see: https://docs.polymarketexchange.com/

For issues with this sample code, contact your Polymarket representative.
