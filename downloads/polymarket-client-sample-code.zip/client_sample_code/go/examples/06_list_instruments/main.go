// Example 06: List Instruments
//
// Demonstrates listing tradeable instruments on the exchange with pagination support.
//
// Note: This endpoint requires authentication but does NOT require a participant_id.
// You can call this before completing KYC onboarding.
package main

import (
	"fmt"
	"os"

	"github.com/polymarket/client-sample-code/go/config"
	"github.com/polymarket/client-sample-code/go/rest"
)

func main() {
	fmt.Println("============================================================")
	fmt.Println("Example 06: List Instruments (with Pagination)")
	fmt.Println("============================================================")
	fmt.Println()

	// Load configuration
	cfg := config.MustLoad()

	// Create REST client
	client := rest.NewClient(cfg)

	// Method 1: Simple - get all instruments (uses pagination internally)
	fmt.Println("Method 1: Fetch all instruments (auto-pagination)")
	all, err := client.ListAllInstruments(100)
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: %v\n", err)
		os.Exit(1)
	}
	fmt.Printf("  Total instruments: %d\n\n", len(all))

	// Method 2: Manual pagination for more control
	fmt.Println("Method 2: Manual pagination (pageSize=5)")
	pageToken := ""
	pageNum := 0
	for pageNum < 3 { // Show first 3 pages
		pageNum++
		resp, err := client.ListInstrumentsWithPagination(rest.ListInstrumentsRequest{
			PageSize:  5,
			PageToken: pageToken,
		})
		if err != nil {
			fmt.Fprintf(os.Stderr, "ERROR: %v\n", err)
			break
		}
		fmt.Printf("  Page %d: %d instruments", pageNum, len(resp.Instruments))
		if resp.Eof {
			fmt.Print(" (end of results)")
		}
		fmt.Println()

		// Display instruments
		for i, inst := range resp.Instruments {
			fmt.Printf("    %d.%d. %s - %s (state: %s)\n",
				pageNum, i+1, inst.Symbol, inst.Description, inst.State)
		}

		if resp.Eof {
			break
		}
		pageToken = resp.NextPageToken
	}

	fmt.Println()

	// Method 3: Filter by symbols
	fmt.Println("Method 3: Filter by specific symbols")
	if len(all) > 0 {
		// Get first two symbols for filtering demo
		filterSymbols := []string{}
		for i := 0; i < 2 && i < len(all); i++ {
			filterSymbols = append(filterSymbols, all[i].Symbol)
		}

		resp, err := client.ListInstrumentsWithPagination(rest.ListInstrumentsRequest{
			Symbols: filterSymbols,
		})
		if err != nil {
			fmt.Fprintf(os.Stderr, "ERROR: %v\n", err)
		} else {
			fmt.Printf("  Filtered to %d instruments:\n", len(resp.Instruments))
			for _, inst := range resp.Instruments {
				fmt.Printf("    - %s: %s\n", inst.Symbol, inst.Description)
			}
		}
	}

	fmt.Println()
	fmt.Println("Success!")
}
