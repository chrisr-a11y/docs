// Example 10: Place and Cancel Order
//
// Demonstrates placing a limit order and then immediately canceling it.
//
// This example uses a very unattractive price ($0.01) to ensure the order
// won't fill before we cancel it. This is a safe way to test the trading
// API without any actual execution risk.
//
// Default symbol: SBLIX-KC-YES (Kansas City wins Super Bowl)
package main

import (
	"fmt"
	"os"

	"github.com/google/uuid"
	"github.com/polymarket/client-sample-code/go/config"
	"github.com/polymarket/client-sample-code/go/rest"
)

func main() {
	fmt.Println("============================================================")
	fmt.Println("Example 10: Place and Cancel Order")
	fmt.Println("============================================================")
	fmt.Println()

	// Load configuration
	cfg := config.MustLoad()

	// Create REST client
	client := rest.NewClient(cfg)

	// Generate unique client order ID
	clOrdID := fmt.Sprintf("sample-%s", uuid.New().String())

	// Order parameters
	symbol := cfg.TestSymbol
	side := "SIDE_BUY"
	orderType := "ORDER_TYPE_LIMIT"
	quantity := int64(1)
	price := int64(1) // $0.01 - extremely unattractive, won't fill

	fmt.Println("Step 1: Placing limit order...")
	fmt.Printf("  Symbol: %s\n", symbol)
	fmt.Printf("  Side: %s\n", side)
	fmt.Printf("  Type: %s\n", orderType)
	fmt.Printf("  Quantity: %d\n", quantity)
	fmt.Printf("  Price: $%.2f (very unattractive)\n", float64(price)/100)
	fmt.Printf("  Account: %s\n", cfg.Account)
	fmt.Printf("  Client Order ID: %s\n", clOrdID)
	fmt.Println()

	// Place order
	orderReq := &rest.PlaceOrderRequest{
		Symbol:      symbol,
		Side:        side,
		Type:        orderType,
		OrderQty:    quantity,
		Price:       price,
		Account:     cfg.Account,
		ClOrdID:     clOrdID,
		TimeInForce: "TIME_IN_FORCE_DAY",
	}

	result, err := client.PlaceOrder(orderReq)
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: Failed to place order: %v\n", err)
		os.Exit(1)
	}

	orderID := result.OrderID
	fmt.Println("  Order placed successfully!")
	fmt.Printf("  Order ID: %s\n", orderID)
	fmt.Println()

	if orderID == "" {
		fmt.Fprintln(os.Stderr, "ERROR: No order ID returned")
		os.Exit(1)
	}

	// Cancel order
	fmt.Println("Step 2: Canceling order...")
	err = client.CancelOrder(orderID, cfg.Account, symbol)
	if err != nil {
		fmt.Fprintf(os.Stderr, "WARNING: Cancel may have failed: %v\n", err)
		fmt.Println()
		fmt.Println("Please check the order status manually.")
		os.Exit(1)
	}

	fmt.Println("  Order canceled successfully!")
	fmt.Println()
	fmt.Println("Trade API test completed successfully!")
	fmt.Println("(Order was placed and immediately canceled - no execution)")
}
