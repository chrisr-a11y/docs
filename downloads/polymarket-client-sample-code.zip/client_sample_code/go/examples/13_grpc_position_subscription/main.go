// Example 13: gRPC Position Subscription
//
// Demonstrates subscribing to position updates via gRPC.
// The subscription provides real-time position changes.
package main

import (
	"context"
	"fmt"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/polymarket/client-sample-code/go/config"
	grpcclient "github.com/polymarket/client-sample-code/go/grpc"
)

func main() {
	fmt.Println("============================================================")
	fmt.Println("Example 13: gRPC Position Subscription")
	fmt.Println("============================================================")
	fmt.Println()

	// Load configuration
	cfg := config.MustLoad()

	// Create gRPC client
	fmt.Printf("Connecting to gRPC server: %s\n", cfg.GRPCAddr)
	client, err := grpcclient.NewClient(cfg)
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: %v\n", err)
		os.Exit(1)
	}
	defer client.Close()

	// Subscribe to positions for our account
	accounts := []string{cfg.Account}

	fmt.Printf("Subscribing to position updates for accounts: %v\n", accounts)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	sub, err := client.SubscribePositions(ctx, accounts)
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: Failed to subscribe: %v\n", err)
		os.Exit(1)
	}
	defer sub.Close()

	fmt.Println("Subscription active. Waiting for position updates...")
	fmt.Println("(Press Ctrl+C to stop)")
	fmt.Println()

	// Handle graceful shutdown
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)

	// Receive updates for 30 seconds or until interrupted
	timeout := time.After(30 * time.Second)
	updateCount := 0

	for {
		select {
		case <-sigChan:
			fmt.Println("\nReceived interrupt, shutting down...")
			return

		case <-timeout:
			fmt.Printf("\nTimeout reached after 30 seconds. Received %d updates.\n", updateCount)
			return

		case <-sub.Done():
			if err := sub.Err(); err != nil {
				fmt.Fprintf(os.Stderr, "\nStream ended with error: %v\n", err)
			} else {
				fmt.Println("\nStream ended normally.")
			}
			return

		case update, ok := <-sub.Updates():
			if !ok {
				fmt.Println("\nUpdates channel closed.")
				return
			}
			updateCount++

			// Log updates
			if snapshot := update.GetSnapshot(); snapshot != nil {
				fmt.Printf("Update #%d: Snapshot with %d positions\n", updateCount, len(snapshot.Positions))
				for i, pos := range snapshot.Positions {
					if i < 5 {
						fmt.Printf("  - %s: net=%d, cost=%d\n",
							pos.Symbol, pos.NetPosition, pos.Cost)
					}
				}
				if len(snapshot.Positions) > 5 {
					fmt.Printf("  ... and %d more\n", len(snapshot.Positions)-5)
				}
			} else if posUpdate := update.GetUpdate(); posUpdate != nil {
				fmt.Printf("Update #%d: Position change\n", updateCount)
				for _, pos := range posUpdate.Positions {
					fmt.Printf("  - %s: net=%d, cost=%d\n",
						pos.Symbol, pos.NetPosition, pos.Cost)
				}
			} else if update.GetHeartbeat() != nil {
				fmt.Printf("Update #%d: Heartbeat\n", updateCount)
			}
		}
	}
}
