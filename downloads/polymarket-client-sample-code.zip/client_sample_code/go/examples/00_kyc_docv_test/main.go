// Example: KYC DocV (Document Verification) Test
//
// Tests the Socure DocV flow using sandbox DOB triggers. These DOBs trigger
// document verification and return SDK credentials for mobile integration.
//
// Socure Sandbox DocV Test DOBs (from Socure ID+ Test Cases PDF):
//   - 1985-09-02: DocV Accept (after document submission)
//   - 1985-09-05: DocV Reject (after document submission)
//   - 1985-09-26: DocV Review (after document submission)
//   - 1985-09-01: DocV Resubmit (after document submission)
//
// All DOBs above will trigger DocV (REVIEW/ON_HOLD status) and return:
//   - docvTransactionToken: Token to pass to SDK's launch() method
//   - sdkKey: Public key for initializing Socure DocV SDK
//   - url: Web URL for document verification
//   - qrCode: QR code image (base64 PNG) for mobile scanning
//   - eventId: Socure event identifier
//
// The DOB determines the OUTCOME after DocV completion, not whether DocV triggers.
package main

import (
	"fmt"
	"os"
	"time"

	"github.com/polymarket/client-sample-code/go/config"
	"github.com/polymarket/client-sample-code/go/rest"
)

// DocVTestCase represents a test case for DocV DOB triggers
type DocVTestCase struct {
	DOB             string
	ExpectedOutcome string
	Description     string
}

// DocVTestResult represents the result of a DocV test
type DocVTestResult struct {
	DOB                   string
	ExpectedOutcome       string
	HTTPStatus            int
	DocVTriggered         bool
	SDKKeyPresent         bool
	TransactionTokenPresent bool
	URLPresent            bool
	Passed                bool
}

var docVTestCases = []DocVTestCase{
	{"1985-09-02", "Accept", "User will be approved after DocV completion"},
	{"1985-09-05", "Reject", "User will be rejected after DocV completion"},
	{"1985-09-26", "Review", "User will need manual review after DocV"},
	{"1985-09-01", "Resubmit", "User will need to resubmit documents"},
}

func testDocVTrigger(client *rest.Client, tc DocVTestCase) DocVTestResult {
	userID := fmt.Sprintf("docv-test-%s-%d", tc.ExpectedOutcome, time.Now().Unix())

	fmt.Printf("\n--- Testing DOB %s (%s) ---\n", tc.DOB, tc.ExpectedOutcome)
	fmt.Printf("  Expected: %s\n", tc.Description)

	req := &rest.KYCStartRequest{
		UserID:      userID,
		FirstName:   "DocV",
		LastName:    "Test" + tc.ExpectedOutcome,
		DateOfBirth: tc.DOB,
		Email:       fmt.Sprintf("%s@example.com", userID),
		PhoneNumber: "+14155551212",
		SSN:         "000000000",
		Address: rest.KYCAddress{
			AddressLine1: "123 Test Street",
			City:         "New York",
			State:        "NY",
			PostalCode:   "10001",
			Country:      "US",
		},
	}

	result := DocVTestResult{
		DOB:             tc.DOB,
		ExpectedOutcome: tc.ExpectedOutcome,
		HTTPStatus:      200,
	}

	resp, err := client.KYCStart(req)
	if err != nil {
		fmt.Printf("  ERROR: %v\n", err)
		result.HTTPStatus = 0
		return result
	}

	fmt.Printf("  Decision: %s, Status: %s\n", resp.Status.Decision, resp.Status.Status)
	fmt.Printf("  SubStatus: %s\n", resp.Status.SubStatus)

	if resp.DocV != nil {
		result.DocVTriggered = true
		result.SDKKeyPresent = resp.DocV.SDKKey != ""
		result.TransactionTokenPresent = resp.DocV.DocVTransactionToken != ""
		result.URLPresent = resp.DocV.URL != ""

		fmt.Printf("  DocV Data Present: YES\n")
		fmt.Printf("    SDK Key: %s\n", resp.DocV.SDKKey)

		token := resp.DocV.DocVTransactionToken
		if len(token) > 50 {
			token = token[:50]
		}
		fmt.Printf("    Transaction Token: %s...\n", token)
		fmt.Printf("    URL: %s\n", resp.DocV.URL)
		fmt.Printf("    Event ID: %s\n", resp.DocV.EventID)

		if resp.DocV.QRCode != "" {
			fmt.Printf("    QR Code: <present>\n")
		} else {
			fmt.Printf("    QR Code: <missing>\n")
		}

		result.Passed = result.SDKKeyPresent && result.TransactionTokenPresent && result.URLPresent
	} else {
		fmt.Printf("  DocV Data Present: NO\n")
	}

	return result
}

func boolToStr(b bool) string {
	if b {
		return "YES"
	}
	return "NO"
}

func passToStr(b bool) string {
	if b {
		return "PASS"
	}
	return "FAIL"
}

func main() {
	fmt.Println("======================================================================")
	fmt.Println("KYC DocV (Document Verification) Test")
	fmt.Println("======================================================================")
	fmt.Println()
	fmt.Println("This test verifies that Socure DocV DOBs trigger document verification")
	fmt.Println("and return the SDK credentials needed for mobile integration.")
	fmt.Println()
	fmt.Println("Reference: Socure ID+ Test Cases PDF, Section 3 (DocV)")
	fmt.Println()

	cfg := config.MustLoad()
	client := rest.NewClient(cfg)

	var results []DocVTestResult

	for _, tc := range docVTestCases {
		result := testDocVTrigger(client, tc)
		results = append(results, result)
		time.Sleep(1 * time.Second)
	}

	// Summary
	fmt.Println()
	fmt.Println("======================================================================")
	fmt.Println("Test Summary")
	fmt.Println("======================================================================")

	passed := 0
	for _, r := range results {
		if r.Passed {
			passed++
		}
	}

	fmt.Printf("\nResults: %d/%d tests passed\n\n", passed, len(results))

	fmt.Printf("%-12s %-10s %-6s %-8s %-8s %-6s %-6s\n", "DOB", "Outcome", "DocV", "SDK Key", "Token", "URL", "Pass")
	fmt.Println("----------------------------------------------------------------------")

	for _, r := range results {
		fmt.Printf("%-12s %-10s %-6s %-8s %-8s %-6s %-6s\n",
			r.DOB,
			r.ExpectedOutcome,
			boolToStr(r.DocVTriggered),
			boolToStr(r.SDKKeyPresent),
			boolToStr(r.TransactionTokenPresent),
			boolToStr(r.URLPresent),
			passToStr(r.Passed),
		)
	}

	fmt.Println()

	if passed == len(results) {
		fmt.Println("All DocV tests passed! SDK credentials are being returned correctly.")
		fmt.Println()
		fmt.Println("To integrate DocV in your mobile app:")
		fmt.Println("  1. Initialize Socure SDK with the 'sdkKey'")
		fmt.Println("  2. Call SDK.launch() with the 'docvTransactionToken'")
		fmt.Println("  3. Handle success/failure callbacks from the SDK")
		fmt.Println()
		os.Exit(0)
	} else {
		fmt.Println("Some tests failed. Check the DocV configuration.")
		os.Exit(1)
	}
}
