// Example 18: Historical Positions
//
// Demonstrates querying positions at a specific point in time using:
// - AsOfTime: RFC3339 timestamp for exact point-in-time queries
// - AsOfDate: Year/month/day for end-of-trading-day queries
//
// Use cases:
// - End-of-day reports and P&L calculations
// - Regulatory snapshots at specific timestamps
// - Position reconciliation with external records
// - Audit trail and compliance reviews
//
// Note: AsOfTime and AsOfDate are mutually exclusive.
//
//	Use one or the other, not both.
package main

import (
	"fmt"
	"os"

	"github.com/polymarket/client-sample-code/go/config"
	"github.com/polymarket/client-sample-code/go/rest"
)

func main() {
	fmt.Println("============================================================")
	fmt.Println("Example 18: Historical Positions")
	fmt.Println("============================================================")
	fmt.Println()

	// Load configuration
	cfg := config.MustLoad()

	// Create REST client
	client := rest.NewClient(cfg)

	// -------------------------------------------------------------------------
	// Example 1: Query by timestamp (AsOfTime)
	// -------------------------------------------------------------------------
	fmt.Println("1. Query positions by timestamp (AsOfTime)")
	fmt.Println("--------------------------------------------------")

	// Query positions as of a specific timestamp
	// Format: RFC3339 (e.g., "2026-01-02T17:00:00Z")
	timestamp := "2025-12-21T23:00:00Z"
	fmt.Printf("   Account: %s\n", cfg.Account)
	fmt.Printf("   As of time: %s\n", timestamp)

	result, err := client.ListHistoricalPositions(cfg.Account, rest.HistoricalPositionsOptions{
		AsOfTime: timestamp,
	})

	if err != nil {
		fmt.Printf("   Error: %v\n", err)
	} else {
		if len(result.Positions) == 0 {
			fmt.Println("   No positions found at that time.")
		} else {
			fmt.Printf("   Found %d position(s):\n", len(result.Positions))
			for _, pos := range result.Positions {
				fmt.Printf("     - %s: netPosition=%d\n", pos.Symbol, pos.NetPosition)
			}
		}
	}

	fmt.Println()

	// -------------------------------------------------------------------------
	// Example 2: Query by trade date (AsOfDate)
	// -------------------------------------------------------------------------
	fmt.Println("2. Query positions by trade date (AsOfDate)")
	fmt.Println("--------------------------------------------------")

	// Query positions at end of a specific trading day
	fmt.Printf("   Account: %s\n", cfg.Account)
	fmt.Printf("   As of date: 2025-12-22\n")

	result, err = client.ListHistoricalPositions(cfg.Account, rest.HistoricalPositionsOptions{
		AsOfDate: &rest.DateOption{
			Year:  2025,
			Month: 12,
			Day:   22,
		},
	})

	if err != nil {
		fmt.Printf("   Error: %v\n", err)
	} else {
		if len(result.Positions) == 0 {
			fmt.Println("   No positions found at that date.")
		} else {
			fmt.Printf("   Found %d position(s):\n", len(result.Positions))
			for _, pos := range result.Positions {
				fmt.Printf("     - %s: netPosition=%d\n", pos.Symbol, pos.NetPosition)
			}
		}
	}

	fmt.Println()
	fmt.Println("============================================================")
	fmt.Println("Done!")
	os.Exit(0)
}
