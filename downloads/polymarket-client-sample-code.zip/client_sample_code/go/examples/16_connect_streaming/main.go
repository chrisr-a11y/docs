// Example 16: Connect Protocol Streaming
//
// Demonstrates using the Connect protocol (HTTP/2) as an alternative to gRPC.
// Connect provides the same streaming capabilities but over standard HTTP,
// which can be easier to work with in some environments.
//
// Note: This example uses the Connect client library instead of native gRPC.
package main

import (
	"context"
	"crypto/tls"
	"fmt"
	"net"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"connectrpc.com/connect"
	"github.com/polymarket/client-sample-code/go/auth"
	"github.com/polymarket/client-sample-code/go/config"
	polymarketv1 "github.com/polymarket/client-sample-code/go/gen/polymarket/v1"
	"github.com/polymarket/client-sample-code/go/gen/polymarket/v1/polymarketv1connect"
)

func main() {
	fmt.Println("============================================================")
	fmt.Println("Example 16: Connect Protocol Streaming")
	fmt.Println("============================================================")
	fmt.Println()

	// Load configuration
	cfg := config.MustLoad()

	// Create HTTP client for Connect
	httpClient := &http.Client{
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{MinVersion: tls.VersionTLS12},
			DialContext: (&net.Dialer{
				Timeout:   30 * time.Second,
				KeepAlive: 30 * time.Second,
			}).DialContext,
			ForceAttemptHTTP2:     true,
			MaxIdleConns:          100,
			IdleConnTimeout:       90 * time.Second,
			TLSHandshakeTimeout:   10 * time.Second,
			ExpectContinueTimeout: 1 * time.Second,
		},
		Timeout: 0, // No timeout for streaming
	}

	// Create Connect client
	marketDataClient := polymarketv1connect.NewMarketDataSubscriptionAPIClient(
		httpClient,
		cfg.APIURL,
	)

	// Get auth token
	token, _, err := auth.GetAccessToken(cfg)
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: Failed to get auth token: %v\n", err)
		os.Exit(1)
	}

	// Create request with auth headers
	req := connect.NewRequest(&polymarketv1.CreateMarketDataSubscriptionRequest{
		Symbols: []string{cfg.TestSymbol},
		Depth:   5,
	})
	req.Header().Set("Authorization", "Bearer "+token)
	req.Header().Set("x-participant-id", cfg.ParticipantID)

	fmt.Printf("Connecting via Connect protocol to: %s\n", cfg.APIURL)
	fmt.Printf("Subscribing to market data for: %s\n", cfg.TestSymbol)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	stream, err := marketDataClient.CreateMarketDataSubscription(ctx, req)
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: Failed to create subscription: %v\n", err)
		os.Exit(1)
	}
	defer stream.Close()

	fmt.Println("Subscription active. Waiting for market data updates...")
	fmt.Println("(Press Ctrl+C to stop)")
	fmt.Println()

	// Handle graceful shutdown
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)

	// Receive updates
	updateCount := 0
	timeout := time.After(30 * time.Second)

	for {
		select {
		case <-sigChan:
			fmt.Println("\nReceived interrupt, shutting down...")
			return

		case <-timeout:
			fmt.Printf("\nTimeout reached after 30 seconds. Received %d updates.\n", updateCount)
			return

		default:
			// Non-blocking receive with timeout
			recvCtx, recvCancel := context.WithTimeout(ctx, 5*time.Second)
			if stream.Receive() {
				recvCancel()
				msg := stream.Msg()
				updateCount++

				if updateCount <= 5 {
					if md := msg.GetUpdate(); md != nil {
						fmt.Printf("Update #%d: %s - %d bids, %d offers\n",
							updateCount, md.Symbol, len(md.Bids), len(md.Offers))
					} else if msg.GetHeartbeat() != nil {
						fmt.Printf("Update #%d: Heartbeat\n", updateCount)
					}
				} else if updateCount == 6 {
					fmt.Println("(Suppressing further output...)")
				}
			} else {
				recvCancel()
				if err := stream.Err(); err != nil {
					fmt.Fprintf(os.Stderr, "\nStream error: %v\n", err)
				} else {
					fmt.Println("\nStream ended.")
				}
				return
			}
		}
	}
}
