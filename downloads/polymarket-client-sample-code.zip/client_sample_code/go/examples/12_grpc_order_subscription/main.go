// Example 12: gRPC Order Subscription
//
// Demonstrates subscribing to order status updates via gRPC.
// The subscription provides real-time order lifecycle events.
package main

import (
	"context"
	"fmt"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/polymarket/client-sample-code/go/config"
	grpcclient "github.com/polymarket/client-sample-code/go/grpc"
)

func main() {
	fmt.Println("============================================================")
	fmt.Println("Example 12: gRPC Order Subscription")
	fmt.Println("============================================================")
	fmt.Println()

	// Load configuration
	cfg := config.MustLoad()

	// Create gRPC client
	fmt.Printf("Connecting to gRPC server: %s\n", cfg.GRPCAddr)
	client, err := grpcclient.NewClient(cfg)
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: %v\n", err)
		os.Exit(1)
	}
	defer client.Close()

	// Subscribe to orders for our account
	accounts := []string{cfg.Account}

	fmt.Printf("Subscribing to order updates for accounts: %v\n", accounts)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	sub, err := client.SubscribeOrders(ctx, accounts)
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: Failed to subscribe: %v\n", err)
		os.Exit(1)
	}
	defer sub.Close()

	fmt.Println("Subscription active. Waiting for order updates...")
	fmt.Println("(Press Ctrl+C to stop, or place an order to see updates)")
	fmt.Println()

	// Handle graceful shutdown
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)

	// Receive updates for 30 seconds or until interrupted
	timeout := time.After(30 * time.Second)
	updateCount := 0

	for {
		select {
		case <-sigChan:
			fmt.Println("\nReceived interrupt, shutting down...")
			return

		case <-timeout:
			fmt.Printf("\nTimeout reached after 30 seconds. Received %d updates.\n", updateCount)
			return

		case <-sub.Done():
			if err := sub.Err(); err != nil {
				fmt.Fprintf(os.Stderr, "\nStream ended with error: %v\n", err)
			} else {
				fmt.Println("\nStream ended normally.")
			}
			return

		case update, ok := <-sub.Updates():
			if !ok {
				fmt.Println("\nUpdates channel closed.")
				return
			}
			updateCount++

			// Log all order updates (there usually won't be many)
			if snapshot := update.GetSnapshot(); snapshot != nil {
				fmt.Printf("Update #%d: Snapshot with %d orders\n", updateCount, len(snapshot.Orders))
				for i, order := range snapshot.Orders {
					if i < 3 {
						fmt.Printf("  - %s: %s %s @ %d (state: %s)\n",
							order.Id, order.Side, order.Symbol, order.Price, order.State)
					}
				}
			} else if orderUpdate := update.GetUpdate(); orderUpdate != nil {
				fmt.Printf("Update #%d: Order update with %d execution(s)\n", updateCount, len(orderUpdate.Executions))
				for _, exec := range orderUpdate.Executions {
					if order := exec.GetOrder(); order != nil {
						fmt.Printf("  - %s: %s %s @ %d (state: %s)\n",
							order.Id, order.Side, order.Symbol, order.Price, order.State)
					}
				}
			} else if update.GetHeartbeat() != nil {
				fmt.Printf("Update #%d: Heartbeat\n", updateCount)
			}
		}
	}
}
