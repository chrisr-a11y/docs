// Example 04: Get Balance
//
// Demonstrates getting the USD balance for a trading account.
package main

import (
	"fmt"
	"os"
	"strconv"

	"github.com/polymarket/client-sample-code/go/config"
	"github.com/polymarket/client-sample-code/go/rest"
)

func main() {
	fmt.Println("============================================================")
	fmt.Println("Example 04: Get Balance")
	fmt.Println("============================================================")
	fmt.Println()

	// Load configuration
	cfg := config.MustLoad()

	// Create REST client
	client := rest.NewClient(cfg)

	// Get balance
	fmt.Printf("Getting USD balance for account: %s\n", cfg.Account)
	result, err := client.GetBalance(cfg.Account, "USD")
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: %v\n", err)
		os.Exit(1)
	}

	// Parse and format balance
	balance, _ := strconv.ParseFloat(result.Balance, 64)
	fmt.Printf("  Balance: $%.2f USD\n", balance)
	fmt.Println()
	fmt.Println("Success!")
}
