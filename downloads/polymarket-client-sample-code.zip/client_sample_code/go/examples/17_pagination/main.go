// Example 17: Pagination
//
// Demonstrates how to paginate through large result sets using page tokens.
// Shows both manual pagination and the convenience SearchAllOrders() method.
package main

import (
	"fmt"
	"os"

	"github.com/polymarket/client-sample-code/go/config"
	"github.com/polymarket/client-sample-code/go/rest"
)

func main() {
	fmt.Println("============================================================")
	fmt.Println("Example 17: Pagination")
	fmt.Println("============================================================")
	fmt.Println()

	// Load configuration
	cfg := config.MustLoad()

	// Create REST client
	client := rest.NewClient(cfg)

	fmt.Printf("Account: %s\n\n", cfg.Account)

	// Method 1: Manual pagination
	manualPagination(client, cfg.Account)

	// Method 2: Automatic pagination
	automaticPagination(client, cfg.Account)

	fmt.Println()
	fmt.Println("============================================================")
	fmt.Println("Pagination Patterns:")
	fmt.Println("============================================================")
	fmt.Println(`
1. Manual Pagination:
   - Use SearchOrdersWithToken() with pageToken parameter
   - Good for streaming/processing as you go
   - Memory efficient for large datasets

2. Automatic Pagination:
   - Use SearchAllOrders() for convenience
   - Returns all results in one call
   - Simpler code, but loads all into memory

3. Best Practices:
   - Use reasonable pageSize (50-100)
   - Handle errors at each page
   - Consider memory for large result sets
   - Add delays if hitting rate limits
`)
}

// manualPagination demonstrates manual pagination through orders.
//
// Use this approach when you need:
// - Control over when to stop fetching
// - To process results as they come in (streaming-like)
// - Memory efficiency for very large result sets
func manualPagination(client *rest.Client, account string) {
	fmt.Println("Method 1: Manual Pagination")
	fmt.Println("----------------------------------------")

	var allOrders []rest.Order
	pageToken := ""
	pageCount := 0
	pageSize := 10 // Small page size to demonstrate pagination

	for {
		pageCount++
		fmt.Printf("  Fetching page %d... ", pageCount)

		result, err := client.SearchOrdersWithToken(account, pageSize, pageToken)
		if err != nil {
			fmt.Printf("Error: %v\n", err)
			return
		}

		allOrders = append(allOrders, result.Orders...)
		fmt.Printf("got %d orders\n", len(result.Orders))

		// Get next page token
		pageToken = result.NextPageToken

		// Stop if no more pages
		if pageToken == "" {
			fmt.Println("  No more pages.")
			break
		}

		// Optional: limit pages for demo purposes
		if pageCount >= 5 {
			fmt.Println("  (stopping after 5 pages for demo)")
			break
		}
	}

	fmt.Printf("\n  Total orders retrieved: %d\n", len(allOrders))
}

// automaticPagination demonstrates automatic pagination using SearchAllOrders().
//
// Use this approach when you need:
// - All results in one call
// - Simplicity over control
// - Small to medium result sets
func automaticPagination(client *rest.Client, account string) {
	fmt.Println("\nMethod 2: Automatic Pagination (SearchAllOrders)")
	fmt.Println("----------------------------------------")

	fmt.Println("  Fetching all orders...")
	allOrders, err := client.SearchAllOrders(account, 50)
	if err != nil {
		fmt.Fprintf(os.Stderr, "  Error: %v\n", err)
		return
	}

	fmt.Printf("  Total orders retrieved: %d\n", len(allOrders))

	// Show summary by status
	if len(allOrders) > 0 {
		statusCounts := make(map[string]int)
		for _, order := range allOrders {
			statusCounts[order.Status]++
		}

		fmt.Println("\n  Orders by status:")
		for status, count := range statusCounts {
			fmt.Printf("    %s: %d\n", status, count)
		}
	}
}
