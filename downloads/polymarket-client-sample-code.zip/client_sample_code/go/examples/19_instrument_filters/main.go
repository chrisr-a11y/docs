// Example 19: Instrument Filters
//
// Demonstrates filtering instruments by state and metadata fields.
// These filters allow efficient querying of specific instrument subsets.
//
// Available Filters:
// - states: Filter by instrument states (INSTRUMENT_STATE_OPEN, INSTRUMENT_STATE_CLOSED, INSTRUMENT_STATE_TERMINATED)
// - metadata: Filter by metadata fields like sports_game_league, market_category
// - symbols: Filter by specific symbols (see Example 06)
// - tradableFilter: Filter tradable vs non-tradable instruments
package main

import (
	"fmt"
	"os"

	"github.com/polymarket/client-sample-code/go/config"
	"github.com/polymarket/client-sample-code/go/rest"
)

func main() {
	fmt.Println("============================================================")
	fmt.Println("Example 19: Instrument Filters")
	fmt.Println("============================================================")
	fmt.Println()

	// Load configuration
	cfg := config.MustLoad()

	// Create REST client
	client := rest.NewClient(cfg)

	// Filter 1: Get OPEN instruments only
	fmt.Println("Filter 1: Instruments in OPEN state")
	fmt.Println("-------------------------------------")
	resp, err := client.ListInstrumentsWithPagination(rest.ListInstrumentsRequest{
		PageSize: 10,
		States:   []string{"INSTRUMENT_STATE_OPEN"},
	})
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: %v\n", err)
	} else {
		fmt.Printf("  Found %d OPEN instruments (showing first 10):\n", len(resp.Instruments))
		for i, inst := range resp.Instruments {
			if i >= 5 {
				fmt.Printf("    ... and %d more\n", len(resp.Instruments)-5)
				break
			}
			fmt.Printf("    - %s: %s\n", inst.Symbol, truncate(inst.Description, 50))
		}
	}
	fmt.Println()

	// Filter 2: Get TERMINATED instruments
	fmt.Println("Filter 2: Instruments in TERMINATED state")
	fmt.Println("------------------------------------------")
	resp, err = client.ListInstrumentsWithPagination(rest.ListInstrumentsRequest{
		PageSize: 10,
		States:   []string{"INSTRUMENT_STATE_TERMINATED"},
	})
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: %v\n", err)
	} else {
		fmt.Printf("  Found %d TERMINATED instruments (showing first 10):\n", len(resp.Instruments))
		for i, inst := range resp.Instruments {
			if i >= 5 {
				fmt.Printf("    ... and %d more\n", len(resp.Instruments)-5)
				break
			}
			fmt.Printf("    - %s: %s\n", inst.Symbol, truncate(inst.Description, 50))
		}
	}
	fmt.Println()

	// Filter 3: Filter by metadata - sports_game_league=nfl
	fmt.Println("Filter 3: NFL sports instruments (metadata filter)")
	fmt.Println("---------------------------------------------------")
	resp, err = client.ListInstrumentsWithPagination(rest.ListInstrumentsRequest{
		PageSize: 20,
		Metadata: map[string]string{
			"sports_game_league": "nfl",
		},
	})
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: %v\n", err)
	} else {
		fmt.Printf("  Found %d NFL instruments:\n", len(resp.Instruments))
		for i, inst := range resp.Instruments {
			if i >= 5 {
				fmt.Printf("    ... and %d more\n", len(resp.Instruments)-5)
				break
			}
			fmt.Printf("    - %s: %s\n", inst.Symbol, truncate(inst.Description, 50))
		}
	}
	fmt.Println()

	// Filter 4: Filter by market category
	fmt.Println("Filter 4: Sports category instruments")
	fmt.Println("--------------------------------------")
	resp, err = client.ListInstrumentsWithPagination(rest.ListInstrumentsRequest{
		PageSize: 20,
		Metadata: map[string]string{
			"market_category": "sports",
		},
	})
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: %v\n", err)
	} else {
		fmt.Printf("  Found %d sports category instruments:\n", len(resp.Instruments))
		for i, inst := range resp.Instruments {
			if i >= 5 {
				fmt.Printf("    ... and %d more\n", len(resp.Instruments)-5)
				break
			}
			fmt.Printf("    - %s: %s\n", inst.Symbol, truncate(inst.Description, 50))
		}
	}
	fmt.Println()

	// Filter 5: Combined filters - OPEN + tradable only
	fmt.Println("Filter 5: OPEN and tradable instruments")
	fmt.Println("-----------------------------------------")
	resp, err = client.ListInstrumentsWithPagination(rest.ListInstrumentsRequest{
		PageSize:     10,
		States:       []string{"INSTRUMENT_STATE_OPEN"},
		TradableOnly: true,
	})
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: %v\n", err)
	} else {
		fmt.Printf("  Found %d OPEN and tradable instruments:\n", len(resp.Instruments))
		for i, inst := range resp.Instruments {
			if i >= 5 {
				fmt.Printf("    ... and %d more\n", len(resp.Instruments)-5)
				break
			}
			tradable := "tradable"
			if inst.NonTradable {
				tradable = "non-tradable"
			}
			fmt.Printf("    - %s (%s): %s\n", inst.Symbol, tradable, truncate(inst.Description, 40))
		}
	}
	fmt.Println()

	// Filter 6: Multiple states
	fmt.Println("Filter 6: OPEN or CLOSED instruments")
	fmt.Println("--------------------------------------")
	resp, err = client.ListInstrumentsWithPagination(rest.ListInstrumentsRequest{
		PageSize: 10,
		States:   []string{"INSTRUMENT_STATE_OPEN", "INSTRUMENT_STATE_CLOSED"},
	})
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: %v\n", err)
	} else {
		fmt.Printf("  Found %d OPEN or CLOSED instruments:\n", len(resp.Instruments))
		for i, inst := range resp.Instruments {
			if i >= 5 {
				fmt.Printf("    ... and %d more\n", len(resp.Instruments)-5)
				break
			}
			fmt.Printf("    - %s (state: %s)\n", inst.Symbol, inst.State)
		}
	}
	fmt.Println()

	fmt.Println("Success!")
}

// truncate shortens a string to maxLen characters
func truncate(s string, maxLen int) string {
	if len(s) <= maxLen {
		return s
	}
	return s[:maxLen-3] + "..."
}
