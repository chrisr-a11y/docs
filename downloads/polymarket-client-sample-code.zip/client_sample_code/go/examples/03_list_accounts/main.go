// Example 03: List Accounts
//
// Demonstrates listing trading accounts accessible to the current user.
package main

import (
	"fmt"
	"os"

	"github.com/polymarket/client-sample-code/go/config"
	"github.com/polymarket/client-sample-code/go/rest"
)

func main() {
	fmt.Println("============================================================")
	fmt.Println("Example 03: List Accounts")
	fmt.Println("============================================================")
	fmt.Println()

	// Load configuration
	cfg := config.MustLoad()

	// Create REST client
	client := rest.NewClient(cfg)

	// List accounts
	fmt.Println("Listing trading accounts...")
	result, err := client.ListAccounts()
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: %v\n", err)
		os.Exit(1)
	}

	if len(result.Accounts) == 0 {
		fmt.Println("  No accounts found")
	} else {
		fmt.Printf("  Found %d account(s):\n", len(result.Accounts))
		for i, account := range result.Accounts {
			fmt.Printf("    %d. %s\n", i+1, account)
		}
	}
	fmt.Println()
	fmt.Println("Success!")
}
