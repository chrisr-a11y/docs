// Example 02: Who Am I
//
// Demonstrates getting current user information.
// Returns the authenticated user and their firm.
package main

import (
	"fmt"
	"os"

	"github.com/polymarket/client-sample-code/go/config"
	"github.com/polymarket/client-sample-code/go/rest"
)

func main() {
	fmt.Println("============================================================")
	fmt.Println("Example 02: Who Am I")
	fmt.Println("============================================================")
	fmt.Println()

	// Load configuration
	cfg := config.MustLoad()

	// Create REST client
	client := rest.NewClient(cfg)

	// Get current user info
	fmt.Println("Getting current user info...")
	result, err := client.WhoAmI()
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: %v\n", err)
		os.Exit(1)
	}

	fmt.Printf("  User: %s\n", result.User)
	fmt.Printf("  Firm: %s\n", result.Firm)
	fmt.Println()
	fmt.Println("Success!")
}
