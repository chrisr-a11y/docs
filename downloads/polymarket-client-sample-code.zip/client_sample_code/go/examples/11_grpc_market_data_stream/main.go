// Example 11: gRPC Market Data Stream
//
// Demonstrates subscribing to market data (order book) updates via gRPC.
// The subscription provides real-time order book depth for specified symbols.
package main

import (
	"context"
	"fmt"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/polymarket/client-sample-code/go/config"
	grpcclient "github.com/polymarket/client-sample-code/go/grpc"
)

func main() {
	fmt.Println("============================================================")
	fmt.Println("Example 11: gRPC Market Data Stream")
	fmt.Println("============================================================")
	fmt.Println()

	// Load configuration
	cfg := config.MustLoad()

	// Create gRPC client
	fmt.Printf("Connecting to gRPC server: %s\n", cfg.GRPCAddr)
	client, err := grpcclient.NewClient(cfg)
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: %v\n", err)
		os.Exit(1)
	}
	defer client.Close()

	// Subscribe to market data
	symbols := []string{cfg.TestSymbol}
	depth := int32(5) // 5 levels of order book depth

	fmt.Printf("Subscribing to market data for symbols: %v (depth: %d)\n", symbols, depth)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	sub, err := client.SubscribeMarketData(ctx, symbols, depth)
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: Failed to subscribe: %v\n", err)
		os.Exit(1)
	}
	defer sub.Close()

	fmt.Println("Subscription active. Waiting for market data updates...")
	fmt.Println("(Press Ctrl+C to stop)")
	fmt.Println()

	// Handle graceful shutdown
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)

	// Receive updates for 30 seconds or until interrupted
	timeout := time.After(30 * time.Second)
	updateCount := 0

	for {
		select {
		case <-sigChan:
			fmt.Println("\nReceived interrupt, shutting down...")
			return

		case <-timeout:
			fmt.Printf("\nTimeout reached after 30 seconds. Received %d updates.\n", updateCount)
			return

		case <-sub.Done():
			if err := sub.Err(); err != nil {
				fmt.Fprintf(os.Stderr, "\nStream ended with error: %v\n", err)
			} else {
				fmt.Println("\nStream ended normally.")
			}
			return

		case update, ok := <-sub.Updates():
			if !ok {
				fmt.Println("\nUpdates channel closed.")
				return
			}
			updateCount++

			// Log first few updates
			if updateCount <= 5 {
				if md := update.GetUpdate(); md != nil {
					fmt.Printf("Update #%d: %s - %d bids, %d offers\n",
						updateCount, md.Symbol, len(md.Bids), len(md.Offers))
					if len(md.Bids) > 0 {
						fmt.Printf("  Top bid: %d @ %d\n", md.Bids[0].Qty, md.Bids[0].Px)
					}
					if len(md.Offers) > 0 {
						fmt.Printf("  Top offer: %d @ %d\n", md.Offers[0].Qty, md.Offers[0].Px)
					}
				} else if update.GetHeartbeat() != nil {
					fmt.Printf("Update #%d: Heartbeat\n", updateCount)
				}
			} else if updateCount == 6 {
				fmt.Println("(Suppressing further output...)")
			}
		}
	}
}
