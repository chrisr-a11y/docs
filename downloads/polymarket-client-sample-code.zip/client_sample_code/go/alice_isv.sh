#!/bin/bash
#
# Alice ISV Test Runner - Go Client Samples
#
# Runs all Go client sample code examples against dev01 using Alice ISV credentials.
#
# Usage:
#   ./alice_isv.sh              # Run all examples
#   ./alice_isv.sh --streaming  # Include gRPC streaming
#

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "============================================================"
echo "  Go Client Sample Code - Dev01 Test Runner (Alice ISV)"
echo "============================================================"
echo ""

# Alice ISV credentials (private_key_jwt auth)
export POLYMARKET_CLIENT_ID="pxvcbtk7WT5BoHxLMQNGb5xN2ubWg33S"
export POLYMARKET_PRIVATE_KEY_PATH="$SCRIPT_DIR/keys/alice_isv_private.pem"
export POLYMARKET_API_URL="https://api.dev01.polymarketexchange.com"
export POLYMARKET_AUTH_DOMAIN="pmx-dev01.us.auth0.com"
export POLYMARKET_AUTH_AUDIENCE="https://api.dev01.polymarketexchange.com"
export POLYMARKET_GRPC_ADDR="grpc-api.dev01.polymarketexchange.com:443"

# Alice user credentials
export POLYMARKET_PARTICIPANT_ID="firms/ISV-Participant-Alice/users/alice-bob"
export POLYMARKET_ACCOUNT="firms/ISV-Alice/accounts/alice-bob-trading"

# Test symbol
export POLYMARKET_TEST_SYMBOL="GWTEST-20251219"
export POLYMARKET_VERBOSE="true"
export POLYMARKET_TIMEOUT="30"

echo "Configuration:"
echo "  API URL: $POLYMARKET_API_URL"
echo "  gRPC Addr: $POLYMARKET_GRPC_ADDR"
echo "  Auth Domain: $POLYMARKET_AUTH_DOMAIN"
echo "  Client ID: ${POLYMARKET_CLIENT_ID:0:8}..."
echo "  Private Key: $POLYMARKET_PRIVATE_KEY_PATH"
echo "  Participant ID: $POLYMARKET_PARTICIPANT_ID"
echo "  Account: $POLYMARKET_ACCOUNT"
echo "  Test Symbol: $POLYMARKET_TEST_SYMBOL"
echo ""

# Verify private key exists
if [ ! -f "$POLYMARKET_PRIVATE_KEY_PATH" ]; then
    echo "ERROR: Private key not found: $POLYMARKET_PRIVATE_KEY_PATH"
    exit 1
fi

echo "Running Go client samples..."
echo "============================================================"
echo ""

cd "$SCRIPT_DIR"

# Run all examples using cmd/run_all
go run ./cmd/run_all/... "$@"
