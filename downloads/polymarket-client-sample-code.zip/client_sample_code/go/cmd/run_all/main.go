// Run All Examples
//
// This orchestrator runs all REST examples (01-10) in sequence,
// optionally starting background gRPC subscriptions first.
package main

import (
	"context"
	"flag"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"time"

	"github.com/polymarket/client-sample-code/go/config"
	grpcclient "github.com/polymarket/client-sample-code/go/grpc"
)

func main() {
	fmt.Println("============================================================")
	fmt.Println("Polymarket Exchange API - Go Sample Code")
	fmt.Println("============================================================")
	fmt.Println()

	// Parse flags
	withStreaming := flag.Bool("streaming", false, "Start background gRPC subscriptions")
	flag.Parse()

	// Load configuration to validate it early
	cfg, err := config.Load()
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR: %v\n", err)
		os.Exit(1)
	}

	fmt.Printf("Configuration loaded:\n")
	fmt.Printf("  API URL: %s\n", cfg.APIURL)
	fmt.Printf("  gRPC Address: %s\n", cfg.GRPCAddr)
	fmt.Printf("  Participant: %s\n", cfg.ParticipantID)
	fmt.Printf("  Account: %s\n", cfg.Account)
	fmt.Printf("  Test Symbol: %s\n", cfg.TestSymbol)
	fmt.Println()

	// Optionally start background gRPC subscriptions
	var grpcClient *grpcclient.Client
	if *withStreaming {
		fmt.Println("Starting background gRPC subscriptions...")
		grpcClient, err = grpcclient.NewClient(cfg)
		if err != nil {
			fmt.Printf("  WARNING: Could not connect to gRPC: %v\n", err)
		} else {
			defer grpcClient.Close()

			ctx := context.Background()

			// Start market data subscription
			mdSub, err := grpcClient.SubscribeMarketData(ctx, []string{cfg.TestSymbol}, 5)
			if err != nil {
				fmt.Printf("  WARNING: Market data subscription failed: %v\n", err)
			} else {
				defer mdSub.Close()
				fmt.Printf("  Market data subscription active for %s\n", cfg.TestSymbol)
				grpcclient.LogStreamUpdates("MarketData", mdSub.Updates(), mdSub.Done())
			}

			// Start order subscription
			orderSub, err := grpcClient.SubscribeOrders(ctx, []string{cfg.Account})
			if err != nil {
				fmt.Printf("  WARNING: Order subscription failed: %v\n", err)
			} else {
				defer orderSub.Close()
				fmt.Println("  Order subscription active")
				grpcclient.LogStreamUpdates("Orders", orderSub.Updates(), orderSub.Done())
			}

			// Start position subscription
			posSub, err := grpcClient.SubscribePositions(ctx, []string{cfg.Account})
			if err != nil {
				fmt.Printf("  WARNING: Position subscription failed: %v\n", err)
			} else {
				defer posSub.Close()
				fmt.Println("  Position subscription active")
				grpcclient.LogStreamUpdates("Positions", posSub.Updates(), posSub.Done())
			}

			fmt.Println()
			// Give subscriptions time to establish
			time.Sleep(2 * time.Second)
		}
	}

	// Find examples directory
	examplesDir := findExamplesDir()
	if examplesDir == "" {
		fmt.Fprintln(os.Stderr, "ERROR: Could not find examples directory")
		os.Exit(1)
	}

	// REST Examples to run
	restExamples := []string{
		"01_health_check",
		"02_whoami",
		"03_list_accounts",
		"04_get_balance",
		"05_list_positions",
		"06_list_instruments",
		"07_list_symbols",
		"08_search_orders",
		"09_list_users",
		"10_place_and_cancel_order",
	}

	fmt.Println("Running REST API Examples...")
	fmt.Println("============================================================")
	fmt.Println()

	passed := 0
	failed := 0
	var failedExamples []string

	for _, example := range restExamples {
		examplePath := filepath.Join(examplesDir, example)
		fmt.Printf("Running %s...\n", example)

		cmd := exec.Command("go", "run", ".")
		cmd.Dir = examplePath
		cmd.Stdout = os.Stdout
		cmd.Stderr = os.Stderr
		cmd.Env = os.Environ()

		err := cmd.Run()
		if err != nil {
			fmt.Printf("FAILED: %s\n", example)
			failed++
			failedExamples = append(failedExamples, example)
		} else {
			passed++
		}
		fmt.Println()

		// Small delay between examples
		time.Sleep(500 * time.Millisecond)
	}

	// Print summary
	fmt.Println("============================================================")
	fmt.Println("Summary")
	fmt.Println("============================================================")
	fmt.Printf("Passed: %d/%d\n", passed, len(restExamples))
	fmt.Printf("Failed: %d/%d\n", failed, len(restExamples))

	if len(failedExamples) > 0 {
		fmt.Println("\nFailed examples:")
		for _, e := range failedExamples {
			fmt.Printf("  - %s\n", e)
		}
	}

	if *withStreaming && grpcClient != nil {
		fmt.Println("\nStreaming subscriptions were active during the test run.")
		fmt.Println("Check the logs above for any streaming updates received.")
	}

	if failed > 0 {
		os.Exit(1)
	}
}

func findExamplesDir() string {
	// Try relative paths from common locations
	candidates := []string{
		"examples",
		"../examples",
		"../../examples",
		"client_sample_code/go/examples",
	}

	for _, c := range candidates {
		if _, err := os.Stat(filepath.Join(c, "01_health_check")); err == nil {
			return c
		}
	}

	return ""
}
