// Package rest provides a REST API client for the Polymarket Exchange API.
package rest

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"

	"github.com/google/uuid"
	"github.com/polymarket/client-sample-code/go/auth"
	"github.com/polymarket/client-sample-code/go/config"
)

// Client is a REST API client for the Polymarket Exchange API.
type Client struct {
	config     *config.Config
	httpClient *http.Client
}

// NewClient creates a new REST API client.
func NewClient(cfg *config.Config) *Client {
	return &Client{
		config: cfg,
		httpClient: &http.Client{
			Timeout: time.Duration(cfg.Timeout) * time.Second,
		},
	}
}

// Response represents an API response.
type Response struct {
	StatusCode int
	Body       []byte
	Headers    http.Header
}

// JSON unmarshals the response body into the provided target.
func (r *Response) JSON(target interface{}) error {
	return json.Unmarshal(r.Body, target)
}

// request makes an HTTP request to the API.
func (c *Client) request(method, path string, body interface{}, authenticated bool) (*Response, error) {
	url := c.config.APIURL + path

	var bodyReader io.Reader
	if body != nil {
		data, err := json.Marshal(body)
		if err != nil {
			return nil, fmt.Errorf("failed to marshal request body: %w", err)
		}
		bodyReader = bytes.NewReader(data)
	}

	req, err := http.NewRequest(method, url, bodyReader)
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	// Set headers
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("x-request-id", uuid.New().String())

	if authenticated {
		bearer, err := auth.BearerToken(c.config)
		if err != nil {
			return nil, fmt.Errorf("failed to get auth token: %w", err)
		}
		req.Header.Set("Authorization", bearer)
		// Only send participant ID if set (not required for RefData endpoints)
		if c.config.ParticipantID != "" {
			req.Header.Set("x-participant-id", c.config.ParticipantID)
		}
	}

	if c.config.Verbose {
		fmt.Printf("\n>>> %s %s\n", method, url)
		if body != nil {
			data, _ := json.MarshalIndent(body, "  ", "  ")
			fmt.Printf("  Body: %s\n", data)
		}
	}

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("request failed: %w", err)
	}
	defer resp.Body.Close()

	respBody, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response body: %w", err)
	}

	if c.config.Verbose {
		fmt.Printf("\n<<< %d\n", resp.StatusCode)
		if len(respBody) > 0 && len(respBody) < 500 {
			fmt.Printf("  Response: %s\n", respBody)
		} else if len(respBody) > 0 {
			fmt.Printf("  Response: %s...\n", respBody[:500])
		}
	}

	return &Response{
		StatusCode: resp.StatusCode,
		Body:       respBody,
		Headers:    resp.Header,
	}, nil
}

// Get makes an authenticated GET request.
func (c *Client) Get(path string) (*Response, error) {
	return c.request("GET", path, nil, true)
}

// GetNoAuth makes an unauthenticated GET request.
func (c *Client) GetNoAuth(path string) (*Response, error) {
	return c.request("GET", path, nil, false)
}

// Post makes an authenticated POST request.
func (c *Client) Post(path string, body interface{}) (*Response, error) {
	return c.request("POST", path, body, true)
}

// PostNoAuth makes an unauthenticated POST request.
func (c *Client) PostNoAuth(path string, body interface{}) (*Response, error) {
	return c.request("POST", path, body, false)
}

// =============================================================================
// Health API (No Auth Required)
// =============================================================================

// HealthResponse represents the health check response.
type HealthResponse struct {
	Status string `json:"status"`
}

// Health checks the API health status. No authentication required.
func (c *Client) Health() (*HealthResponse, error) {
	resp, err := c.GetNoAuth("/v1/health")
	if err != nil {
		return nil, err
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("health check failed with status %d: %s", resp.StatusCode, resp.Body)
	}

	var result HealthResponse
	if err := resp.JSON(&result); err != nil {
		return nil, fmt.Errorf("failed to parse health response: %w", err)
	}
	return &result, nil
}

// =============================================================================
// Accounts API
// =============================================================================

// WhoAmIResponse represents the current user info.
type WhoAmIResponse struct {
	User string `json:"user"`
	Firm string `json:"firm"`
}

// WhoAmI returns the current authenticated user info.
func (c *Client) WhoAmI() (*WhoAmIResponse, error) {
	resp, err := c.Get("/v1/whoami")
	if err != nil {
		return nil, err
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("whoami failed with status %d: %s", resp.StatusCode, resp.Body)
	}

	var result WhoAmIResponse
	if err := resp.JSON(&result); err != nil {
		return nil, fmt.Errorf("failed to parse whoami response: %w", err)
	}
	return &result, nil
}

// AccountsResponse represents the list of accounts.
type AccountsResponse struct {
	Accounts []string `json:"accounts"`
}

// ListAccounts returns the trading accounts accessible to the current user.
func (c *Client) ListAccounts() (*AccountsResponse, error) {
	resp, err := c.Get("/v1/accounts")
	if err != nil {
		return nil, err
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("list accounts failed with status %d: %s", resp.StatusCode, resp.Body)
	}

	var result AccountsResponse
	if err := resp.JSON(&result); err != nil {
		return nil, fmt.Errorf("failed to parse accounts response: %w", err)
	}
	return &result, nil
}

// UsersResponse represents the list of users.
type UsersResponse struct {
	Users []string `json:"users"`
}

// ListUsers returns the users in the firm.
func (c *Client) ListUsers() (*UsersResponse, error) {
	resp, err := c.Get("/v1/users")
	if err != nil {
		return nil, err
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("list users failed with status %d: %s", resp.StatusCode, resp.Body)
	}

	var result UsersResponse
	if err := resp.JSON(&result); err != nil {
		return nil, fmt.Errorf("failed to parse users response: %w", err)
	}
	return &result, nil
}

// =============================================================================
// Positions API
// =============================================================================

// BalanceResponse represents an account balance.
type BalanceResponse struct {
	Balance string `json:"balance"`
}

// GetBalance returns the balance for the specified account and currency.
func (c *Client) GetBalance(account, currency string) (*BalanceResponse, error) {
	resp, err := c.Post("/v1/positions/balance", map[string]string{
		"name":     account,
		"currency": currency,
	})
	if err != nil {
		return nil, err
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("get balance failed with status %d: %s", resp.StatusCode, resp.Body)
	}

	var result BalanceResponse
	if err := resp.JSON(&result); err != nil {
		return nil, fmt.Errorf("failed to parse balance response: %w", err)
	}
	return &result, nil
}

// Position represents a trading position.
type Position struct {
	Account     string `json:"account"`
	Symbol      string `json:"symbol"`
	NetPosition string `json:"net_position"`
	QtyBought   string `json:"qty_bought"`
	QtySold     string `json:"qty_sold"`
	Cost        string `json:"cost"`
	Realized    string `json:"realized"`
}

// PositionsResponse represents the list of positions.
type PositionsResponse struct {
	Positions []Position `json:"positions"`
}

// ListPositions returns the positions for the specified account.
func (c *Client) ListPositions(account string) (*PositionsResponse, error) {
	resp, err := c.Get(fmt.Sprintf("/v1/positions?name=%s", account))
	if err != nil {
		return nil, err
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("list positions failed with status %d: %s", resp.StatusCode, resp.Body)
	}

	var result PositionsResponse
	if err := resp.JSON(&result); err != nil {
		return nil, fmt.Errorf("failed to parse positions response: %w", err)
	}
	return &result, nil
}

// =============================================================================
// Order Book API (No participant_id required)
//
// These endpoints require authentication but do NOT require a participant_id.
// You can call them before KYC onboarding is complete.
// =============================================================================

// BookEntry represents a price level in the order book.
type BookEntry struct {
	Px            string `json:"px"`
	Qty           string `json:"qty"`
	SymbolSubType string `json:"symbolSubType"`
}

// OrderBookResponse represents the L2 order book snapshot.
type OrderBookResponse struct {
	Symbol string      `json:"symbol"`
	Bids   []BookEntry `json:"bids"`
	Offers []BookEntry `json:"offers"`
	State  string      `json:"state"`
	Stats  interface{} `json:"stats"`
}

// GetOrderBook returns the L2 order book for the specified symbol.
func (c *Client) GetOrderBook(symbol string, depth int) (*OrderBookResponse, error) {
	if depth <= 0 {
		depth = 3
	}
	resp, err := c.Get(fmt.Sprintf("/v1/orderbook/%s?depth=%d", symbol, depth))
	if err != nil {
		return nil, err
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("get orderbook failed with status %d: %s", resp.StatusCode, resp.Body)
	}

	var result OrderBookResponse
	if err := resp.JSON(&result); err != nil {
		return nil, fmt.Errorf("failed to parse orderbook response: %w", err)
	}
	return &result, nil
}

// BBOResponse represents the best bid/offer response.
type BBOResponse struct {
	Symbol    string     `json:"symbol"`
	BestBid   *BookEntry `json:"bestBid"`
	BestOffer *BookEntry `json:"bestOffer"`
	Spread    string     `json:"spread"`
	MidPrice  string     `json:"midPrice"`
	State     string     `json:"state"`
}

// GetBBO returns the best bid/offer for the specified symbol.
func (c *Client) GetBBO(symbol string) (*BBOResponse, error) {
	resp, err := c.Get(fmt.Sprintf("/v1/orderbook/%s/bbo", symbol))
	if err != nil {
		return nil, err
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("get BBO failed with status %d: %s", resp.StatusCode, resp.Body)
	}

	var result BBOResponse
	if err := resp.JSON(&result); err != nil {
		return nil, fmt.Errorf("failed to parse BBO response: %w", err)
	}
	return &result, nil
}

// =============================================================================
// Reference Data API (No participant_id required)
//
// These endpoints require authentication but do NOT require a participant_id.
// You can call them before KYC onboarding is complete.
// =============================================================================

// Instrument represents a tradeable instrument.
type Instrument struct {
	Symbol      string `json:"symbol"`
	Description string `json:"description"`
	State       string `json:"state"`
	TickSize    int64  `json:"tick_size"`
	MinQty      int64  `json:"min_qty"`
}

// InstrumentsResponse represents the list of instruments.
type InstrumentsResponse struct {
	Instruments []Instrument `json:"instruments"`
}

// ListInstruments returns the tradeable instruments, optionally filtered by symbols.
func (c *Client) ListInstruments(symbols []string) (*InstrumentsResponse, error) {
	body := map[string]interface{}{
		"symbols": symbols,
	}
	if symbols == nil {
		body["symbols"] = []string{}
	}

	resp, err := c.Post("/v1/refdata/instruments", body)
	if err != nil {
		return nil, err
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("list instruments failed with status %d: %s", resp.StatusCode, resp.Body)
	}

	var result InstrumentsResponse
	if err := resp.JSON(&result); err != nil {
		return nil, fmt.Errorf("failed to parse instruments response: %w", err)
	}
	return &result, nil
}

// SymbolsResponse represents the list of available symbols.
type SymbolsResponse struct {
	Symbols []string `json:"symbols"`
}

// ListSymbols returns all available trading symbols.
func (c *Client) ListSymbols() (*SymbolsResponse, error) {
	resp, err := c.Post("/v1/refdata/symbols", map[string]interface{}{})
	if err != nil {
		return nil, err
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("list symbols failed with status %d: %s", resp.StatusCode, resp.Body)
	}

	var result SymbolsResponse
	if err := resp.JSON(&result); err != nil {
		return nil, fmt.Errorf("failed to parse symbols response: %w", err)
	}
	return &result, nil
}

// =============================================================================
// Report API (Order History)
// =============================================================================

// TradeStatsResponse represents aggregated trade statistics.
// Note: GetTradeStats does NOT require participant_id.
type TradeStatsResponse struct {
	Symbol string      `json:"symbol"`
	Stats  interface{} `json:"stats"`
}

// GetTradeStats returns aggregated trade statistics for the specified symbol.
// Note: This endpoint requires authentication but does NOT require a participant_id.
// You can call it before KYC onboarding is complete.
func (c *Client) GetTradeStats(symbol string) (*TradeStatsResponse, error) {
	resp, err := c.Post("/v1/report/trades/stats", map[string]string{
		"symbol": symbol,
	})
	if err != nil {
		return nil, err
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("get trade stats failed with status %d: %s", resp.StatusCode, resp.Body)
	}

	var result TradeStatsResponse
	if err := resp.JSON(&result); err != nil {
		return nil, fmt.Errorf("failed to parse trade stats response: %w", err)
	}
	return &result, nil
}

// Order represents an order in the system.
type Order struct {
	OrderID     string `json:"order_id,omitempty"`
	ClOrdID     string `json:"clord_id,omitempty"`
	Symbol      string `json:"symbol"`
	Side        string `json:"side"`
	Type        string `json:"type"`
	Status      string `json:"status,omitempty"`
	OrderQty    int64  `json:"order_qty"`
	Price       int64  `json:"price"`
	FilledQty   int64  `json:"filled_qty,omitempty"`
	Account     string `json:"account"`
	TimeInForce string `json:"time_in_force,omitempty"`
}

// SearchOrdersResponse represents the order search results.
type SearchOrdersResponse struct {
	Orders        []Order `json:"orders"`
	NextPageToken string  `json:"next_page_token,omitempty"`
}

// SearchOrders searches historical orders for the specified account.
func (c *Client) SearchOrders(account string, pageSize int) (*SearchOrdersResponse, error) {
	return c.SearchOrdersWithToken(account, pageSize, "")
}

// SearchOrdersWithToken searches historical orders with pagination support.
func (c *Client) SearchOrdersWithToken(account string, pageSize int, pageToken string) (*SearchOrdersResponse, error) {
	body := map[string]interface{}{
		"account":   account,
		"page_size": pageSize,
	}
	if pageToken != "" {
		body["page_token"] = pageToken
	}

	resp, err := c.Post("/v1/report/orders/search", body)
	if err != nil {
		return nil, err
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("search orders failed with status %d: %s", resp.StatusCode, resp.Body)
	}

	var result SearchOrdersResponse
	if err := resp.JSON(&result); err != nil {
		return nil, fmt.Errorf("failed to parse orders response: %w", err)
	}
	return &result, nil
}

// SearchAllOrders retrieves all orders using pagination.
// Returns all orders for the account, automatically handling pagination.
func (c *Client) SearchAllOrders(account string, pageSize int) ([]Order, error) {
	var allOrders []Order
	pageToken := ""

	for {
		result, err := c.SearchOrdersWithToken(account, pageSize, pageToken)
		if err != nil {
			return nil, err
		}

		allOrders = append(allOrders, result.Orders...)

		if result.NextPageToken == "" {
			break
		}
		pageToken = result.NextPageToken
	}

	return allOrders, nil
}

// =============================================================================
// Trading API
// =============================================================================

// PlaceOrderRequest represents an order placement request.
type PlaceOrderRequest struct {
	Symbol      string `json:"symbol"`
	Side        string `json:"side"`
	Type        string `json:"type"`
	OrderQty    int64  `json:"order_qty"`
	Price       int64  `json:"price"`
	Account     string `json:"account"`
	ClOrdID     string `json:"clord_id"`
	TimeInForce string `json:"time_in_force"`
}

// PlaceOrderResponse represents the order placement response.
type PlaceOrderResponse struct {
	OrderID string `json:"orderId"` // Note: API returns camelCase
}

// PlaceOrder places a new trading order.
func (c *Client) PlaceOrder(req *PlaceOrderRequest) (*PlaceOrderResponse, error) {
	resp, err := c.Post("/v1/trading/orders", req)
	if err != nil {
		return nil, err
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("place order failed with status %d: %s", resp.StatusCode, resp.Body)
	}

	var result PlaceOrderResponse
	if err := resp.JSON(&result); err != nil {
		return nil, fmt.Errorf("failed to parse place order response: %w", err)
	}
	return &result, nil
}

// CancelOrderRequest represents an order cancellation request.
type CancelOrderRequest struct {
	OrderID string `json:"order_id"`
	Account string `json:"account"`
	Symbol  string `json:"symbol"`
}

// CancelOrder cancels a working order.
func (c *Client) CancelOrder(orderID, account, symbol string) error {
	req := &CancelOrderRequest{
		OrderID: orderID,
		Account: account,
		Symbol:  symbol,
	}

	resp, err := c.Post("/v1/trading/orders/cancel", req)
	if err != nil {
		return err
	}
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("cancel order failed with status %d: %s", resp.StatusCode, resp.Body)
	}

	return nil
}

// =============================================================================
// KYC API
// =============================================================================

// KYCAddress represents a user's address for KYC.
type KYCAddress struct {
	AddressLine1 string `json:"address_line_1"`
	City         string `json:"city"`
	State        string `json:"state"`
	PostalCode   string `json:"postal_code"`
	Country      string `json:"country"`
}

// KYCStartRequest represents a KYC start request.
//
// For Socure sandbox testing, use these DOBs:
//
// Consumer Onboarding (instant decision):
//   - 1985-10-02: Auto-approve (ACCEPT)
//   - 1985-09-04: Reject
//   - 1985-09-29: Review
//
// DocV (Document Verification) - triggers DocV flow, outcome after completion:
//   - 1985-09-02: DocV Accept
//   - 1985-09-05: DocV Reject
//   - 1985-09-26: DocV Review
//   - 1985-09-01: DocV Resubmit
//
// Reference: Socure ID+ Test Cases PDF
type KYCStartRequest struct {
	UserID      string     `json:"user_id"`
	FirstName   string     `json:"first_name"`
	LastName    string     `json:"last_name"`
	DateOfBirth string     `json:"date_of_birth"` // YYYY-MM-DD
	Email       string     `json:"email"`
	PhoneNumber string     `json:"phone_number"` // +1XXXXXXXXXX
	SSN         string     `json:"ssn"`
	Address     KYCAddress `json:"address"`
}

// KYCStatus represents the KYC status in a response.
type KYCStatus struct {
	Decision   string `json:"decision"`
	Status     string `json:"status"`
	SubStatus  string `json:"subStatus"`
	ExternalID string `json:"externalId"`
}

// DocVData represents DocV (Document Verification) data for mobile SDK integration.
type DocVData struct {
	DocVTransactionToken string `json:"docvTransactionToken"` // Token for SDK launch()
	SDKKey               string `json:"sdkKey"`               // Public key for SDK initialization
	URL                  string `json:"url"`                  // Web URL for DocV
	QRCode               string `json:"qrCode"`               // QR code image (base64 PNG)
	EventID              string `json:"eventId"`              // Socure event ID
}

// KYCStartResponse represents the KYC start response.
type KYCStartResponse struct {
	Status        KYCStatus `json:"status"`
	DocV          *DocVData `json:"docv,omitempty"`
	ParticipantID string    `json:"participantId"`
	Account       string    `json:"account"`
}

// KYCStart initiates KYC verification for a new user.
func (c *Client) KYCStart(req *KYCStartRequest) (*KYCStartResponse, error) {
	resp, err := c.Post("/v1/kyc/start", req)
	if err != nil {
		return nil, err
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("KYC start failed with status %d: %s", resp.StatusCode, resp.Body)
	}

	var result KYCStartResponse
	if err := resp.JSON(&result); err != nil {
		return nil, fmt.Errorf("failed to parse KYC start response: %w", err)
	}
	return &result, nil
}

// KYCStatusResponse represents the KYC status response.
type KYCStatusResponse struct {
	Status        KYCStatus `json:"status"`
	ParticipantID string    `json:"participantId"`
	Account       string    `json:"account"`
}

// KYCGetStatus gets the KYC status for a user.
func (c *Client) KYCGetStatus(userID string) (*KYCStatusResponse, error) {
	resp, err := c.Get("/v1/kyc/status?user_id=" + userID)
	if err != nil {
		return nil, err
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("KYC status failed with status %d: %s", resp.StatusCode, resp.Body)
	}

	var result KYCStatusResponse
	if err := resp.JSON(&result); err != nil {
		return nil, fmt.Errorf("failed to parse KYC status response: %w", err)
	}
	return &result, nil
}
